<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Testimonials
 */
class FS_Testimonials extends \Elementor\Widget_Base
{

    /**
     * @return string
     */
    public function get_name()
    {

        return 'fs-testimonials';

    }

    /**
     * @return string|void
     */
    public function get_title()
    {

        return __('Testimonials', 'fs-core');

    }

    /**
     * @return string
     */
    public function get_icon()
    {

        return 'eicon-review';

    }

    /**
     * @return array
     */
    public function get_categories()
    {

        return ['fs-widgets'];

    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'testimonial_text',
            [
                'label' => __('Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Testimonial Text', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_image',
            [
                'label' => __('Logo', 'fs-core'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_link',
            [
                'label' => __('Testimonial Link', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Testimonial Link', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_link_url',
            [
                'label' => __('Link URL', 'fs-core'),
                'type' => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'testimonial',
            [
                'label' => __('Testimonial', 'fs-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();
    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $header_trigger = false;

        $content_trigger = false;

        ?>

        <div class="fs-testimonials">

            <ul class="testimonials-items">

                <?php

                foreach ($settings['testimonial'] as $item) :

                    $testimonial_text = $item['testimonial_text'];

                    $testimonial_link = $item['testimonial_link'];

                    $testimonial_link_url = $item['testimonial_link_url'];

                    ?>

                    <li class="testimonial-item <?php if (!$header_trigger): ?> active <?php endif; ?>">

                        <p class="testimonial-text body-2">

                            <?php echo esc_html($testimonial_text); ?>

                        </p>

                        <a href="<?php echo esc_url($testimonial_link_url['url']); ?>" class="testimonial-link fs-link">

                            <?php echo esc_html($testimonial_link); ?>

                        </a>

                    </li>

                    <?php

                    $header_trigger = true;

                endforeach;

                ?>

            </ul>

            <div class="logos-wrapper">

                <ul class="testimonials-logos">

                    <?php foreach ($settings['testimonial'] as $item) :

                        $testimonial_image = $item['testimonial_image'];

                        $image_url = wp_get_attachment_image_url($testimonial_image['id']);

                        ?>

                        <li class="testimonial-logo <?php if (!$content_trigger): ?> active <?php endif; ?>">

                            <img src="<?php echo esc_url($image_url); ?>"
                                 alt="<?php echo esc_html__('Logotype', 'fs-core'); ?>">

                        </li>

                        <?php $content_trigger = true; ?>

                    <?php endforeach; ?>

                </ul>

            </div>

        </div>

        <?php
    }
}
