<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Positions_List_Widget
 */
class FS_Positions_List_Widget extends \Elementor\Widget_Base
{
    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-positions-list';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Positions List', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-bullet-list';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'positions_count',
            [
                'label' => __('Positions Count', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 4,
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        $args = array(
            'posts_per_page' => $settings['positions_count']['size'],
            'order' => 'DESC',
            'post_type' => 'career',
            'post__not_in' => array(get_the_ID()),
        );

        $the_query = new WP_Query($args);

        if ($the_query->have_posts()) :

            ?>

            <div class="related-positions">

                <div class="positions-list">

                    <div class="inner-wrapper">

                        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                            <?php

                            $title = get_the_title();

                            $field_position_location = FSD_Helper::get_field('field_position_location');

                            ?>

                            <article <?php post_class('position-item'); ?>>

                                <div class="item-inner">

                                    <a href="<?php the_permalink(); ?>" class="link-overlay">


                                    </a>

                                    <p class="post-title body-3">

                                        <?php echo esc_html(wp_trim_words($title, 7, '...')); ?>

                                    </p>

                                    <p class="location body-8">

                                        <?php echo esc_html($field_position_location); ?>

                                    </p>

                                    <span class="arrow">

                                         <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow.svg') ?>"
                                              alt="<?php echo esc_attr__('Arrow Icon', 'fs-core'); ?>">

                                            </span>

                                </div>

                            </article>

                        <?php endwhile; ?>

                    </div>

                </div>

            </div>

        <?php

        endif;

    }
}
