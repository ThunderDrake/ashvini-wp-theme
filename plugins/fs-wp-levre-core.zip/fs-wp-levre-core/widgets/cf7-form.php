<?php defined('ABSPATH') || exit;

/**
 * Class FS_CF7_Form_Widget
 */
class FS_CF7_Form_Widget extends \Elementor\Widget_Base
{

    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-cf7-form';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('CF7 Contact Form', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'cf7_form_options',
            [
                'label' => __('CF7 Options', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $contactForms =  FSD_Helper::get_cf7();

        $this->add_control(
            'cf7_form',
            [
                'label' => __('Contact form', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'description' => __('Select the contact form', 'fs-core'),
                'options' =>$contactForms,
            ]
        );

        $this->end_controls_section();

    }

    /* Render */
    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        ?>

        <div class="cf7-main-wrapper">

            <?php

            echo do_shortcode('[contact-form-7 id="' . $settings['cf7_form'] . '" ]');

            ?>

        </div>

        <?php

    }
}
