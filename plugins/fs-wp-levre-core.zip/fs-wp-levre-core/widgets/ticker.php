<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Ticker_Widget
 */
class FS_Ticker_Widget extends \Elementor\Widget_Base
{
    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-ticker';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Ticker', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-animation-text';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ticker_text',
            [
                'label' => __('Ticker Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Ticker Sample Text', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'ticker_image',
            [
                'label' => __('OR Ticker Image', 'fs-core'),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'ticker',
            [
                'label' => __('Ticker', 'fs-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'ticker_text' => __('Ticker Sample Text', 'fs-core'),
                    ],
                    [
                        'ticker_text' => __('Ticker Sample Text', 'fs-core'),
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'ticker_space',
            [
                'label' => __('Ticker Space', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 60,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'unit' => 'px',
                ],
                'size_units' => ['px'],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ticker-item' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        ?>

        <div class="ticker-wrapper">

            <div class="marquee inner-wrapper">

                <ul class="ticker-list">

                    <?php foreach ($settings['ticker'] as $item) : ?>

                        <li class="ticker-item">

                            <?php if (!empty($item['ticker_text'])): ?>

                                <h3>

                                    <?php print_r($item['ticker_text']); ?>

                                </h3>

                            <?php else: ?>

                                <?php if (!empty($item['ticker_image'])): ?>

                                    <?php

                                    $ticker_image = $item['ticker_image'];

                                    ?>

                                    <img src="<?php echo esc_url($ticker_image['url']); ?>"
                                         alt="<?php echo esc_html__('Logotype', 'fs-core'); ?>">

                                <?php endif; ?>

                            <?php endif; ?>

                        </li>

                    <?php endforeach; ?>

                    <?php foreach ($settings['ticker'] as $item) : ?>

                        <li class="ticker-item">

                            <?php if (!empty($item['ticker_text'])): ?>

                                <h3>

                                    <?php print_r($item['ticker_text']); ?>

                                </h3>

                            <?php else: ?>

                                <?php if (!empty($item['ticker_image'])): ?>

                                    <?php

                                    $ticker_image = $item['ticker_image'];

                                    ?>

                                    <img src="<?php echo esc_url($ticker_image['url']); ?>"
                                         alt="<?php echo esc_html__('Logotype', 'fs-core'); ?>">

                                <?php endif; ?>

                            <?php endif; ?>

                        </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        </div>

        <?php

    }
}
