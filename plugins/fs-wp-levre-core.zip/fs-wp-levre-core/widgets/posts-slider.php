<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Posts_Slider_Widget
 */
class FS_Posts_Slider_Widget extends \Elementor\Widget_Base
{
    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-posts-slider';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Posts Slider', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-post-slider';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        FSD_Helper::the_post_controls($this);

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => __('Loop', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('True', 'your-plugin'),
                'label_off' => __('False', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'slider_layout',
            [
                'label' => __('Slider Layout', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => false,
                'default' => 'boxed',
                'description' => __('Select the layout type', 'fs-core'),
                'options' => [
                    'boxed' => __('Boxed', 'fs-core'),
                    'full-width' => __('Full Width', 'fs-core'),
                ],
            ]
        );

        $this->add_control(
            'arrows',
            [
                'label' => __('Arrows', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Enable', 'your-plugin'),
                'label_off' => __('Disable', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_control(
            'scrollbar',
            [
                'label' => __('Scrollbar', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Enable', 'your-plugin'),
                'label_off' => __('Disable', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'arrows_position',
            [
                'label' => __('Arrows Position', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => false,
                'default' => 'inside',
                'description' => __('Select the arrows position', 'fs-core'),
                'options' => [
                    'inside' => __('Inside', 'fs-core'),
                    'outside' => __('Outside', 'fs-core'),
                ],
                'condition' => [
                    'arrows' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'responsive_view',
            [
                'label' => __('Responsive View', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'slider' => [
                        'title' => __('Slider', 'plugin-domain'),
                        'icon' => 'eicon-post-slider',
                    ],
                    'grid' => [
                        'title' => __('Grid', 'plugin-domain'),
                        'icon' => 'eicon-gallery-grid',
                    ],
                ],
                'default' => 'slider',
                'toggle' => true,
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        $the_query = FSD_Helper::get_posts_query($settings);

        $title_output_length = $settings['title_output_length']['size'];

        $slider_layout = $settings['slider_layout'];

        $loop = $settings['loop'];

        $responsive_view = $settings['responsive_view'];

        if (empty(preg_replace('/[0-9]+/', '', $id))):

            $id = 'empty-id';

        endif;

        ?>

        <div class="posts-slider-wrapper <?php echo esc_attr('responsive-view-' . $responsive_view); ?> <?php echo esc_attr($slider_layout); ?> <?php if ($loop !== 'yes'): ?>loop-disabled<?php endif; ?>"
             id="<?php echo esc_attr(preg_replace('/[0-9]+/', '', $id)); ?>">

            <div class="inner-wrapper">

                <div class="swiper-container posts-slider"
                     <?php if ($loop === 'yes'): ?>data-loop="<?php echo esc_attr('true'); ?>"<?php endif; ?>>

                    <div class="swiper-wrapper">

                        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                            <?php

                            $title = get_the_title();

                            $category = get_the_category();

                            if (has_post_thumbnail()):

                                ?>

                                <article <?php post_class('swiper-slide post-article blog-card-slider'); ?>>

                                    <div class="card-inner">

                                        <div class="card-header">

                                            <a href="<?php the_permalink(); ?>" class="link-overlay"></a>

                                            <?php

                                            $image_id = get_post_thumbnail_id(get_the_ID());

                                            echo FSD_Helper::render_image($image_id,
                                                'fs-vertical-size-medium',
                                                array('sizes' => implode(',', array(
                                                    '(max-width: 300px) 300px',
                                                    '(max-width: 540px) 540px',
                                                    '(max-width: 768px) 768px',
                                                )),
                                                    'srcset' => implode(',', array(
                                                        esc_url(wp_get_attachment_image_url($image_id, 'fs-vertical-size-extra-small')) . ' 300w',
                                                        esc_url(wp_get_attachment_image_url($image_id, 'fs-vertical-size-small')) . ' 540w',
                                                        esc_url(wp_get_attachment_image_url($image_id, 'fs-vertical-size-medium')) . ' 768w',
                                                    )),
                                                    'loading' => 'lazy',
                                                    'class' => 'wp-image-slider',
                                                    'alt' => get_the_title()
                                                ), false);

                                            ?>

                                        </div>

                                        <div class="card-body">

                                            <div class="card-meta">

                                                <?php if (!empty($category)): ?>

                                                    <a class="category-name meta-item"
                                                       href="<?php echo esc_url(get_category_link($category[0]->term_id)); ?>">

                                                        <?php echo esc_html($category[0]->name); ?>

                                                    </a>

                                                <?php endif; ?>

                                                <p class="date meta-item">

                                                    <?php echo esc_html(get_the_date()); ?>

                                                </p>

                                            </div>

                                            <p class="card-title body-5">

                                                <a href="<?php the_permalink(); ?>">

                                                    <?php echo esc_html(wp_trim_words($title, $title_output_length, '...')); ?>

                                                </a>

                                            </p>

                                        </div>

                                    </div>

                                </article>

                            <?php

                            endif;

                        endwhile;

                        ?>

                    </div>

                    <div class="posts-slider-scrollbar <?php if ($settings['scrollbar'] !== 'yes'): ?>hidden<?php endif; ?>">

                    </div>

                    <?php if ($settings['arrows'] === 'yes' && $settings['arrows_position'] === 'inside'): ?>

                        <div class="posts-slider-navigation <?php echo esc_attr($settings['arrows_position']); ?>">

                            <div class="navigation-button navigation-button-prev">

                                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
                                     alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">

                            </div>

                            <div class="navigation-button navigation-button-next">

                                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
                                     alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">

                            </div>

                        </div>

                    <?php endif; ?>

                </div>

                <?php if ($settings['arrows'] === 'yes' && $settings['arrows_position'] === 'outside'): ?>

                    <div class="posts-slider-navigation <?php echo esc_attr($settings['arrows_position']); ?>">

                        <div class="navigation-button navigation-button-prev">

                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
                                 alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">

                        </div>

                        <div class="navigation-button navigation-button-next">

                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
                                 alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">

                        </div>

                    </div>

                <?php endif; ?>

            </div>

        </div>

        <?php

    }
}
