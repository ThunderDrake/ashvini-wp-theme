<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Products_Slider_Widget
 */
class FS_Products_Slider_Widget extends \Elementor\Widget_Base
{
	
	/**
	 * @return string
	 */
	public function get_name()
	{
		
		return 'fs-products-slider';
	}
	
	/**
	 * @return string|void
	 */
	public function get_title()
	{
		
		return __('Products Slider', 'fs-core');
	}
	
	/**
	 * @return string
	 */
	public function get_icon()
	{
		
		return 'eicon-post-slider';
	}
	
	/**
	 * @return array
	 */
	public function get_categories()
	{
		
		return ['fs-widgets'];
	}
	
	/**
	 *
	 */
	protected function register_controls()
	{
		
		$this->start_controls_section(
				'product_options',
				[
						'label' => __('Product Options', 'fs-core'),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				]
		);
		
		$this->add_control(
				'title_output_length',
				[
						'label' => __('Title length', 'fs-core'),
						'type' => \Elementor\Controls_Manager::SLIDER,
						'description' => __('The length of the displayed title. NOTE: For some types of widgets, the value should not be too large, as this can damage the appearance of the widget', 'fs-core'),
						'range' => [
								'px' => [
										'min' => 5,
										'max' => 30,
										'step' => 1,
								],
						],
						'default' => [
								'size' => 10,
						],
				]
		);
		
		$this->add_control(
				'products_count',
				[
						'label' => __('Show Products', 'fs-core'),
						'description' => __('Count of displayed products in the slider', 'fs-core'),
						'type' => \Elementor\Controls_Manager::SLIDER,
						'range' => [
								'px' => [
										'min' => 2,
										'max' => 100,
										'step' => 1,
								],
						],
						'default' => [
								'size' => 7,
						],
				]
		);
		
		$this->add_control(
				'products_sorting',
				[
						'label' => __('Products Sorting', 'fs-core'),
						'type' => \Elementor\Controls_Manager::SELECT2,
						'multiple' => false,
						'default' => 'latest',
						'description' => __('Select the type of slider sorting algorithm by which the slides will be sorted inside the slider', 'fs-core'),
						'options' => [
								'latest' => __('Latest', 'fs-core'),
								'random' => __('Random', 'fs-core'),
								'price' => __('Price', 'fs-core'),
								'rating' => __('Rating', 'fs-core'),
								'popularity' => __('Total Sales', 'fs-core'),
						],
				]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
				'content_section',
				[
						'label' => __('Settings', 'fs-core'),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				]
		);
		
		$this->add_control(
				'loop',
				[
						'label' => __('Loop', 'plugin-domain'),
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => __('Enable', 'your-plugin'),
						'label_off' => __('Disable', 'your-plugin'),
						'return_value' => 'yes',
						'default' => 'no',
				]
		);
		
		$this->add_control(
				'slider_layout',
				[
						'label' => __('Slider Layout', 'fs-core'),
						'type' => \Elementor\Controls_Manager::SELECT2,
						'multiple' => false,
						'default' => 'boxed',
						'description' => __('Select the layout type', 'fs-core'),
						'options' => [
								'boxed' => __('Boxed', 'fs-core'),
								'full-width' => __('Full Width', 'fs-core'),
						],
				]
		);
		
		$this->add_control(
				'arrows',
				[
						'label' => __('Arrows', 'plugin-domain'),
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => __('Enable', 'your-plugin'),
						'label_off' => __('Disable', 'your-plugin'),
						'return_value' => 'yes',
						'default' => 'no',
				]
		);
		$this->add_control(
				'scrollbar',
				[
						'label' => __('Scrollbar', 'plugin-domain'),
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => __('Enable', 'your-plugin'),
						'label_off' => __('Disable', 'your-plugin'),
						'return_value' => 'yes',
						'default' => 'no',
				]
		);
		
		$this->add_control(
				'arrows_position',
				[
						'label' => __('Arrows Position', 'fs-core'),
						'type' => \Elementor\Controls_Manager::SELECT2,
						'multiple' => false,
						'default' => 'inside',
						'description' => __('Select the arrows position', 'fs-core'),
						'options' => [
								'inside' => __('Inside', 'fs-core'),
								'outside' => __('Outside', 'fs-core'),
						],
						'condition' => [
								'arrows' => 'yes'
						],
				]
		);
		
		$this->add_control(
				'responsive_view',
				[
						'label' => __('Responsive View', 'plugin-domain'),
						'type' => \Elementor\Controls_Manager::CHOOSE,
						'options' => [
								'slider' => [
										'title' => __('Slider', 'plugin-domain'),
										'icon' => 'eicon-post-slider',
								],
								'grid' => [
										'title' => __('Grid', 'plugin-domain'),
										'icon' => 'eicon-gallery-grid',
								],
						],
						'default' => 'slider',
						'toggle' => true,
				]
		);
		
		$this->end_controls_section();
		
	}
	
	/**
	 *
	 */
	protected function render()
	{
		
		$settings = $this->get_settings_for_display();
		
		$id = $this->get_id();
		
		$args = [
				'posts_per_page' => $settings['products_count']['size'],
				'order' => 'DESC',
				'post_type' => 'product',
				'orderby' => $settings['products_sorting']
		];
		
		if ($settings['products_sorting'] === 'price' || $settings['products_sorting'] === 'rating' || $settings['products_sorting'] === 'popularity'):
			
			$args['orderby'] = 'meta_value_num';
			
			if ($settings['products_sorting'] === 'popularity'):
				
				$args['meta_key'] = 'total_sales';
			
			endif;
			
			if ($settings['products_sorting'] === 'rating'):
				
				$args['meta_key'] = '_wc_average_rating';
			
			endif;
			
			if ($settings['products_sorting'] === 'price'):
				
				$args['meta_key'] = '_price';
			
			endif;
		
		endif;
		
		$the_query = new WP_Query($args);
		
		$title_output_length = $settings['title_output_length']['size'];
		
		$slider_layout = $settings['slider_layout'];
		
		$loop = $settings['loop'];
		
		$responsive_view = $settings['responsive_view'];
		
		if (empty(preg_replace('/[0-9]+/', '', $id))):
			
			$id = 'empty-id';
		
		endif;
		
		?>
		
		<div class="posts-slider-wrapper woocommerce products <?php echo esc_attr('responsive-view-' . $responsive_view); ?> <?php echo esc_attr($slider_layout); ?> <?php if ($loop !== 'yes'): ?>loop-disabled<?php endif; ?>"
		     id="<?php echo esc_attr(preg_replace('/[0-9]+/', '', $id)); ?>">
			
			<div class="inner-wrapper">
				
				<div class="swiper-container posts-slider"
				     <?php if ($loop === 'yes'): ?>data-loop="<?php echo esc_attr('true'); ?>"<?php endif; ?>>
					
					<div class="swiper-wrapper">
						
						<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
							
							<?php
							
							$product = wc_get_product(get_the_ID());
							
							$post = get_post();
							
							$title = get_the_title();
							
							$image_id = get_post_thumbnail_id(get_the_ID());
							
							if (has_post_thumbnail()):
								
								?>
								
								<article <?php post_class('swiper-slide post-article blog-card-slider product'); ?>
										data-product-id="<?php echo esc_attr($product->get_id()); ?>">
									
									<div class="card-inner <?php if (!$product->managing_stock() && !$product->is_in_stock()): ?>outofstock<?php endif; ?>">
										
										<div class="card-header">
											
											<?php echo wc_get_rating_html($product->get_average_rating()); ?>
											
											<?php $labels_toggle = get_theme_mod('shop-labels', 1); ?>
											
											<?php if ($labels_toggle): ?>
												
												<div class="badges-wrapper">
													
													<?php
													
													$newness_days = (int)get_theme_mod('shop-newest-items-treshhold', '3');
													
													$field_new_label = FSD_Helper::get_field('field_new_label', get_the_ID());
													
													$created = strtotime($product->get_date_created());
													
													if ((time() - (60 * 60 * 24 * $newness_days)) < $created || $field_new_label) :
														
														echo '<span class="itsnew">' . esc_html__('New!', 'woocommerce') . '</span>';
													
													endif;
													
													if (!$product->is_in_stock()) :
														
														echo '<span class="sold-out-badge">' . esc_html__("Sold Out", "levre") . '</span>';
													
													endif;
													
													if ($product->is_on_sale()) :
														
														echo apply_filters('woocommerce_sale_flash', '<span class="onsale">' . esc_html__('Sale!', 'levre') . '</span>', $post, $product);
													
													endif;
													
													?>
												
												</div>
											
											<?php endif; ?>
											
											<a href="<?php the_permalink(); ?>" class="link-overlay"></a>
											
											<?php
											
											echo FSD_Helper::render_image($image_id,
													'fs-vertical-size-medium',
													['sizes' => implode(',', [
															'(max-width: 300px) 300px',
															'(max-width: 540px) 540px',
															'(max-width: 768px) 768px',
													]),
															'srcset' => implode(',', [
																	esc_url(wp_get_attachment_image_url($image_id, 'fs-vertical-size-extra-small')) . ' 300w',
																	esc_url(wp_get_attachment_image_url($image_id, 'fs-vertical-size-small')) . ' 540w',
																	esc_url(wp_get_attachment_image_url($image_id, 'fs-vertical-size-medium')) . ' 768w',
															]),
															'loading' => 'lazy',
															'class' => 'wp-image-slider',
															'alt' => get_the_title()
													], false);
											
											$product_id = $product->get_id();
											
											if (\Elementor\Plugin::$instance->editor->is_edit_mode()) :
												
												$product_cart_id = 0;
											
											else:
												
												$product_cart_id = WC()->cart->generate_cart_id($product_id);
											
											endif;
											
											$quick_actions = get_theme_mod('shop-quick-actions-overlay', 1);
											
											?>
											
											<?php if (!empty($quick_actions) && !\Elementor\Plugin::$instance->editor->is_edit_mode()): ?>
												
												<div class="buttons-overlay">
													
													<a class="fs-add-to-cart-button <?php echo esc_attr($product->get_type()) ?> fs-button dark-border-style <?php if (WC()->cart->find_product_in_cart($product_cart_id)): ?> already-in-cart <?php endif; ?>"
													   <?php if (WC()->cart->find_product_in_cart($product_cart_id)): ?>href="<?php echo esc_url(wc_get_cart_url()); ?>" <?php elseif ((!$product->is_in_stock() || $product->get_type() !== 'simple') && $product->get_type() !== 'external'): ?> href="<?php echo esc_url(get_permalink($product_id)); ?>" <?php elseif ($product->get_type() === 'external' && !empty($product->get_product_url())): ?> href="<?php echo esc_url($product->get_product_url()); ?>" <?php endif; ?>
													   data-href="<?php echo esc_url(wc_get_cart_url()); ?>">
														
														<div class="def-st">
															
															<?php
															
															if (WC()->cart->find_product_in_cart($product_cart_id)):
																
																echo esc_html__('View Cart', 'levre');
															
															elseif (!$product->is_in_stock()):
																
																echo esc_html__('Read More', 'levre');
															
															else:
																
																if ($product->get_type() !== 'variable' && $product->get_type() !== 'external'):
																	
																	?>
																	
																	<svg class="left-ic" width="13" height="13"
																	     viewBox="0 0 13 13" fill="none"
																	     xmlns="http://www.w3.org/2000/svg">
																		<path fill-rule="evenodd" clip-rule="evenodd"
																		      d="M7 6L7 0L6 0L6 6L0 6L0 7L6 7V13H7V7L13 7V6L7 6Z"
																		      fill="black" />
																	</svg>
																
																<?php
																
																endif;
																
																echo esc_html($product->add_to_cart_text());
																
																if ($product->get_type() === 'variable' || $product->get_type() === 'external'):
																	
																	?>
																	
																	<svg class="right-ic" width="17" height="11"
																	     viewBox="0 0 17 11" fill="none"
																	     xmlns="http://www.w3.org/2000/svg">
																		<path d="M0 5H15.5C15.7761 5 16 5.22386 16 5.5C16 5.77614 15.7761 6 15.5 6H0V5Z"
																		      fill="black" />
																		<path fill-rule="evenodd" clip-rule="evenodd"
																		      d="M11.5 0.5L10.7929 1.20711L15.0355 5.44975L10.7929 9.69239L11.5 10.3995L15.7426 6.15685L16.4497 5.44975L15.7426 4.74264L11.5 0.5Z"
																		      fill="black" />
																	</svg>
																
																<?php
																
																endif;
															
															endif;
															
															?>
														
														</div>
														
														<div class="load-st">
															
															<svg width="20" height="20" viewBox="0 0 24 24"
															     xmlns="http://www.w3.org/2000/svg">
																<style>.spinner_0XTQ {
																		transform-origin: center;
																		animation: spinner_y6GP .75s linear infinite
																	}
																	
																	@keyframes spinner_y6GP {
																		100% {
																			transform: rotate(360deg)
																		}
																	}</style>
																<path class="spinner_0XTQ"
																      d="M12,23a9.63,9.63,0,0,1-8-9.5,9.51,9.51,0,0,1,6.79-9.1A1.66,1.66,0,0,0,12,2.81h0a1.67,1.67,0,0,0-1.94-1.64A11,11,0,0,0,12,23Z"
																      fill="#fff" />
															</svg>
														
														</div>
														
														<div class="already-in-state">
															
															<?php echo esc_html__('View Cart', 'levre'); ?>
														
														</div>
													
													</a>
													
													<?php
													
													echo do_shortcode('[ti_wishlists_addtowishlist product_id="' . $product_id . '"]');
													
													?>
												
												</div>
											
											<?php endif; ?>
										
										</div>
										
										<div class="card-body">
											
											<div class="responsive-rating">
												
												<?php echo wc_get_rating_html($product->get_average_rating()); ?>
											
											</div>
											
											<?php if (!empty($title)): ?>
												
												<p class="card-title body-5">
													
													<a href="<?php the_permalink(); ?>">
														
														<?php echo esc_html(wp_trim_words($title, $title_output_length, '...')); ?>
													
													</a>
												
												</p>
											
											<?php endif; ?>
											
											<?php if (!empty($product->get_price_html())): ?>
												
												<p class="price">
													
													<?php echo $product->get_price_html(); ?>
												
												</p>
											
											<?php endif; ?>
										
										</div>
									
									</div>
								
								</article>
							
							<?php
							
							endif;
						
						endwhile;
						
						?>
					
					</div>
					
					<div class="posts-slider-scrollbar <?php if ($settings['scrollbar'] !== 'yes'): ?>hidden<?php endif; ?>">
					
					</div>
					
					<?php if ($settings['arrows'] === 'yes' && $settings['arrows_position'] === 'inside'): ?>
						
						<div class="posts-slider-navigation <?php echo esc_attr($settings['arrows_position']); ?>">
							
							<div class="navigation-button navigation-button-prev">
								
								<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
								     alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">
							
							</div>
							
							<div class="navigation-button navigation-button-next">
								
								<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
								     alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">
							
							</div>
						
						</div>
					
					<?php endif; ?>
				
				</div>
				
				<?php if ($settings['arrows'] === 'yes' && $settings['arrows_position'] === 'outside'): ?>
					
					<div class="posts-slider-navigation <?php echo esc_attr($settings['arrows_position']); ?>">
						
						<div class="navigation-button navigation-button-prev">
							
							<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
							     alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">
						
						</div>
						
						<div class="navigation-button navigation-button-next">
							
							<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-forward.svg'); ?>"
							     alt="<?php echo esc_attr__('Arrow Forward', 'levre'); ?>">
						
						</div>
					
					</div>
				
				<?php endif; ?>
			
			</div>
		
		</div>
		
		<?php
		
	}
	
}