<?php defined('ABSPATH') || exit;

/**
 * Class FS_Hero_Slider_Widget
 */
class FS_Hero_Slider_Widget extends \Elementor\Widget_Base
{

    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-hero-slider';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Hero Slider', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-header';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'hero_options',
            [
                'label' => __('Hero Options', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'hero_effect',
            [
                'label' => __('Slider Effect', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => false,
                'default' => 'fade',
                'description' => __('Select the slider effect', 'fs-core'),
                'options' => [
                    'slide' => __('Slide', 'fs-core'),
                    'fade' => __('Fade', 'fs-core'),
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'hero_image',
            [
                'label' => __('Hero Image', 'fs-core'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'hero_title',
            [
                'label' => __('Hero Title', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Hero Title', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'hero_subtitle',
            [
                'label' => __('Hero Subtitle', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Hero Subtitle', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'first_button_text',
            [
                'label' => __('First Button Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('First Button Text', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'first_button_url',
            [
                'label' => __('First Button URL', 'fs-core'),
                'type' => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'second_button_text',
            [
                'label' => __('Second Button Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('First Button Text', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'second_button_url',
            [
                'label' => __('Second Button URL', 'fs-core'),
                'type' => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'slider',
            [
                'label' => __('Hero Slider', 'fs-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Enable', 'your-plugin'),
                'label_off' => __('Disable', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_delay',
            [
                'label' => __('Autoplay Delay', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10000,
                        'step' => 1
                    ],
                ],
                'default' => [
                    'size' => 3000,
                ],
                'condition' => [
                    'autoplay' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'arrows',
            [
                'label' => __('Arrows', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Enable', 'your-plugin'),
                'label_off' => __('Disable', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'arrows_size',
            [
                'label' => __('Arrows Size', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 75,
                ],
                'condition' => [
                    'arrows' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'pagination',
            [
                'label' => __('Pagination', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Enable', 'your-plugin'),
                'label_off' => __('Disable', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        $arrows = $settings['arrows'];

        $arrows_size = $settings['arrows_size'] ? $settings['arrows_size'] : 75;

        $pagination = $settings['pagination'];

        $autoplay = $settings['autoplay'];

        $autoplay_delay = $settings['autoplay_delay'];

        ?>

        <header class="hero-slider-scene"
                <?php if ($autoplay): ?>data-autoplay="<?php echo esc_attr($autoplay_delay['size']); ?>"<?php endif; ?>>

            <div class="inner-wrapper">

                <?php if ($arrows === 'yes'): ?>

                    <div class="navigation-button navigation-button-prev">

                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow_left.svg') ?>"
                             alt="<?php echo esc_attr__('Arrow Icon', 'fs-core'); ?>"
                             style="width: <?php echo esc_html($arrows_size['size']); ?>px;">

                    </div>

                <?php endif; ?>

                <div class="swiper-container hero-slider"
                     data-effect="<?php echo esc_attr($settings['hero_effect']); ?>">

                    <div class="swiper-wrapper">

                        <?php

                        foreach ($settings['slider'] as $item) :

                            $hero_image = $item['hero_image'];

                            $hero_title = $item['hero_title'];

                            $hero_subtitle = $item['hero_subtitle'];

                            $first_button_text = $item['first_button_text'];

                            $first_button_url = $item['first_button_url'];

                            $second_button_text = $item['second_button_text'];

                            $second_button_url = $item['second_button_url'];

                            ?>

                            <div class="swiper-slide"
                                 style="background-image: url(<?php echo esc_url($hero_image['url']); ?>)">

                                <div class="content-wrapper">

                                    <h1 class="title">

                                        <?php echo esc_html($hero_title); ?>

                                    </h1>

                                    <p class="subtitle">

                                        <?php echo esc_html($hero_subtitle); ?>

                                    </p>

                                    <div class="button-wrapper">

                                        <?php if (!empty($first_button_text)): ?>

                                            <a href="<?php echo esc_url($first_button_url['url']); ?>"
                                               class="fs-button dark-style">

                                                <?php echo esc_html($first_button_text); ?>

                                            </a>

                                        <?php endif; ?>


                                        <?php if (!empty($second_button_text)): ?>

                                            <a href="<?php echo esc_url($second_button_url['url']); ?>"
                                               class="fs-button dark-border-style">

                                                <?php echo esc_html($second_button_text); ?>

                                            </a>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                        <?php

                        endforeach;

                        ?>

                    </div>

                    <?php if ($pagination === 'yes'): ?>

                        <div class="pagination-wrapper hero-slider-pagination">

                        </div>

                    <?php endif; ?>

                </div>

                <?php if ($arrows === 'yes'): ?>

                    <div class="navigation-button navigation-button-next">

                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow_right.svg') ?>"
                             alt="<?php echo esc_attr__('Arrow Icon', 'fs-core'); ?>"
                             style="width: <?php echo esc_html($arrows_size['size']); ?>px;">

                    </div>

                <?php endif; ?>

            </div>

        </header>

        <?php

    }
}
