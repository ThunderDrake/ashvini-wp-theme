<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Button_Widget
 */
class FS_Paroller_Widget extends \Elementor\Widget_Base
{
    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-paroller';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Paroller Image', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-image';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => __('Choose Image', 'fs-core'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_responsive_control(
            'paroller_direction',
            [
                'label' => __('Paroller Direction', 'elementor'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'vertical' => [
                        'title' => __('Vertical', 'elementor'),
                        'icon' => 'eicon-navigation-vertical',
                    ],
                    'horizontal' => [
                        'title' => __('Horizontal', 'elementor'),
                        'icon' => 'eicon-navigation-horizontal',
                    ],
                ],
                'default' => 'vertical',
            ]
        );

        $this->add_control(
            'paroller_factor',
            [
                'label' => __('Paroller Factor', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10,
                ],
            ]
        );

        $this->add_control(
            'paroller_factor_xs',
            [
                'label' => __('Paroller Factor XS', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10,
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        $settings = $this->get_settings();

        $image = $settings['image'];

        $image_url = wp_get_attachment_image_url($image['id'], 'full');

        if (!empty($image_url)):

            ?>

            <img class="paroller-image" src="<?php echo esc_url($image_url); ?>"
                 data-paroller-factor="<?php echo esc_attr($settings['paroller_factor']['size'] / 100); ?>"
                 data-paroller-factor-xs="<?php echo esc_attr($settings['paroller_factor_xs']['size'] / 100); ?>"
                 data-paroller-direction="<?php echo esc_attr($settings['paroller_direction']); ?>"
                 data-paroller-type="foreground" alt="<?php echo esc_attr__('Paroller Image', 'fs-core'); ?>">

        <?php

        endif;

    }
}
