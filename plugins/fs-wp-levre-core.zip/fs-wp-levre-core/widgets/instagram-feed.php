<?php defined('ABSPATH') || exit;

/**
 * Class FS_Instagram_Feed_Widget
 */
class FS_Instagram_Feed_Widget extends \Elementor\Widget_Base
{

    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-instagram-feed';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Instagram Feed', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-instagram-gallery';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'cf7_form_options',
            [
                'label' => __('CF7 Options', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'instagram_shortcode',
            [
                'label' => __('Shortcode', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

    }

    /* Render */
    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        ?>

        <div class="instagram-feed-main-wrapper">

            <?php

            echo do_shortcode($settings['instagram_shortcode']);

            ?>

        </div>

        <?php

    }
}
