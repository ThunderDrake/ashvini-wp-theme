<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Button_Widget
 */
class FS_Button_Widget extends \Elementor\Widget_Base
{
    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-button';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Button', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-button';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'button_style',
            [
                'label' => __('Button Style', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'default-style' => __('Default Style', 'fs-core'),
                    'default-border-style' => __('Default Border Style', 'fs-core'),
                    'dark-style' => __('Dark Style', 'fs-core'),
                    'dark-border-style' => __('Dark Border Style', 'fs-core'),
                    'link-style' => __('Link Style', 'fs-core'),
                    'link-arrow-style' => __('Link Arrow Style', 'fs-core'),
                ],
                'default' => 'default-style'
            ]
        );
        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Placeholder', 'fs-core'),
                'placeholder' => __('Placeholder', 'fs-core'),
            ]
        );
        $this->add_control(
            'button_link',
            [
                'label' => __('Button Link', 'fs-core'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('', 'fs-core'),
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );
        $this->add_control(
            'target_type',
            [
                'label' => __('Target type', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'description' => __('Select the type of target, depending on the value, the link will be opened in the current window (_self) or in a new one (_blank)', 'fs-core'),
                'multiple' => false,
                'options' => [
                    '_self' => __('Self', 'fs-core'),
                    '_blank' => __('Blank', 'fs-core'),
                ],
                'default' => '_self',
            ]
        );
        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        if ($settings['button_style'] === 'default-style'):

            ?>

            <div class="button-wrapper">

                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                   class="fs-button default-style"
                   target="<?php echo esc_attr($settings['target_type']); ?>">

                    <?php echo esc_html($settings['button_text']); ?>

                </a>

            </div>

        <?php

        elseif ($settings['button_style'] === 'default-border-style'):

            ?>

            <div class="button-wrapper">

                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                   class="fs-button default-border-style"
                   target="<?php echo esc_attr($settings['target_type']); ?>">

                    <?php echo esc_html($settings['button_text']); ?>

                </a>

            </div>

        <?php

        elseif ($settings['button_style'] === 'dark-style'):

            ?>

            <div class="button-wrapper">

                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                   class="fs-button dark-style"
                   target="<?php echo esc_attr($settings['target_type']); ?>">

                    <?php echo esc_html($settings['button_text']); ?>

                </a>

            </div>

        <?php

        elseif ($settings['button_style'] === 'dark-border-style'):

            ?>

            <div class="button-wrapper">

                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                   class="fs-button dark-border-style"
                   target="<?php echo esc_attr($settings['target_type']); ?>">

                    <?php echo esc_html($settings['button_text']); ?>

                </a>

            </div>

        <?php

        elseif ($settings['button_style'] === 'link-style'):

            ?>

            <div class="button-wrapper">

                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                   class="fs-link"
                   target="<?php echo esc_attr($settings['target_type']); ?>">

                    <?php echo esc_html($settings['button_text']); ?>

                </a>

            </div>

        <?php

        elseif ($settings['button_style'] === 'link-arrow-style'):

            ?>

            <div class="button-wrapper">

                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                   class="fs-link with-icon"
                   target="<?php echo esc_attr($settings['target_type']); ?>">

                    <?php echo esc_html($settings['button_text']); ?>

                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow.svg') ?>"
                         alt="<?php echo esc_attr__('Arrow Icon', 'fs-core'); ?>">

                </a>

            </div>

        <?php

        endif;

    }
}
