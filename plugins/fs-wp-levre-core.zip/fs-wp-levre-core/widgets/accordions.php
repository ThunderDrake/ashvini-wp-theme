<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Accordion
 */
class FS_Accordion extends \Elementor\Widget_Base
{

    /**
     * @return string
     */
    public function get_name()
    {

        return 'fs-accordion';

    }

    /**
     * @return string|void
     */
    public function get_title()
    {

        return __('Accordion', 'fs-core');

    }

    /**
     * @return string
     */
    public function get_icon()
    {

        return 'eicon-accordion';

    }

    /**
     * @return array
     */
    public function get_categories()
    {

        return ['fs-widgets'];

    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'accordion_title',
            [
                'label' => __('Title', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Accordion Title', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'accordion_content',
            [
                'label' => __('Content', 'fs-core'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Accordion Content', 'fs-core'),
                'show_label' => false,
            ]
        );

        $this->add_control(
            'accordion',
            [
                'label' => __('Accordion', 'fs-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'accordion_title' => __('Accordion title', 'fs-core'),
                        'accordion_content' => __('Item content. Click the edit button to change this text.', 'fs-core'),
                    ],
                    [
                        'accordion_title' => __('Accordion title', 'fs-core'),
                        'accordion_content' => __('Item content. Click the edit button to change this text.', 'fs-core'),
                    ],
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     *
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $counter_trigger = false;

        ?>

        <ul class="fs-accordion">

            <?php foreach ($settings['accordion'] as $item) : ?>

                <li class="accordion-item <?php if (!$counter_trigger): ?> open <?php endif; ?>">

                    <div class="open-link">

                        <p class="accordion-title body-5">

                            <?php echo $item['accordion_title']; ?>

                        </p>

                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/plus.svg'); ?>"
                             alt="<?php echo esc_attr__('Plus', 'levre'); ?>" class="plus-icon">

                    </div>

                    <div class="accordion-content body-6">

                        <?php echo $item['accordion_content']; ?>

                    </div>

                </li>

                <?php $counter_trigger = true; ?>

            <?php endforeach; ?>

        </ul>

        <?php
    }
}
