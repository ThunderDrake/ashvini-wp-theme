<?php if (!defined('ABSPATH')) : exit; endif;

/**
 * Class FS_Featured_Product_Categories_Widget
 */
class FS_Featured_Product_Categories_Widget extends \Elementor\Widget_Base
{
    /**
     * @return string
     */
    public function get_name()
    {
        return 'fs-featured-product-categories';
    }

    /**
     * @return string|void
     */
    public function get_title()
    {
        return __('Featured Product Categories', 'fs-core');
    }

    /**
     * @return string
     */
    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    /**
     * @return array
     */
    public function get_categories()
    {
        return ['fs-widgets'];
    }

    /**
     *
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'grid_options',
            [
                'label' => __('Grid Options', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'grid_style',
            [
                'label' => __('Grid Style', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'style-1' => __('Style 1', 'fs-core'),
                    'style-2' => __('Style 2', 'fs-core'),
                    'style-3' => __('Style 3', 'fs-core'),
                    'style-4' => __('Style 4', 'fs-core'),
                ],
                'default' => 'style-1'
            ]
        );

        $terms = get_terms(
            array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
            )
        );

        $settings = array();

        if (!empty($terms)):

            foreach ($terms as $category):

                if (!empty($category) && !empty($category->name) && !empty($category->slug)):

                    $name = $category->name;

                    $slug = $category->slug;

                    $settings[$slug] = $name;

                endif;

            endforeach;

        endif;

        if (!empty($settings)):

            $this->add_control(
                'category_1',
                [
                    'label' => __('Category №1', 'fs-core'),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'description' => __('Select the category №1', 'fs-core'),
                    'options' => $settings,
                ]
            );

            $this->add_control(
                'category_2',
                [
                    'label' => __('Category №2', 'fs-core'),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'description' => __('Select the category №2', 'fs-core'),
                    'options' => $settings,
                ]
            );

            $this->add_control(
                'category_3',
                [
                    'label' => __('Category №3', 'fs-core'),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'description' => __('Select the category №3', 'fs-core'),
                    'options' => $settings,
                ]
            );

            $this->add_control(
                'category_4',
                [
                    'label' => __('Category №4', 'fs-core'),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'description' => __('Select the category №4', 'fs-core'),
                    'options' => $settings,
                    'condition' => [
                        'grid_style' => ['style-1', 'style-2', 'style-4']
                    ],
                ]
            );

        endif;

        $this->add_control(
            'grid_item_button_text',
            [
                'label' => __('Item Link Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View', 'fs-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Title', 'fs-core'),
                'label_block' => true,
                'condition' => [
                    'grid_style' => 'style-3'
                ],
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Subtitle', 'fs-core'),
                'label_block' => true,
                'condition' => [
                    'grid_style' => 'style-3'
                ],
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Button Text', 'fs-core'),
                'label_block' => true,
                'condition' => [
                    'grid_style' => 'style-3'
                ],
            ]
        );

        $this->add_control(
            'button_url',
            [
                'label' => __('Button URL', 'fs-core'),
                'type' => \Elementor\Controls_Manager::URL,
                'label_block' => true,
                'condition' => [
                    'grid_style' => 'style-3'
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        wp_reset_postdata();

        $settings = $this->get_settings_for_display();

        $id = $this->get_id();

        $style = $settings['grid_style'];

        $classes = array();

        array_push($classes, $style);

        $terms = array();

        if (!empty($settings['category_1'])):

            array_push($terms, $settings['category_1']);

        endif;

        if (!empty($settings['category_2'])):

            array_push($terms, $settings['category_2']);

        endif;

        if (!empty($settings['category_3'])):

            array_push($terms, $settings['category_3']);

        endif;

        if (!empty($settings['category_4'])):

            array_push($terms, $settings['category_4']);

        endif;

        ?>

        <div class="featured-product-categories <?php echo esc_attr(implode($classes)); ?>">

            <div class="inner-wrapper">

                <div class="categories-grid">

                    <?php

                    if ($style === 'style-3'):

                        $title = $settings['title'];

                        $subtitle = $settings['subtitle'];

                        $button_text = $settings['button_text'];

                        $button_url = $settings['button_url'];

                        ?>

                        <div class="category-item text-item">

                            <div class="item-inner">

                                <div class="content-item">

                                    <?php if (!empty($title)): ?>

                                        <h1 class="info-title">

                                            <?php echo esc_html($title); ?>

                                        </h1>

                                    <?php endif; ?>

                                    <?php if (!empty($subtitle)): ?>

                                        <p class="subtitle">

                                            <?php echo esc_html($subtitle); ?>

                                        </p>

                                    <?php endif; ?>

                                    <?php if (!empty($button_text)): ?>

                                        <a <?php if (!empty($button_url['url'])): ?> href="<?php echo esc_url($button_url['url']); ?>" <?php endif; ?>
                                                class="fs-button dark-border-style">

                                            <?php echo esc_html($button_text); ?>

                                        </a>

                                    <?php endif; ?>

                                </div>

                            </div>

                        </div>

                    <?php

                    endif;

                    if (!empty($terms)):

                        foreach ($terms as $term):

                            if (!empty($term)):

                                $category = get_term_by('slug', $term, 'product_cat');

                                if (!empty($category)):

                                    if (!empty($category->term_id)):

                                        $term_id = $category->term_id;

                                        $name = $category->name;

                                        $slug = $category->slug;

                                        $additional_image_id = FSD_Helper::get_field('field_product_category_additional_image', 'product_cat_' . $term_id);

                                        $thumbnail_id = get_term_meta($term_id, 'thumbnail_id', true);

                                        ?>

                                        <div class="category-item">

                                            <div class="item-inner">

                                                <a href="<?php echo esc_url(get_term_link($term_id)); ?>"
                                                   class="link-overlay"></a>

                                                <div class="thumbnail-image">

                                                    <?php

                                                    if ($style === 'style-1'):

                                                        echo FSD_Helper::render_image($thumbnail_id,
                                                            'fs-vertical-size-medium',
                                                            array('sizes' => implode(',', array(
                                                                '(max-width: 300px) 300px',
                                                                '(max-width: 540px) 540px',
                                                                '(max-width: 768px) 768px',
                                                            )),
                                                                'srcset' => implode(',', array(
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-vertical-size-extra-small')) . ' 300w',
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-vertical-size-small')) . ' 540w',
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-vertical-size-medium')) . ' 768w',
                                                                )),
                                                                'loading' => 'lazy',
                                                                'alt' => $name
                                                            ), false);

                                                        echo FSD_Helper::render_image($additional_image_id,
                                                            'fs-vertical-size-medium',
                                                            array('sizes' => implode(',', array(
                                                                '(max-width: 300px) 300px',
                                                                '(max-width: 540px) 540px',
                                                                '(max-width: 768px) 768px',
                                                            )),
                                                                'srcset' => implode(',', array(
                                                                    esc_url(wp_get_attachment_image_url($additional_image_id, 'fs-vertical-size-extra-small')) . ' 300w',
                                                                    esc_url(wp_get_attachment_image_url($additional_image_id, 'fs-vertical-size-small')) . ' 540w',
                                                                    esc_url(wp_get_attachment_image_url($additional_image_id, 'fs-vertical-size-medium')) . ' 768w',
                                                                )),
                                                                'loading' => 'lazy',
                                                                'alt' => $name
                                                            ), false);

                                                    endif;

                                                    if ($style === 'style-2' || $style === 'style-4'):

                                                        echo FSD_Helper::render_image($thumbnail_id,
                                                            'fs-square-size-large',
                                                            array('sizes' => implode(',', array(
                                                                '(max-width: 300px) 300px',
                                                                '(max-width: 540px) 540px',
                                                                '(max-width: 768px) 768px',
                                                                '(max-width: 1024px) 1024px',
                                                            )),
                                                                'srcset' => implode(',', array(
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-extra-small')) . ' 300w',
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-small')) . ' 540w',
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-medium')) . ' 768w',
                                                                    esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-large')) . ' 1024w',
                                                                )),
                                                                'loading' => 'lazy',
                                                                'alt' => $name
                                                            ), false);

                                                    endif;

                                                    if ($style === 'style-3'):

                                                        if (!empty($thumbnail_id)):

                                                            echo FSD_Helper::render_image($thumbnail_id,
                                                                'fs-square-size-large',
                                                                array('sizes' => implode(',', array(
                                                                    '(max-width: 300px) 300px',
                                                                    '(max-width: 540px) 540px',
                                                                    '(max-width: 768px) 768px',
                                                                    '(max-width: 1024px) 1024px',
                                                                )),
                                                                    'srcset' => implode(',', array(
                                                                        esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-extra-small')) . ' 300w',
                                                                        esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-small')) . ' 540w',
                                                                        esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-medium')) . ' 768w',
                                                                        esc_url(wp_get_attachment_image_url($thumbnail_id, 'fs-square-size-large')) . ' 1024w',
                                                                    )),
                                                                    'loading' => 'lazy',
                                                                    'alt' => $name
                                                                ), false);

                                                        endif;

                                                    endif;

                                                    ?>

                                                </div>

                                                <div class="content-item">

                                                    <div class="title-wrapper">

                                                        <?php if (!empty($name)): ?>

                                                            <h2 class="title">

                                                                <?php echo esc_html($name); ?>

                                                            </h2>

                                                        <?php endif; ?>

                                                        <?php if ($style === 'style-3'):

                                                            $category_description = FSD_Helper::get_field('field_product_category_description', 'product_cat_' . $term_id);

                                                            if (!empty($category_description)):

                                                                ?>

                                                                <p class="category-description">

                                                                    <?php echo esc_html($category_description); ?>

                                                                </p>

                                                            <?php endif; ?>

                                                        <?php endif; ?>

                                                    </div>

                                                    <p class="fs-link with-icon">

                                                        <?php if (!empty($settings['grid_item_button_text'])): ?>

                                                            <?php echo esc_html($settings['grid_item_button_text']); ?>

                                                        <?php endif; ?>

                                                        <?php if ($style === 'style-3' || $style === 'style-4'): ?>

                                                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow-white.svg') ?>"
                                                                 alt="<?php echo esc_attr__('Arrow Icon', 'fs-core'); ?>">

                                                        <?php else: ?>

                                                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/arrow.svg') ?>"
                                                                 alt="<?php echo esc_attr__('Arrow Icon', 'fs-core'); ?>">

                                                        <?php endif; ?>

                                                    </p>

                                                </div>

                                            </div>

                                        </div>

                                    <?php

                                    endif;

                                endif;

                            endif;

                        endforeach; ?>

                    <?php endif; ?>

                </div>

            </div>

        </div>

        <?php

        wp_reset_postdata();

    }
}
