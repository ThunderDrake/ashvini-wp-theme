<?php if (!defined('ABSPATH')) : exit; endif;

use Elementor\Plugin;

/**
 * Class FS_Content_Tabs
 */
class FS_Content_Tabs extends \Elementor\Widget_Base
{

    /**
     * @return string
     */
    public function get_name()
    {

        return 'fs-content-tabs';

    }

    /**
     * @return string|void
     */
    public function get_title()
    {

        return __('Content Tabs', 'fs-core');

    }

    /**
     * @return string
     */
    public function get_icon()
    {

        return 'eicon-tabs';

    }

    /**
     * @return array
     */
    public function get_categories()
    {

        return ['fs-widgets'];

    }

    /**
     *
     */
    protected function register_controls()
    {

        $templates = FSD_Helper::get_elementor_templates('section');

        $formatted_templates = array();

        $formatted_templates['none'] = esc_html__('None', 'fs-core');

        if(!empty($templates)):

        foreach ($templates as $template):

            $formatted_templates[$template['template_id']] = $template['title'];

        endforeach;

        endif;

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'label' => __('Title', 'fs-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('tab Title', 'fs-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tab_content',
            [
                'label' => __('Content', 'fs-core'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'show_label' => false,
            ]
        );

        if(!empty($formatted_templates)):

        $repeater->add_control(
            'tab_elementor_template',
            [
                'label' => __('OR Elementor Template', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $formatted_templates,
                'default' => 'none'
            ]
        );

        endif;

        $this->add_control(
            'tab',
            [
                'label' => __('Tab', 'fs-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tab_title' => __('Tab Title', 'fs-core'),
                    ],
                    [
                        'tab_title' => __('Tab title', 'fs-core'),
                    ],
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     *
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $header_trigger = false;

        $content_trigger = false;

        ?>

        <div class="fs-content-tab">

            <ul class="tabs-header">

                <?php foreach ($settings['tab'] as $item) : ?>

                    <?php

                    $item_title = $item['tab_title'];

                    ?>

                    <li class="header-item body-7 <?php if (!$header_trigger): ?> active <?php endif; ?>">

                        <?php echo esc_html($item_title); ?>

                    </li>

                    <?php

                    $header_trigger = true;

                    ?>

                <?php endforeach; ?>

            </ul>

            <div class="tabs-content">

                <?php foreach ($settings['tab'] as $item) : ?>

                    <div class="tab-content <?php if (!$content_trigger): ?> active <?php endif; ?>">

                        <?php

                        $tab_content = $item['tab_content'];

                        $tab_elementor_template = $item['tab_elementor_template'];

                        if (!empty($tab_elementor_template) && $tab_elementor_template !== 'none'):

                            echo Plugin::$instance->frontend->get_builder_content($tab_elementor_template);

                        elseif (!empty($tab_content)):

                            echo $tab_content;

                        endif; ?>

                    </div>

                    <?php

                    $content_trigger = true;

                    ?>

                <?php endforeach; ?>

            </div>

        </div>

        <?php
    }
}
