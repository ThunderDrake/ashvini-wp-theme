<?php defined('ABSPATH') || exit;

/**
 * Plugin Name: Levre Core Plugin
 * Description: Core plugin for Levre Theme
 * Version: 4.3
 * Author: firstsight_design
 * Author URI: https://themeforest.net/user/firstsight_design
 * Text Domain: fs-core
 */

/* include external modules */
include_once('vendor/entry.php');

/* include plugin modules */
include_once('modules/entry.php');

/* create new core plugin instance */
new FSD_Core(array(
    /* plugin name */
    'name' => esc_html('Levre Core Plugin'),
    /* plugin slug */
    'slug' => 'fs-core',
    /* plugin prefix */
    'prefix' => 'fs-',
    /* plugin version */
    'version' => '3.2',
    /* minimum php version */
    'minimum_php_version' => '7.0',
    /* plugin path */
    'plugin_path' => plugin_dir_path(__FILE__),
    /* plugin url */
    'plugin_url' => plugin_dir_url(__FILE__),
));
