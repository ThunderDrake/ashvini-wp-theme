<?php defined('ABSPATH') || exit;

/**
 * Class FSD_Career
 */
class FSD_Career extends FSD_Core
{

    /**
     * fs_portfolio constructor.
     */
    public function __construct()
    {

        /* init portfolio */
        $this->init();

        $this->settings();

    }

    /**
     * init
     */
    public function init()
    {

        /* register career post type */
        register_post_type('career', [
            'label' => null,
            'labels' => [
                'name' => esc_html__('Career', 'jk-core'),
                'singular_name' => esc_html__('Item', 'jk-core'),
                'add_new' => esc_html__('Add New', 'jk-core'),
                'add_new_item' => esc_html__('Add New Position', 'jk-core'),
                'edit_item' => esc_html__('Edit Position', 'jk-core'),
                'new_item' => esc_html__('New Position', 'jk-core'),
                'view_item' => esc_html__('View Position', 'jk-core'),
                'search_items' => esc_html__('Search Position', 'jk-core'),
                'not_found' => esc_html__('Not Found', 'jk-core'),
                'not_found_in_trash' => esc_html__('Not Found in Trash', 'jk-core'),
                'menu_name' => esc_html__('Career', 'jk-core'),
            ],
            'description' => '',
            'public' => true,
            'show_in_menu' => null,
            'show_in_rest' => false,
            'rest_base' => null,
            'menu_position' => null,
            'menu_icon' => 'dashicons-groups',
            'hierarchical' => true,
            'supports' => ['title', 'editor', 'author', 'thumbnail', 'excerpt',],
            'taxonomies' => array(),
            'has_archive' => false,
            'query_let' => true,
            'rewrite' => array('slug' => 'career'),
        ]);

    }

    
    public function settings()
    {

        if (function_exists('acf_add_local_field_group')):

            acf_add_local_field_group(array(
                'key' => 'group_career_settings',
                'title' => __('Position Options', 'fs-core'),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'career',
                        ),
                    ),
                ),
                'position' => 'side',
            ));

        endif;

        if (function_exists('acf_add_local_field')):

            acf_add_local_field(array(
                'key' => 'field_position_location',
                'label' => esc_html('Event Location'),
                'name' => 'option_position_location',
                'type' => 'text',
                'instructions' => esc_html__('Input position location', 'fs-core'),
                'required' => 0,
                'conditional_logic' => 0,
                'parent' => 'group_career_settings',
            ));

            acf_add_local_field(array(
                'key' => 'field_position_apply_now_button_text',
                'label' => esc_html('Apply Now Button Text'),
                'name' => 'option_position_apply_now_button_text',
                'type' => 'text',
                'instructions' => esc_html__('Input apply now button text', 'fs-core'),
                'required' => 0,
                'conditional_logic' => 0,
                'parent' => 'group_career_settings',
            ));

            acf_add_local_field(array(
                'key' => 'field_position_apply_now_button_link',
                'label' => esc_html('Apply Now Button Link'),
                'name' => 'option_position_apply_now_button_link',
                'type' => 'text',
                'instructions' => esc_html__('Input apply now button link', 'fs-core'),
                'required' => 0,
                'conditional_logic' => 0,
                'parent' => 'group_career_settings',
            ));

            acf_add_local_field(array(
                'key' => 'field_position_apply_now_successful_link',
                'label' => esc_html('Successful Link'),
                'name' => 'option_position_apply_now_successful_link',
                'type' => 'text',
                'instructions' => esc_html__('Input successful link', 'fs-core'),
                'required' => 0,
                'conditional_logic' => 0,
                'parent' => 'group_career_settings',
            ));

        endif;

    }

}