<?php defined('ABSPATH') || exit;

/**
 * Class FSD_Helper
 */
class FSD_Helper extends FSD_Core
{

    /**
     * @return mixed|string
     */
    public static function get_page_title()
    {

        $title = wp_get_document_title();

        if (is_date()):

            if (is_year()):

                $title = get_query_var('year');

            elseif (is_month()):

                $title = DateTime::createFromFormat('m', get_query_var('monthnum'))->format('F') . ' ';

                $title = get_query_var('year');

            elseif (is_day()):

                $title = DateTime::createFromFormat('m', get_query_var('monthnum'))->format('F') . ' ';

                $title .= DateTime::createFromFormat('d', get_query_var('day'))->format('d') . ', ';

                $title .= get_query_var('year');

            endif;

        endif;

        if (!empty($title)):

            return $title;

        endif;

    }

    /**
     * Get Elementor templates
     *
     * @param string $type type of templates
     *
     * @return array of Elementor templates
     * @since 1.0.0
     * @access public
     * @static
     *
     */
    public static function get_elementor_templates($type = 'section')
    {

        if (!function_exists('elementor_pro_load_plugin')):

            $templates = \Elementor\Plugin::$instance->templates_manager->get_source('local')->get_items([
                'type' => 'section',
            ]);

        else:

            $templates = array();

        endif;

        if ($templates):

            return $templates;

        else:

            return get_option('fs_elementor_templates');

        endif;

    }

    /**
     * @param $instance
     */
    public static function the_post_controls($instance)
    {

        $categories_all = get_categories(array(
            'taxonomy' => 'category',
            'type' => 'post',
        ));

        $categories = [];

        if ($categories_all):

            foreach ($categories_all as $cat):

                $categories[$cat->name] = $cat->name;

            endforeach;

        endif;

        $tags_all = get_tags();

        $tags = [];

        if ($tags_all):

            foreach ($tags_all as $tag):

                $tags[$tag->name] = $tag->name;

            endforeach;

        endif;

        $users_all = get_users();

        $users = [];

        if ($users_all):

            foreach ($users_all as $user):

                $users[$user->ID] = $user->display_name;

            endforeach;

        endif;

        $instance->start_controls_section(
            'post_options',
            [
                'label' => __('Post Options', 'fs-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $instance->add_control(
            'title_output_length',
            [
                'label' => __('Title length', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'description' => __('The length of the displayed title. NOTE: For some types of widgets, the value should not be too large, as this can damage the appearance of the widget', 'fs-core'),
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 30,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 10,
                ],
            ]
        );

        $instance->add_control(
            'posts_count',
            [
                'label' => __('Show Posts', 'fs-core'),
                'description' => __('Count of displayed posts in the slider', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 2,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 7,
                ],
            ]
        );

        $instance->add_control(
            'posts_sorting',
            [
                'label' => __('Posts Sorting', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => false,
                'default' => 'latest',
                'description' => __('Select the type of slider sorting algorithm by which the slides will be sorted inside the slider', 'fs-core'),
                'options' => [
                    'latest' => __('Latest', 'fs-core'),
                    'random' => __('Random', 'fs-core'),
                ],
            ]
        );

        $instance->add_control(
            'ignore_sticky_toggle',
            [
                'label' => __('Ignore Sticky Post', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Enable', 'fs-core'),
                'label_off' => __('Disable', 'fs-core'),
                'description' => __('If true, sticky posts will be ignored and displayed in a regular queue', 'fs-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $instance->add_control(
            'heading_general_relation',
            [
                'label' => __('General Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $instance->add_control(
            'general_relation',
            [
                'label' => __('General Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'description' => __('Dependencies between the main display types', 'fs-core'),
                'options' => [
                    'AND' => __('AND', 'fs-core'),
                    'OR' => __('OR', 'fs-core'),
                ],
                'default' => 'OR',
                'toggle' => true,
            ]
        );

        $instance->add_control(
            'heading_post_format_relation',
            [
                'label' => __('Post Format Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $instance->add_control(
            'post_formats',
            [
                'label' => __('Post Formats', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'description' => __('Posts of selected post formats will be displayed in the slider', 'fs-core'),
                'multiple' => true,
                'options' => [
                    'standard' => __('Standard', 'fs-core'),
                    'video' => __('Video', 'fs-core'),
                    'gallery' => __('Gallery', 'fs-core'),
                    'quote' => __('Quote', 'fs-core'),
                    'aside' => __('Aside', 'fs-core'),
                    'image' => __('Image', 'fs-core'),
                    'link' => __('Link', 'fs-core'),
                    'audio' => __('Audio', 'fs-core'),
                ],
            ]
        );

        $instance->add_control(
            'heading_category_relation',
            [
                'label' => __('Category Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $instance->add_control(
            'category_relation',
            [
                'label' => __('Category Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'description' => __('Dependencies between categories', 'fs-core'),
                'options' => [
                    'AND' => __('AND', 'fs-core'),
                    'OR' => __('OR', 'fs-core'),
                ],
                'default' => 'OR',
                'toggle' => true,
            ]
        );

        $instance->add_control(
            'post_categories',
            [
                'label' => __('Category', 'fs-core'),
                'description' => __('Posts of selected categories will be displayed in the slider', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
            ]
        );

        $instance->add_control(
            'heading_tag_relation',
            [
                'label' => __('Tag Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $instance->add_control(
            'tag_relation',
            [
                'label' => __('Tag Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'description' => __('Dependencies between tags', 'fs-core'),
                'options' => [
                    'AND' => __('AND', 'fs-core'),
                    'OR' => __('OR', 'fs-core'),
                ],
                'default' => 'OR',
                'toggle' => true,
            ]
        );

        $instance->add_control(
            'post_tags',
            [
                'label' => __('Tag', 'fs-core'),
                'description' => __('Posts of selected tags will be displayed in the slider', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $tags,
            ]
        );

        $instance->add_control(
            'heading_authors_relation',
            [
                'label' => __('Author Relation', 'fs-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $instance->add_control(
            'post_authors',
            [
                'label' => __('Author', 'fs-core'),
                'description' => __('Posts of selected authors will be displayed in the slider', 'fs-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $users,
            ]
        );

        $instance->end_controls_section();

    }

    /**
     * @param $settings
     * @param int $page
     *
     * @return WP_Query
     */
    public static function get_posts_query($settings, $page = 1)
    {

        $args = array(
            'posts_per_page' => $settings['posts_count']['size'],
            'order' => 'DESC',
            'post_type' => 'post',
            'paged' => $page,
            'tax_query' => array(),
        );

        if ($settings['ignore_sticky_toggle']):

            $args['ignore_sticky_posts'] = 1;

        endif;

        if ($settings['posts_sorting'] === 'random'):

            $args['orderby'] = 'rand';

        endif;

        if (isset($settings['posts_grid_archive'])
            && $settings['posts_grid_archive'] === 'yes'
            && !\Elementor\Plugin::$instance->editor->is_edit_mode()):
            if (is_tag() || is_category()):

                $queried_object = get_queried_object();

                $tax_query = array(
                    'taxonomy' => $queried_object->taxonomy,
                    'field' => 'slug',
                    'terms' => $queried_object->slug
                );

                array_push($args['tax_query'], $tax_query);

            elseif (is_date()):

                if (is_year()):

                    $args['year'] = get_query_var('year');

                elseif (is_month()):

                    $args['monthnum'] = get_query_var('monthnum');

                    $args['year'] = get_query_var('year');

                elseif (is_day()):

                    $args['monthnum'] = get_query_var('monthnum');

                    $args['year'] = get_query_var('year');

                    $args['day'] = get_query_var('day');

                endif;

            elseif (is_author()):

                $args['author_name'] = get_query_var('author_name');

            elseif (is_search()):

                $args['s'] = get_query_var('s');

            endif;

        else:

            if ($settings['post_formats'] || $settings['post_categories'] || $settings['post_tags']):

                $args['tax_query'] = array(
                    'relation' => $settings['general_relation'],
                );

            endif;

            if ($settings['post_formats']):

                $post_formats_taxonomy = [];

                $post_formats_array = $settings['post_formats'];

                $post_formats_taxonomy['relation'] = 'OR';

                for ($i = 0; $i < count($post_formats_array); $i++):

                    if ($post_formats_array[$i] !== 'standard'):

                        array_push($post_formats_taxonomy, array(
                            'taxonomy' => 'post_format',
                            'field' => 'slug',
                            'terms' => 'post-format-' . $post_formats_array[$i],
                        ));

                    else:

                        array_push($post_formats_taxonomy, array(
                            'taxonomy' => 'post_format',
                            'operator' => 'NOT EXISTS',
                        ));

                    endif;

                endfor;

                array_push($args['tax_query'], $post_formats_taxonomy);

            endif;

            if ($settings['post_categories']):

                $post_categories_taxonomy = [];

                $post_categories_array = $settings['post_categories'];

                $post_categories_taxonomy['relation'] = $settings['category_relation'];

                for ($i = 0; $i < count($post_categories_array); $i++):

                    array_push($post_categories_taxonomy, array(
                        'taxonomy' => 'category',
                        'field' => 'slug',
                        'terms' => $post_categories_array[$i]
                    ));

                endfor;

                array_push($args['tax_query'], $post_categories_taxonomy);

            endif;

            if ($settings['post_tags']):

                $post_tags_taxonomy = [];

                $post_tags_array = $settings['post_tags'];

                $post_tags_taxonomy['relation'] = $settings['tag_relation'];

                for ($i = 0; $i < count($post_tags_array); $i++):

                    array_push($post_tags_taxonomy, array(
                        'taxonomy' => 'post_tag',
                        'field' => 'slug',
                        'terms' => $post_tags_array[$i]
                    ));

                endfor;

                array_push($args['tax_query'], $post_tags_taxonomy);

            endif;

            if ($settings['post_authors']):

                $post_authors_array = $settings['post_authors'];

                $args['author'] = implode(',', $post_authors_array);

            endif;

        endif;

        $the_query = new WP_Query($args);

        return $the_query;

    }

    /**
     * @return array
     */
    public static function get_cf7()
    {

        $options = array();

        if (function_exists('wpcf7')) :

            $wpcf7_form_list = get_posts(array(
                'post_type' => 'wpcf7_contact_form',
                'posts_per_page' => 999,
            ));

            $options[0] = esc_html__('Select a Contact Form', 'fs-core');

            if (!empty($wpcf7_form_list) && !is_wp_error($wpcf7_form_list)) :

                foreach ($wpcf7_form_list as $post) :

                    $options[$post->ID] = $post->post_title;

                endforeach;

            else :

                $options[0] = esc_html__('Create a Form First', 'fs-core');

            endif;

        endif;

        return $options;

    }

    
    public static function the_breadcrumbs()
    {

        $text['home'] = esc_html__('Home', 'fs-core');

        $text['category'] = '%s';

        $text['search'] = esc_html__('Search results for "%s"', 'fs-core');

        $text['tag'] = esc_html__('Tag "%s"', 'fs-core');

        $text['category'] = esc_html__('Category "%s"', 'fs-core');

        $text['author'] = esc_html__('Posts by "%s"', 'fs-core');

        $text['404'] = esc_html__('Error page', 'fs-core');

        $text['page'] = esc_html__('Page "%s"', 'fs-core');

        $text['cpage'] = esc_html__('Comments page "%s"', 'fs-core');

        $text['blog'] = esc_html__('Blog', 'fs-core');

        $text['shop'] = esc_html__('Shop', 'fs-core');

        $wrap_before = '<div class="fs-breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">';

        $wrap_after = '</div>';

        $sep = '<span class="breadcrumbs-separator">' . '/' . '</span>';

        $before = '<span class="breadcrumbs-current breadcrumbs-item">';

        $after = '</span>';

        $show_on_home = 1;

        $show_home_link = 1;

        $show_current = 1;

        $show_last_sep = 1;

        global $post;

        $home_url = esc_url(home_url('/'));

        $link = '<span itemscope itemtype="http://schema.org/ListItem" class="breadcrumbs-item">';

        $link .= '<a class="breadcrumbs-link" href="%1$s"><span>%2$s</span></a>';

        $link .= '</span>';

        $parent_id = ($post) ? $post->post_parent : '';

        $home_link = sprintf($link, $home_url, $text['home'], 1);

        if (is_home()) :

            if ($show_on_home):

                echo $wrap_before . $home_link . $sep . $before . $text['blog'] . $after . $wrap_after;

            endif;

        else:

            $position = 0;

            echo $wrap_before;

            if ($show_home_link) :

                $position += 1;

                echo $home_link;

            endif;

            if (is_category() || is_tax('brands')) :

                $parents = get_ancestors(get_query_var('cat'), 'category');

                foreach (array_reverse($parents) as $cat) :

                    $position += 1;

                    if ($position > 1) echo $sep;

                    echo sprintf($link, get_category_link($cat), get_cat_name($cat), $position);

                endforeach;

                if (get_query_var('paged')) :

                    $position += 1;

                    $cat = get_query_var('cat');

                    echo $sep . sprintf($link, get_category_link($cat), get_cat_name($cat), $position);

                    echo $sep . $before . sprintf($text['page'], get_query_var('paged')) . $after;

                else :

                    if ($show_current) :

                        if ($position >= 1):

                            echo $sep;

                        endif;

                        $brands_page_id = (int)get_theme_mod('shop-brands-main-page');

                        if (is_tax('brands') && !empty($brands_page_id)):

                            $page_url = get_permalink($brands_page_id);

                            $page_title = get_the_title($brands_page_id);

                            echo '<span itemscope="" itemtype="http://schema.org/ListItem" class="breadcrumbs-item"><a class="breadcrumbs-link" href="' . esc_url($page_url) . '"><span>' . esc_html($page_title) . '</span></a></span>' . $sep . $before . single_cat_title('', false) . $after;

                        else:

                            echo $before . sprintf($text['category'], single_cat_title('', false)) . $after;

                        endif;

                    elseif ($show_last_sep):

                        echo $sep;

                    endif;

                endif;

            elseif (class_exists('WooCommerce') && is_shop() || is_product_taxonomy()) :

                if ($show_home_link && $show_current):

                    echo $sep;

                endif;

                if ($show_current):

                    echo $before . esc_html__('Shop', 'levre') . $after;

                elseif ($show_home_link && $show_last_sep) :

                    echo $sep;

                endif;

            elseif (is_search()) :

                if (get_query_var('paged')) :

                    $position += 1;

                    if ($show_home_link):

                        echo $sep;

                    endif;

                    echo sprintf($link, $home_url . '?s=' . get_search_query(), sprintf($text['search'], get_search_query()), $position);

                    echo $sep . $before . sprintf($text['page'], get_query_var('paged')) . $after;

                else :

                    if ($show_current) :

                        if ($position >= 1):

                            echo $sep;

                        endif;

                        echo $before . sprintf($text['search'], get_search_query()) . $after;

                    elseif ($show_last_sep):

                        echo $sep;

                    endif;

                endif;

            elseif (is_year()) :

                if ($show_home_link && $show_current):

                    echo $sep;

                endif;

                if ($show_current):

                    echo $before . get_query_var('year') . $after;

                elseif ($show_home_link && $show_last_sep) :

                    echo $sep;

                endif;

            elseif (is_month()) :

                if ($show_home_link):

                    echo $sep;

                endif;

                $position += 1;

                echo sprintf($link, get_year_link(get_query_var('year')), get_query_var('year'), $position);

                if ($show_current):

                    echo $sep . $before . DateTime::createFromFormat('m', get_query_var('monthnum'))->format('F') . $after;

                elseif ($show_last_sep):

                    echo $sep;

                endif;

            elseif (is_day()) :

                if ($show_home_link):

                    echo $sep;

                endif;

                $position += 1;

                echo sprintf($link, get_year_link(get_query_var('year')), get_query_var('year'), $position) . $sep;

                $position += 1;

                echo sprintf($link, get_month_link(get_query_var('year'), get_query_var('monthnum')), DateTime::createFromFormat('m', get_query_var('monthnum'))->format('F'), $position);

                if ($show_current):

                    echo $sep . $before . DateTime::createFromFormat('d', get_query_var('day'))->format('d') . $after;

                elseif ($show_last_sep):

                    echo $sep;

                endif;

            elseif (is_single() && !is_attachment()) :

                if (get_post_type() != 'post') :

                    $position += 1;

                    $post_type = get_post_type_object(get_post_type());

                    if ($position > 1):

                        echo $sep;

                    endif;

                    echo sprintf($link, get_post_type_archive_link($post_type->name), $post_type->labels->name, $position);

                    if ($show_current):

                        echo $sep . $before . get_the_title() . $after;

                    elseif ($show_last_sep):

                        echo $sep;

                    endif;

                else :

                    $cat = get_the_category();

                    $catID = $cat[0]->cat_ID;

                    $parents = get_ancestors($catID, 'category');

                    $parents = array_reverse($parents);

                    $parents[] = $catID;

                    foreach ($parents as $cat) :

                        $position += 1;

                        if ($position > 1):

                            echo $sep;

                        endif;

                        echo sprintf($link, get_category_link($cat), get_cat_name($cat), $position);

                    endforeach;

                    if (get_query_var('cpage')) :

                        $position += 1;

                        echo $sep . sprintf($link, get_permalink(), get_the_title(), $position);

                        echo $sep . $before . sprintf($text['cpage'], get_query_var('cpage')) . $after;

                    else :

                        if ($show_current):

                            echo $sep . $before . get_the_title() . $after;

                        elseif ($show_last_sep):

                            echo $sep;

                        endif;

                    endif;

                endif;

            elseif (is_post_type_archive()) :

                $post_type = get_post_type_object(get_post_type());

                if (get_query_var('paged')) :

                    $position += 1;

                    if ($position > 1):

                        echo $sep;

                    endif;

                    echo sprintf($link, get_post_type_archive_link($post_type->name), $post_type->label, $position);

                    echo $sep . $before . sprintf($text['page'], get_query_var('paged')) . $after;

                else:

                    if ($show_home_link && $show_current):

                        echo $sep;

                    endif;

                    if ($show_current):

                        echo $before . $post_type->label . $after;

                    elseif ($show_home_link && $show_last_sep):

                        echo $sep;

                    endif;

                endif;

            elseif (is_attachment()) :

                $parent = get_post($parent_id);

                $cat = get_the_category($parent->ID);

                $catID = $cat[0]->cat_ID;

                $parents = get_ancestors($catID, 'category');

                $parents = array_reverse($parents);

                $parents[] = $catID;

                foreach ($parents as $cat) :

                    $position += 1;

                    if ($position > 1):

                        echo $sep;

                    endif;

                    echo sprintf($link, get_category_link($cat), get_cat_name($cat), $position);

                endforeach;

                $position += 1;

                echo $sep . sprintf($link, get_permalink($parent), $parent->post_title, $position);

                if ($show_current):

                    echo $sep . $before . get_the_title() . $after;

                elseif ($show_last_sep):

                    echo $sep;

                endif;

            elseif (is_page() && !$parent_id) :

                if ($show_home_link && $show_current):

                    echo $sep;

                endif;

                if ($show_current):

                    echo $before . get_the_title() . $after;

                elseif ($show_home_link && $show_last_sep):

                    echo $sep;

                endif;

            elseif (is_page() && $parent_id) :

                $parents = get_post_ancestors(get_the_ID());

                foreach (array_reverse($parents) as $pageID) :

                    $position += 1;

                    if ($position > 1):

                        echo $sep;

                    endif;

                    echo sprintf($link, get_page_link($pageID), get_the_title($pageID), $position);

                endforeach;

                if ($show_current):

                    echo $sep . $before . get_the_title() . $after;

                elseif ($show_last_sep):

                    echo $sep;

                endif;

            elseif (is_tag() || is_tax('brands')) :

                if (get_query_var('paged')) :

                    $position += 1;

                    $tagID = get_query_var('tag_id');

                    echo $sep . sprintf($link, get_tag_link($tagID), single_tag_title('', false), $position);

                    echo $sep . $before . sprintf($text['page'], get_query_var('paged')) . $after;

                else :

                    if ($show_home_link && $show_current):

                        echo $sep;

                    endif;

                    if ($show_current):

                        echo $before . sprintf($text['tag'], single_tag_title('', false)) . $after;

                    elseif ($show_home_link && $show_last_sep):

                        echo $sep;

                    endif;

                endif;

            elseif (is_author()) :

                $author = get_userdata(get_query_var('author'));

                if (get_query_var('paged')) :

                    $position += 1;

                    echo $sep . sprintf($link, get_author_posts_url($author->ID), sprintf($text['author'], $author->display_name), $position);

                    echo $sep . $before . sprintf($text['page'], get_query_var('paged')) . $after;

                else :

                    if ($show_home_link && $show_current) echo $sep;

                    if ($show_current) echo $before . sprintf($text['author'], $author->display_name) . $after;

                    elseif ($show_home_link && $show_last_sep) echo $sep;

                endif;

            elseif (is_404()) :

                if ($show_home_link && $show_current):

                    echo $sep;

                endif;

                if ($show_current):

                    echo $before . $text['404'] . $after;

                elseif ($show_last_sep):

                    echo $sep;

                endif;

            elseif (has_post_format() && !is_singular()) :

                if ($show_home_link && $show_current):

                    echo $sep;

                endif;

                echo get_post_format_string(get_post_format());

            endif;

            echo $wrap_after;

        endif;

    }

    
    public static function the_comments()
    {

        comments_template();

    }

    /**
     * @param $param
     */
    public static function the_option($param)
    {

        if (function_exists('the_field')) :

            return the_field($param, 'option');

        endif;

    }

    /**
     * @param $param
     *
     * @return mixed
     */
    public static function get_option($param)
    {

        if (function_exists('get_field')) :

            return get_field($param, 'option');

        endif;

    }

    /**
     * @param $param
     * @param null $id
     */
    public static function the_field($param, $id = null)
    {

        if ($id == null) :

            $id = get_the_ID();

        endif;

        if (function_exists('the_field')) :

            return the_field($param, $id);

        endif;

    }

    /**
     * @param $param
     * @param null $id
     *
     * @return mixed
     */
    public static function get_field($param, $id = null)
    {

        if ($id == null) :

            $id = get_the_ID();

        endif;

        if (function_exists('get_field')) :

            return get_field($param, $id);

        endif;

    }

    /**
     * @param $param
     */
    public static function the_sub_field($param)
    {

        if (function_exists('the_sub_field')) :

            return the_sub_field($param);

        endif;

    }

    /**
     * @param $param
     *
     * @return bool
     */
    public static function get_sub_field($param)
    {

        if (function_exists('get_sub_field')) :

            return get_sub_field($param);

        endif;

    }

    /**
     * @param $path
     *
     * @return string
     */
    public static function get_webgl_displacement($path)
    {

        return plugin_dir_url(dirname(__FILE__)) . $path;

    }

    public static function render_image($attachment_id, $size, $attr, $wrapper = true, $wrapper_class = 'render-image-wrapper')
    {

        $html = '';

        if ($wrapper):

            $html = '<div class="' . $wrapper_class . '">';

        endif;

        $html .= wp_get_attachment_image($attachment_id, $size, false, $attr);

        if ($wrapper):

            $html .= '</div>';

        endif;

        if (!empty($html)):

            return $html;

        endif;

    }

    public static function get_fa_icons()
    {

        return array(
            'fab fa-500px' => __('500px', 'fs-core'),
            'fab fa-accessible-icon' => __('accessible-icon', 'fs-core'),
            'fab fa-accusoft' => __('accusoft', 'fs-core'),
            'fas fa-address-book' => __('address-book', 'fs-core'),
            'far fa-address-book' => __('address-book', 'fs-core'),
            'fas fa-address-card' => __('address-card', 'fs-core'),
            'far fa-address-card' => __('address-card', 'fs-core'),
            'fas fa-adjust' => __('adjust', 'fs-core'),
            'fab fa-adn' => __('adn', 'fs-core'),
            'fab fa-adversal' => __('adversal', 'fs-core'),
            'fab fa-affiliatetheme' => __('affiliatetheme', 'fs-core'),
            'fab fa-algolia' => __('algolia', 'fs-core'),
            'fas fa-align-center' => __('align-center', 'fs-core'),
            'fas fa-align-justify' => __('align-justify', 'fs-core'),
            'fas fa-align-left' => __('align-left', 'fs-core'),
            'fas fa-align-right' => __('align-right', 'fs-core'),
            'fas fa-allergies' => __('allergies', 'fs-core'),
            'fab fa-amazon' => __('amazon', 'fs-core'),
            'fab fa-amazon-pay' => __('amazon-pay', 'fs-core'),
            'fas fa-ambulance' => __('ambulance', 'fs-core'),
            'fas fa-american-sign-language-interpreting' => __('american-sign-language-interpreting', 'fs-core'),
            'fab fa-amilia' => __('amilia', 'fs-core'),
            'fas fa-anchor' => __('anchor', 'fs-core'),
            'fab fa-android' => __('android', 'fs-core'),
            'fab fa-angellist' => __('angellist', 'fs-core'),
            'fas fa-angle-double-down' => __('angle-double-down', 'fs-core'),
            'fas fa-angle-double-left' => __('angle-double-left', 'fs-core'),
            'fas fa-angle-double-right' => __('angle-double-right', 'fs-core'),
            'fas fa-angle-double-up' => __('angle-double-up', 'fs-core'),
            'fas fa-angle-down' => __('angle-down', 'fs-core'),
            'fas fa-angle-left' => __('angle-left', 'fs-core'),
            'fas fa-angle-right' => __('angle-right', 'fs-core'),
            'fas fa-angle-up' => __('angle-up', 'fs-core'),
            'fab fa-angrycreative' => __('angrycreative', 'fs-core'),
            'fab fa-angular' => __('angular', 'fs-core'),
            'fab fa-app-store' => __('app-store', 'fs-core'),
            'fab fa-app-store-ios' => __('app-store-ios', 'fs-core'),
            'fab fa-apper' => __('apper', 'fs-core'),
            'fab fa-apple' => __('apple', 'fs-core'),
            'fab fa-apple-pay' => __('apple-pay', 'fs-core'),
            'fas fa-archive' => __('archive', 'fs-core'),
            'fas fa-arrow-alt-circle-down' => __('arrow-alt-circle-down', 'fs-core'),
            'far fa-arrow-alt-circle-down' => __('arrow-alt-circle-down', 'fs-core'),
            'fas fa-arrow-alt-circle-left' => __('arrow-alt-circle-left', 'fs-core'),
            'far fa-arrow-alt-circle-left' => __('arrow-alt-circle-left', 'fs-core'),
            'fas fa-arrow-alt-circle-right' => __('arrow-alt-circle-right', 'fs-core'),
            'far fa-arrow-alt-circle-right' => __('arrow-alt-circle-right', 'fs-core'),
            'fas fa-arrow-alt-circle-up' => __('arrow-alt-circle-up', 'fs-core'),
            'far fa-arrow-alt-circle-up' => __('arrow-alt-circle-up', 'fs-core'),
            'fas fa-arrow-circle-down' => __('arrow-circle-down', 'fs-core'),
            'fas fa-arrow-circle-left' => __('arrow-circle-left', 'fs-core'),
            'fas fa-arrow-circle-right' => __('arrow-circle-right', 'fs-core'),
            'fas fa-arrow-circle-up' => __('arrow-circle-up', 'fs-core'),
            'fas fa-arrow-down' => __('arrow-down', 'fs-core'),
            'fas fa-arrow-left' => __('arrow-left', 'fs-core'),
            'fas fa-arrow-right' => __('arrow-right', 'fs-core'),
            'fas fa-arrow-up' => __('arrow-up', 'fs-core'),
            'fas fa-arrows-alt' => __('arrows-alt', 'fs-core'),
            'fas fa-arrows-alt-h' => __('arrows-alt-h', 'fs-core'),
            'fas fa-arrows-alt-v' => __('arrows-alt-v', 'fs-core'),
            'fas fa-assistive-listening-systems' => __('assistive-listening-systems', 'fs-core'),
            'fas fa-asterisk' => __('asterisk', 'fs-core'),
            'fab fa-asymmetrik' => __('asymmetrik', 'fs-core'),
            'fas fa-at' => __('at', 'fs-core'),
            'fab fa-audible' => __('audible', 'fs-core'),
            'fas fa-audio-description' => __('audio-description', 'fs-core'),
            'fab fa-autoprefixer' => __('autoprefixer', 'fs-core'),
            'fab fa-avianex' => __('avianex', 'fs-core'),
            'fab fa-aviato' => __('aviato', 'fs-core'),
            'fab fa-aws' => __('aws', 'fs-core'),
            'fas fa-backward' => __('backward', 'fs-core'),
            'fas fa-balance-scale' => __('balance-scale', 'fs-core'),
            'fas fa-ban' => __('ban', 'fs-core'),
            'fas fa-band-aid' => __('band-aid', 'fs-core'),
            'fab fa-bandcamp' => __('bandcamp', 'fs-core'),
            'fas fa-barcode' => __('barcode', 'fs-core'),
            'fas fa-bars' => __('bars', 'fs-core'),
            'fas fa-baseball-ball' => __('baseball-ball', 'fs-core'),
            'fas fa-basketball-ball' => __('basketball-ball', 'fs-core'),
            'fas fa-bath' => __('bath', 'fs-core'),
            'fas fa-battery-empty' => __('battery-empty', 'fs-core'),
            'fas fa-battery-full' => __('battery-full', 'fs-core'),
            'fas fa-battery-half' => __('battery-half', 'fs-core'),
            'fas fa-battery-quarter' => __('battery-quarter', 'fs-core'),
            'fas fa-battery-three-quarters' => __('battery-three-quarters', 'fs-core'),
            'fas fa-bed' => __('bed', 'fs-core'),
            'fas fa-beer' => __('beer', 'fs-core'),
            'fab fa-behance' => __('behance', 'fs-core'),
            'fab fa-behance-square' => __('behance-square', 'fs-core'),
            'fas fa-bell' => __('bell', 'fs-core'),
            'far fa-bell' => __('bell', 'fs-core'),
            'fas fa-bell-slash' => __('bell-slash', 'fs-core'),
            'far fa-bell-slash' => __('bell-slash', 'fs-core'),
            'fas fa-bicycle' => __('bicycle', 'fs-core'),
            'fab fa-bimobject' => __('bimobject', 'fs-core'),
            'fas fa-binoculars' => __('binoculars', 'fs-core'),
            'fas fa-birthday-cake' => __('birthday-cake', 'fs-core'),
            'fab fa-bitbucket' => __('bitbucket', 'fs-core'),
            'fab fa-bitcoin' => __('bitcoin', 'fs-core'),
            'fab fa-bity' => __('bity', 'fs-core'),
            'fab fa-black-tie' => __('black-tie', 'fs-core'),
            'fab fa-blackberry' => __('blackberry', 'fs-core'),
            'fas fa-blind' => __('blind', 'fs-core'),
            'fab fa-blogger' => __('blogger', 'fs-core'),
            'fab fa-blogger-b' => __('blogger-b', 'fs-core'),
            'fab fa-bluetooth' => __('bluetooth', 'fs-core'),
            'fab fa-bluetooth-b' => __('bluetooth-b', 'fs-core'),
            'fas fa-bold' => __('bold', 'fs-core'),
            'fas fa-bolt' => __('bolt', 'fs-core'),
            'fas fa-bomb' => __('bomb', 'fs-core'),
            'fas fa-book' => __('book', 'fs-core'),
            'fas fa-bookmark' => __('bookmark', 'fs-core'),
            'far fa-bookmark' => __('bookmark', 'fs-core'),
            'fas fa-bowling-ball' => __('bowling-ball', 'fs-core'),
            'fas fa-box' => __('box', 'fs-core'),
            'fas fa-box-open' => __('box-open', 'fs-core'),
            'fas fa-boxes' => __('boxes', 'fs-core'),
            'fas fa-braille' => __('braille', 'fs-core'),
            'fas fa-briefcase' => __('briefcase', 'fs-core'),
            'fas fa-briefcase-medical' => __('briefcase-medical', 'fs-core'),
            'fab fa-btc' => __('btc', 'fs-core'),
            'fas fa-bug' => __('bug', 'fs-core'),
            'fas fa-building' => __('building', 'fs-core'),
            'far fa-building' => __('building', 'fs-core'),
            'fas fa-bullhorn' => __('bullhorn', 'fs-core'),
            'fas fa-bullseye' => __('bullseye', 'fs-core'),
            'fas fa-burn' => __('burn', 'fs-core'),
            'fab fa-buromobelexperte' => __('buromobelexperte', 'fs-core'),
            'fas fa-bus' => __('bus', 'fs-core'),
            'fab fa-buysellads' => __('buysellads', 'fs-core'),
            'fas fa-calculator' => __('calculator', 'fs-core'),
            'fas fa-calendar' => __('calendar', 'fs-core'),
            'far fa-calendar' => __('calendar', 'fs-core'),
            'fas fa-calendar-alt' => __('calendar-alt', 'fs-core'),
            'far fa-calendar-alt' => __('calendar-alt', 'fs-core'),
            'fas fa-calendar-check' => __('calendar-check', 'fs-core'),
            'far fa-calendar-check' => __('calendar-check', 'fs-core'),
            'fas fa-calendar-minus' => __('calendar-minus', 'fs-core'),
            'far fa-calendar-minus' => __('calendar-minus', 'fs-core'),
            'fas fa-calendar-plus' => __('calendar-plus', 'fs-core'),
            'far fa-calendar-plus' => __('calendar-plus', 'fs-core'),
            'fas fa-calendar-times' => __('calendar-times', 'fs-core'),
            'far fa-calendar-times' => __('calendar-times', 'fs-core'),
            'fas fa-camera' => __('camera', 'fs-core'),
            'fas fa-camera-retro' => __('camera-retro', 'fs-core'),
            'fas fa-capsules' => __('capsules', 'fs-core'),
            'fas fa-car' => __('car', 'fs-core'),
            'fas fa-caret-down' => __('caret-down', 'fs-core'),
            'fas fa-caret-left' => __('caret-left', 'fs-core'),
            'fas fa-caret-right' => __('caret-right', 'fs-core'),
            'fas fa-caret-square-down' => __('caret-square-down', 'fs-core'),
            'far fa-caret-square-down' => __('caret-square-down', 'fs-core'),
            'fas fa-caret-square-left' => __('caret-square-left', 'fs-core'),
            'far fa-caret-square-left' => __('caret-square-left', 'fs-core'),
            'fas fa-caret-square-right' => __('caret-square-right', 'fs-core'),
            'far fa-caret-square-right' => __('caret-square-right', 'fs-core'),
            'fas fa-caret-square-up' => __('caret-square-up', 'fs-core'),
            'far fa-caret-square-up' => __('caret-square-up', 'fs-core'),
            'fas fa-caret-up' => __('caret-up', 'fs-core'),
            'fas fa-cart-arrow-down' => __('cart-arrow-down', 'fs-core'),
            'fas fa-cart-plus' => __('cart-plus', 'fs-core'),
            'fab fa-cc-amazon-pay' => __('cc-amazon-pay', 'fs-core'),
            'fab fa-cc-amex' => __('cc-amex', 'fs-core'),
            'fab fa-cc-apple-pay' => __('cc-apple-pay', 'fs-core'),
            'fab fa-cc-diners-club' => __('cc-diners-club', 'fs-core'),
            'fab fa-cc-discover' => __('cc-discover', 'fs-core'),
            'fab fa-cc-jcb' => __('cc-jcb', 'fs-core'),
            'fab fa-cc-mastercard' => __('cc-mastercard', 'fs-core'),
            'fab fa-cc-paypal' => __('cc-paypal', 'fs-core'),
            'fab fa-cc-stripe' => __('cc-stripe', 'fs-core'),
            'fab fa-cc-visa' => __('cc-visa', 'fs-core'),
            'fab fa-centercode' => __('centercode', 'fs-core'),
            'fas fa-certificate' => __('certificate', 'fs-core'),
            'fas fa-chart-area' => __('chart-area', 'fs-core'),
            'fas fa-chart-bar' => __('chart-bar', 'fs-core'),
            'far fa-chart-bar' => __('chart-bar', 'fs-core'),
            'fas fa-chart-line' => __('chart-line', 'fs-core'),
            'fas fa-chart-pie' => __('chart-pie', 'fs-core'),
            'fas fa-check' => __('check', 'fs-core'),
            'fas fa-check-circle' => __('check-circle', 'fs-core'),
            'far fa-check-circle' => __('check-circle', 'fs-core'),
            'fas fa-check-square' => __('check-square', 'fs-core'),
            'far fa-check-square' => __('check-square', 'fs-core'),
            'fas fa-chess' => __('chess', 'fs-core'),
            'fas fa-chess-bishop' => __('chess-bishop', 'fs-core'),
            'fas fa-chess-board' => __('chess-board', 'fs-core'),
            'fas fa-chess-king' => __('chess-king', 'fs-core'),
            'fas fa-chess-knight' => __('chess-knight', 'fs-core'),
            'fas fa-chess-pawn' => __('chess-pawn', 'fs-core'),
            'fas fa-chess-queen' => __('chess-queen', 'fs-core'),
            'fas fa-chess-rook' => __('chess-rook', 'fs-core'),
            'fas fa-chevron-circle-down' => __('chevron-circle-down', 'fs-core'),
            'fas fa-chevron-circle-left' => __('chevron-circle-left', 'fs-core'),
            'fas fa-chevron-circle-right' => __('chevron-circle-right', 'fs-core'),
            'fas fa-chevron-circle-up' => __('chevron-circle-up', 'fs-core'),
            'fas fa-chevron-down' => __('chevron-down', 'fs-core'),
            'fas fa-chevron-left' => __('chevron-left', 'fs-core'),
            'fas fa-chevron-right' => __('chevron-right', 'fs-core'),
            'fas fa-chevron-up' => __('chevron-up', 'fs-core'),
            'fas fa-child' => __('child', 'fs-core'),
            'fab fa-chrome' => __('chrome', 'fs-core'),
            'fas fa-circle' => __('circle', 'fs-core'),
            'far fa-circle' => __('circle', 'fs-core'),
            'fas fa-circle-notch' => __('circle-notch', 'fs-core'),
            'fas fa-clipboard' => __('clipboard', 'fs-core'),
            'far fa-clipboard' => __('clipboard', 'fs-core'),
            'fas fa-clipboard-check' => __('clipboard-check', 'fs-core'),
            'fas fa-clipboard-list' => __('clipboard-list', 'fs-core'),
            'fas fa-clock' => __('clock', 'fs-core'),
            'far fa-clock' => __('clock', 'fs-core'),
            'fas fa-clone' => __('clone', 'fs-core'),
            'far fa-clone' => __('clone', 'fs-core'),
            'fas fa-closed-captioning' => __('closed-captioning', 'fs-core'),
            'far fa-closed-captioning' => __('closed-captioning', 'fs-core'),
            'fas fa-cloud' => __('cloud', 'fs-core'),
            'fas fa-cloud-download-alt' => __('cloud-download-alt', 'fs-core'),
            'fas fa-cloud-upload-alt' => __('cloud-upload-alt', 'fs-core'),
            'fab fa-cloudscale' => __('cloudscale', 'fs-core'),
            'fab fa-cloudsmith' => __('cloudsmith', 'fs-core'),
            'fab fa-cloudversify' => __('cloudversify', 'fs-core'),
            'fas fa-code' => __('code', 'fs-core'),
            'fas fa-code-branch' => __('code-branch', 'fs-core'),
            'fab fa-codepen' => __('codepen', 'fs-core'),
            'fab fa-codiepie' => __('codiepie', 'fs-core'),
            'fas fa-coffee' => __('coffee', 'fs-core'),
            'fas fa-cog' => __('cog', 'fs-core'),
            'fas fa-cogs' => __('cogs', 'fs-core'),
            'fas fa-columns' => __('columns', 'fs-core'),
            'fas fa-comment' => __('comment', 'fs-core'),
            'far fa-comment' => __('comment', 'fs-core'),
            'fas fa-comment-alt' => __('comment-alt', 'fs-core'),
            'far fa-comment-alt' => __('comment-alt', 'fs-core'),
            'fas fa-comment-dots' => __('comment-dots', 'fs-core'),
            'fas fa-comment-slash' => __('comment-slash', 'fs-core'),
            'fas fa-comments' => __('comments', 'fs-core'),
            'far fa-comments' => __('comments', 'fs-core'),
            'fas fa-compass' => __('compass', 'fs-core'),
            'far fa-compass' => __('compass', 'fs-core'),
            'fas fa-compress' => __('compress', 'fs-core'),
            'fab fa-connectdevelop' => __('connectdevelop', 'fs-core'),
            'fab fa-contao' => __('contao', 'fs-core'),
            'fas fa-copy' => __('copy', 'fs-core'),
            'far fa-copy' => __('copy', 'fs-core'),
            'fas fa-copyright' => __('copyright', 'fs-core'),
            'far fa-copyright' => __('copyright', 'fs-core'),
            'fas fa-couch' => __('couch', 'fs-core'),
            'fab fa-cpanel' => __('cpanel', 'fs-core'),
            'fab fa-creative-commons' => __('creative-commons', 'fs-core'),
            'fas fa-credit-card' => __('credit-card', 'fs-core'),
            'far fa-credit-card' => __('credit-card', 'fs-core'),
            'fas fa-crop' => __('crop', 'fs-core'),
            'fas fa-crosshairs' => __('crosshairs', 'fs-core'),
            'fab fa-css3' => __('css3', 'fs-core'),
            'fab fa-css3-alt' => __('css3-alt', 'fs-core'),
            'fas fa-cube' => __('cube', 'fs-core'),
            'fas fa-cubes' => __('cubes', 'fs-core'),
            'fas fa-cut' => __('cut', 'fs-core'),
            'fab fa-cuttlefish' => __('cuttlefish', 'fs-core'),
            'fab fa-d-and-d' => __('d-and-d', 'fs-core'),
            'fab fa-dashcube' => __('dashcube', 'fs-core'),
            'fas fa-database' => __('database', 'fs-core'),
            'fas fa-deaf' => __('deaf', 'fs-core'),
            'fab fa-delicious' => __('delicious', 'fs-core'),
            'fab fa-deploydog' => __('deploydog', 'fs-core'),
            'fab fa-deskpro' => __('deskpro', 'fs-core'),
            'fas fa-desktop' => __('desktop', 'fs-core'),
            'fab fa-deviantart' => __('deviantart', 'fs-core'),
            'fas fa-diagnoses' => __('diagnoses', 'fs-core'),
            'fab fa-digg' => __('digg', 'fs-core'),
            'fab fa-digital-ocean' => __('digital-ocean', 'fs-core'),
            'fab fa-discord' => __('discord', 'fs-core'),
            'fab fa-discourse' => __('discourse', 'fs-core'),
            'fas fa-dna' => __('dna', 'fs-core'),
            'fab fa-dochub' => __('dochub', 'fs-core'),
            'fab fa-docker' => __('docker', 'fs-core'),
            'fas fa-dollar-sign' => __('dollar-sign', 'fs-core'),
            'fas fa-dolly' => __('dolly', 'fs-core'),
            'fas fa-dolly-flatbed' => __('dolly-flatbed', 'fs-core'),
            'fas fa-donate' => __('donate', 'fs-core'),
            'fas fa-dot-circle' => __('dot-circle', 'fs-core'),
            'far fa-dot-circle' => __('dot-circle', 'fs-core'),
            'fas fa-dove' => __('dove', 'fs-core'),
            'fas fa-download' => __('download', 'fs-core'),
            'fab fa-draft2digital' => __('draft2digital', 'fs-core'),
            'fab fa-dribbble' => __('dribbble', 'fs-core'),
            'fab fa-dribbble-square' => __('dribbble-square', 'fs-core'),
            'fab fa-dropbox' => __('dropbox', 'fs-core'),
            'fab fa-drupal' => __('drupal', 'fs-core'),
            'fab fa-dyalog' => __('dyalog', 'fs-core'),
            'fab fa-earlybirds' => __('earlybirds', 'fs-core'),
            'fab fa-edge' => __('edge', 'fs-core'),
            'fas fa-edit' => __('edit', 'fs-core'),
            'far fa-edit' => __('edit', 'fs-core'),
            'fas fa-eject' => __('eject', 'fs-core'),
            'fab fa-elementor' => __('elementor', 'fs-core'),
            'fas fa-ellipsis-h' => __('ellipsis-h', 'fs-core'),
            'fas fa-ellipsis-v' => __('ellipsis-v', 'fs-core'),
            'fab fa-ember' => __('ember', 'fs-core'),
            'fab fa-empire' => __('empire', 'fs-core'),
            'fas fa-envelope' => __('envelope', 'fs-core'),
            'far fa-envelope' => __('envelope', 'fs-core'),
            'fas fa-envelope-open' => __('envelope-open', 'fs-core'),
            'far fa-envelope-open' => __('envelope-open', 'fs-core'),
            'fas fa-envelope-square' => __('envelope-square', 'fs-core'),
            'fab fa-envira' => __('envira', 'fs-core'),
            'fas fa-eraser' => __('eraser', 'fs-core'),
            'fab fa-erlang' => __('erlang', 'fs-core'),
            'fab fa-ethereum' => __('ethereum', 'fs-core'),
            'fab fa-etsy' => __('etsy', 'fs-core'),
            'fas fa-euro-sign' => __('euro-sign', 'fs-core'),
            'fas fa-exchange-alt' => __('exchange-alt', 'fs-core'),
            'fas fa-exclamation' => __('exclamation', 'fs-core'),
            'fas fa-exclamation-circle' => __('exclamation-circle', 'fs-core'),
            'fas fa-exclamation-triangle' => __('exclamation-triangle', 'fs-core'),
            'fas fa-expand' => __('expand', 'fs-core'),
            'fas fa-expand-arrows-alt' => __('expand-arrows-alt', 'fs-core'),
            'fab fa-expeditedssl' => __('expeditedssl', 'fs-core'),
            'fas fa-external-link-alt' => __('external-link-alt', 'fs-core'),
            'fas fa-external-link-square-alt' => __('external-link-square-alt', 'fs-core'),
            'fas fa-eye' => __('eye', 'fs-core'),
            'fas fa-eye-dropper' => __('eye-dropper', 'fs-core'),
            'fas fa-eye-slash' => __('eye-slash', 'fs-core'),
            'far fa-eye-slash' => __('eye-slash', 'fs-core'),
            'fab fa-facebook' => __('facebook', 'fs-core'),
            'fab fa-facebook-f' => __('facebook-f', 'fs-core'),
            'fab fa-facebook-messenger' => __('facebook-messenger', 'fs-core'),
            'fab fa-facebook-square' => __('facebook-square', 'fs-core'),
            'fas fa-fast-backward' => __('fast-backward', 'fs-core'),
            'fas fa-fast-forward' => __('fast-forward', 'fs-core'),
            'fas fa-fax' => __('fax', 'fs-core'),
            'fas fa-female' => __('female', 'fs-core'),
            'fas fa-fighter-jet' => __('fighter-jet', 'fs-core'),
            'fas fa-file' => __('file', 'fs-core'),
            'far fa-file' => __('file', 'fs-core'),
            'fas fa-file-alt' => __('file-alt', 'fs-core'),
            'far fa-file-alt' => __('file-alt', 'fs-core'),
            'fas fa-file-archive' => __('file-archive', 'fs-core'),
            'far fa-file-archive' => __('file-archive', 'fs-core'),
            'fas fa-file-audio' => __('file-audio', 'fs-core'),
            'far fa-file-audio' => __('file-audio', 'fs-core'),
            'fas fa-file-code' => __('file-code', 'fs-core'),
            'far fa-file-code' => __('file-code', 'fs-core'),
            'fas fa-file-excel' => __('file-excel', 'fs-core'),
            'far fa-file-excel' => __('file-excel', 'fs-core'),
            'fas fa-file-image' => __('file-image', 'fs-core'),
            'far fa-file-image' => __('file-image', 'fs-core'),
            'fas fa-file-medical' => __('file-medical', 'fs-core'),
            'fas fa-file-medical-alt' => __('file-medical-alt', 'fs-core'),
            'fas fa-file-pdf' => __('file-pdf', 'fs-core'),
            'far fa-file-pdf' => __('file-pdf', 'fs-core'),
            'fas fa-file-powerpoint' => __('file-powerpoint', 'fs-core'),
            'far fa-file-powerpoint' => __('file-powerpoint', 'fs-core'),
            'fas fa-file-video' => __('file-video', 'fs-core'),
            'far fa-file-video' => __('file-video', 'fs-core'),
            'fas fa-file-word' => __('file-word', 'fs-core'),
            'far fa-file-word' => __('file-word', 'fs-core'),
            'fas fa-film' => __('film', 'fs-core'),
            'fas fa-filter' => __('filter', 'fs-core'),
            'fas fa-fire' => __('fire', 'fs-core'),
            'fas fa-fire-extinguisher' => __('fire-extinguisher', 'fs-core'),
            'fab fa-firefox' => __('firefox', 'fs-core'),
            'fas fa-first-aid' => __('first-aid', 'fs-core'),
            'fab fa-first-order' => __('first-order', 'fs-core'),
            'fab fa-firstdraft' => __('firstdraft', 'fs-core'),
            'fas fa-flag' => __('flag', 'fs-core'),
            'far fa-flag' => __('flag', 'fs-core'),
            'fas fa-flag-checkered' => __('flag-checkered', 'fs-core'),
            'fas fa-flask' => __('flask', 'fs-core'),
            'fab fa-flickr' => __('flickr', 'fs-core'),
            'fab fa-flipboard' => __('flipboard', 'fs-core'),
            'fab fa-fly' => __('fly', 'fs-core'),
            'fas fa-folder' => __('folder', 'fs-core'),
            'far fa-folder' => __('folder', 'fs-core'),
            'fas fa-folder-open' => __('folder-open', 'fs-core'),
            'far fa-folder-open' => __('folder-open', 'fs-core'),
            'fas fa-font' => __('font', 'fs-core'),
            'fab fa-font-awesome' => __('font-awesome', 'fs-core'),
            'fab fa-font-awesome-alt' => __('font-awesome-alt', 'fs-core'),
            'fab fa-font-awesome-flag' => __('font-awesome-flag', 'fs-core'),
            'fab fa-fonticons' => __('fonticons', 'fs-core'),
            'fab fa-fonticons-fi' => __('fonticons-fi', 'fs-core'),
            'fas fa-football-ball' => __('football-ball', 'fs-core'),
            'fab fa-fort-awesome' => __('fort-awesome', 'fs-core'),
            'fab fa-fort-awesome-alt' => __('fort-awesome-alt', 'fs-core'),
            'fab fa-forumbee' => __('forumbee', 'fs-core'),
            'fas fa-forward' => __('forward', 'fs-core'),
            'fab fa-foursquare' => __('foursquare', 'fs-core'),
            'fab fa-free-code-camp' => __('free-code-camp', 'fs-core'),
            'fab fa-freebsd' => __('freebsd', 'fs-core'),
            'fas fa-frown' => __('frown', 'fs-core'),
            'far fa-frown' => __('frown', 'fs-core'),
            'fas fa-futbol' => __('futbol', 'fs-core'),
            'far fa-futbol' => __('futbol', 'fs-core'),
            'fas fa-gamepad' => __('gamepad', 'fs-core'),
            'fas fa-gavel' => __('gavel', 'fs-core'),
            'fas fa-gem' => __('gem', 'fs-core'),
            'far fa-gem' => __('gem', 'fs-core'),
            'fas fa-genderless' => __('genderless', 'fs-core'),
            'fab fa-get-pocket' => __('get-pocket', 'fs-core'),
            'fab fa-gg' => __('gg', 'fs-core'),
            'fab fa-gg-circle' => __('gg-circle', 'fs-core'),
            'fas fa-gift' => __('gift', 'fs-core'),
            'fab fa-git' => __('git', 'fs-core'),
            'fab fa-git-square' => __('git-square', 'fs-core'),
            'fab fa-github' => __('github', 'fs-core'),
            'fab fa-github-alt' => __('github-alt', 'fs-core'),
            'fab fa-github-square' => __('github-square', 'fs-core'),
            'fab fa-gitkraken' => __('gitkraken', 'fs-core'),
            'fab fa-gitlab' => __('gitlab', 'fs-core'),
            'fab fa-gitter' => __('gitter', 'fs-core'),
            'fas fa-glass-martini' => __('glass-martini', 'fs-core'),
            'fab fa-glide' => __('glide', 'fs-core'),
            'fab fa-glide-g' => __('glide-g', 'fs-core'),
            'fas fa-globe' => __('globe', 'fs-core'),
            'fab fa-gofore' => __('gofore', 'fs-core'),
            'fas fa-golf-ball' => __('golf-ball', 'fs-core'),
            'fab fa-goodreads' => __('goodreads', 'fs-core'),
            'fab fa-goodreads-g' => __('goodreads-g', 'fs-core'),
            'fab fa-google' => __('google', 'fs-core'),
            'fab fa-google-drive' => __('google-drive', 'fs-core'),
            'fab fa-google-play' => __('google-play', 'fs-core'),
            'fab fa-google-plus' => __('google-plus', 'fs-core'),
            'fab fa-google-plus-g' => __('google-plus-g', 'fs-core'),
            'fab fa-google-plus-square' => __('google-plus-square', 'fs-core'),
            'fab fa-google-wallet' => __('google-wallet', 'fs-core'),
            'fas fa-graduation-cap' => __('graduation-cap', 'fs-core'),
            'fab fa-gratipay' => __('gratipay', 'fs-core'),
            'fab fa-grav' => __('grav', 'fs-core'),
            'fab fa-gripfire' => __('gripfire', 'fs-core'),
            'fab fa-grunt' => __('grunt', 'fs-core'),
            'fab fa-gulp' => __('gulp', 'fs-core'),
            'fas fa-h-square' => __('h-square', 'fs-core'),
            'fab fa-hacker-news' => __('hacker-news', 'fs-core'),
            'fab fa-hacker-news-square' => __('hacker-news-square', 'fs-core'),
            'fas fa-hand-holding' => __('hand-holding', 'fs-core'),
            'fas fa-hand-holding-heart' => __('hand-holding-heart', 'fs-core'),
            'fas fa-hand-holding-usd' => __('hand-holding-usd', 'fs-core'),
            'fas fa-hand-lizard' => __('hand-lizard', 'fs-core'),
            'far fa-hand-lizard' => __('hand-lizard', 'fs-core'),
            'fas fa-hand-paper' => __('hand-paper', 'fs-core'),
            'far fa-hand-paper' => __('hand-paper', 'fs-core'),
            'fas fa-hand-peace' => __('hand-peace', 'fs-core'),
            'far fa-hand-peace' => __('hand-peace', 'fs-core'),
            'fas fa-hand-point-down' => __('hand-point-down', 'fs-core'),
            'far fa-hand-point-down' => __('hand-point-down', 'fs-core'),
            'fas fa-hand-point-left' => __('hand-point-left', 'fs-core'),
            'far fa-hand-point-left' => __('hand-point-left', 'fs-core'),
            'fas fa-hand-point-right' => __('hand-point-right', 'fs-core'),
            'far fa-hand-point-right' => __('hand-point-right', 'fs-core'),
            'fas fa-hand-point-up' => __('hand-point-up', 'fs-core'),
            'far fa-hand-point-up' => __('hand-point-up', 'fs-core'),
            'fas fa-hand-pointer' => __('hand-pointer', 'fs-core'),
            'far fa-hand-pointer' => __('hand-pointer', 'fs-core'),
            'fas fa-hand-rock' => __('hand-rock', 'fs-core'),
            'far fa-hand-rock' => __('hand-rock', 'fs-core'),
            'fas fa-hand-scissors' => __('hand-scissors', 'fs-core'),
            'far fa-hand-scissors' => __('hand-scissors', 'fs-core'),
            'fas fa-hand-spock' => __('hand-spock', 'fs-core'),
            'far fa-hand-spock' => __('hand-spock', 'fs-core'),
            'fas fa-hands' => __('hands', 'fs-core'),
            'fas fa-hands-helping' => __('hands-helping', 'fs-core'),
            'fas fa-handshake' => __('handshake', 'fs-core'),
            'far fa-handshake' => __('handshake', 'fs-core'),
            'fas fa-hashtag' => __('hashtag', 'fs-core'),
            'fas fa-hdd' => __('hdd', 'fs-core'),
            'far fa-hdd' => __('hdd', 'fs-core'),
            'fas fa-heading' => __('heading', 'fs-core'),
            'fas fa-headphones' => __('headphones', 'fs-core'),
            'fas fa-heart' => __('heart', 'fs-core'),
            'far fa-heart' => __('heart', 'fs-core'),
            'fas fa-heartbeat' => __('heartbeat', 'fs-core'),
            'fab fa-hips' => __('hips', 'fs-core'),
            'fab fa-hire-a-helper' => __('hire-a-helper', 'fs-core'),
            'fas fa-history' => __('history', 'fs-core'),
            'fas fa-hockey-puck' => __('hockey-puck', 'fs-core'),
            'fas fa-home' => __('home', 'fs-core'),
            'fab fa-hooli' => __('hooli', 'fs-core'),
            'fas fa-hospital' => __('hospital', 'fs-core'),
            'far fa-hospital' => __('hospital', 'fs-core'),
            'fas fa-hospital-alt' => __('hospital-alt', 'fs-core'),
            'fas fa-hospital-symbol' => __('hospital-symbol', 'fs-core'),
            'fab fa-hotjar' => __('hotjar', 'fs-core'),
            'fas fa-hourglass' => __('hourglass', 'fs-core'),
            'far fa-hourglass' => __('hourglass', 'fs-core'),
            'fas fa-hourglass-end' => __('hourglass-end', 'fs-core'),
            'fas fa-hourglass-half' => __('hourglass-half', 'fs-core'),
            'fas fa-hourglass-start' => __('hourglass-start', 'fs-core'),
            'fab fa-houzz' => __('houzz', 'fs-core'),
            'fab fa-html5' => __('html5', 'fs-core'),
            'fab fa-hubspot' => __('hubspot', 'fs-core'),
            'fas fa-i-cursor' => __('i-cursor', 'fs-core'),
            'fas fa-id-badge' => __('id-badge', 'fs-core'),
            'far fa-id-badge' => __('id-badge', 'fs-core'),
            'fas fa-id-card' => __('id-card', 'fs-core'),
            'far fa-id-card' => __('id-card', 'fs-core'),
            'fas fa-id-card-alt' => __('id-card-alt', 'fs-core'),
            'fas fa-image' => __('image', 'fs-core'),
            'far fa-image' => __('image', 'fs-core'),
            'fas fa-images' => __('images', 'fs-core'),
            'far fa-images' => __('images', 'fs-core'),
            'fab fa-imdb' => __('imdb', 'fs-core'),
            'fas fa-inbox' => __('inbox', 'fs-core'),
            'fas fa-indent' => __('indent', 'fs-core'),
            'fas fa-industry' => __('industry', 'fs-core'),
            'fas fa-info' => __('info', 'fs-core'),
            'fas fa-info-circle' => __('info-circle', 'fs-core'),
            'fab fa-instagram' => __('instagram', 'fs-core'),
            'fab fa-internet-explorer' => __('internet-explorer', 'fs-core'),
            'fab fa-ioxhost' => __('ioxhost', 'fs-core'),
            'fas fa-italic' => __('italic', 'fs-core'),
            'fab fa-itunes' => __('itunes', 'fs-core'),
            'fab fa-itunes-note' => __('itunes-note', 'fs-core'),
            'fab fa-java' => __('java', 'fs-core'),
            'fab fa-jenkins' => __('jenkins', 'fs-core'),
            'fab fa-joget' => __('joget', 'fs-core'),
            'fab fa-joomla' => __('joomla', 'fs-core'),
            'fab fa-js' => __('js', 'fs-core'),
            'fab fa-js-square' => __('js-square', 'fs-core'),
            'fab fa-jsfiddle' => __('jsfiddle', 'fs-core'),
            'fas fa-key' => __('key', 'fs-core'),
            'fas fa-keyboard' => __('keyboard', 'fs-core'),
            'far fa-keyboard' => __('keyboard', 'fs-core'),
            'fab fa-keycdn' => __('keycdn', 'fs-core'),
            'fab fa-kickstarter' => __('kickstarter', 'fs-core'),
            'fab fa-kickstarter-k' => __('kickstarter-k', 'fs-core'),
            'fab fa-korvue' => __('korvue', 'fs-core'),
            'fas fa-language' => __('language', 'fs-core'),
            'fas fa-laptop' => __('laptop', 'fs-core'),
            'fab fa-laravel' => __('laravel', 'fs-core'),
            'fab fa-lastfm' => __('lastfm', 'fs-core'),
            'fab fa-lastfm-square' => __('lastfm-square', 'fs-core'),
            'fas fa-leaf' => __('leaf', 'fs-core'),
            'fab fa-leanpub' => __('leanpub', 'fs-core'),
            'fas fa-lemon' => __('lemon', 'fs-core'),
            'far fa-lemon' => __('lemon', 'fs-core'),
            'fab fa-less' => __('less', 'fs-core'),
            'fas fa-level-down-alt' => __('level-down-alt', 'fs-core'),
            'fas fa-level-up-alt' => __('level-up-alt', 'fs-core'),
            'fas fa-life-ring' => __('life-ring', 'fs-core'),
            'far fa-life-ring' => __('life-ring', 'fs-core'),
            'fas fa-lightbulb' => __('lightbulb', 'fs-core'),
            'far fa-lightbulb' => __('lightbulb', 'fs-core'),
            'fab fa-line' => __('line', 'fs-core'),
            'fas fa-link' => __('link', 'fs-core'),
            'fab fa-linkedin' => __('linkedin', 'fs-core'),
            'fab fa-linkedin-in' => __('linkedin-in', 'fs-core'),
            'fab fa-linode' => __('linode', 'fs-core'),
            'fab fa-linux' => __('linux', 'fs-core'),
            'fas fa-lira-sign' => __('lira-sign', 'fs-core'),
            'fas fa-list' => __('list', 'fs-core'),
            'fas fa-list-alt' => __('list-alt', 'fs-core'),
            'far fa-list-alt' => __('list-alt', 'fs-core'),
            'fas fa-list-ol' => __('list-ol', 'fs-core'),
            'fas fa-list-ul' => __('list-ul', 'fs-core'),
            'fas fa-location-arrow' => __('location-arrow', 'fs-core'),
            'fas fa-lock' => __('lock', 'fs-core'),
            'fas fa-lock-open' => __('lock-open', 'fs-core'),
            'fas fa-long-arrow-alt-down' => __('long-arrow-alt-down', 'fs-core'),
            'fas fa-long-arrow-alt-left' => __('long-arrow-alt-left', 'fs-core'),
            'fas fa-long-arrow-alt-right' => __('long-arrow-alt-right', 'fs-core'),
            'fas fa-long-arrow-alt-up' => __('long-arrow-alt-up', 'fs-core'),
            'fas fa-low-vision' => __('low-vision', 'fs-core'),
            'fab fa-lyft' => __('lyft', 'fs-core'),
            'fab fa-magento' => __('magento', 'fs-core'),
            'fas fa-magic' => __('magic', 'fs-core'),
            'fas fa-magnet' => __('magnet', 'fs-core'),
            'fas fa-male' => __('male', 'fs-core'),
            'fas fa-map' => __('map', 'fs-core'),
            'far fa-map' => __('map', 'fs-core'),
            'fas fa-map-marker' => __('map-marker', 'fs-core'),
            'fas fa-map-marker-alt' => __('map-marker-alt', 'fs-core'),
            'fas fa-map-pin' => __('map-pin', 'fs-core'),
            'fas fa-map-signs' => __('map-signs', 'fs-core'),
            'fas fa-mars' => __('mars', 'fs-core'),
            'fas fa-mars-double' => __('mars-double', 'fs-core'),
            'fas fa-mars-stroke' => __('mars-stroke', 'fs-core'),
            'fas fa-mars-stroke-h' => __('mars-stroke-h', 'fs-core'),
            'fas fa-mars-stroke-v' => __('mars-stroke-v', 'fs-core'),
            'fab fa-maxcdn' => __('maxcdn', 'fs-core'),
            'fab fa-medapps' => __('medapps', 'fs-core'),
            'fab fa-medium' => __('medium', 'fs-core'),
            'fab fa-medium-m' => __('medium-m', 'fs-core'),
            'fas fa-medkit' => __('medkit', 'fs-core'),
            'fab fa-medrt' => __('medrt', 'fs-core'),
            'fab fa-meetup' => __('meetup', 'fs-core'),
            'fas fa-meh' => __('meh', 'fs-core'),
            'far fa-meh' => __('meh', 'fs-core'),
            'fas fa-mercury' => __('mercury', 'fs-core'),
            'fas fa-microchip' => __('microchip', 'fs-core'),
            'fas fa-microphone' => __('microphone', 'fs-core'),
            'fas fa-microphone-slash' => __('microphone-slash', 'fs-core'),
            'fab fa-microsoft' => __('microsoft', 'fs-core'),
            'fas fa-minus' => __('minus', 'fs-core'),
            'fas fa-minus-circle' => __('minus-circle', 'fs-core'),
            'fas fa-minus-square' => __('minus-square', 'fs-core'),
            'far fa-minus-square' => __('minus-square', 'fs-core'),
            'fab fa-mix' => __('mix', 'fs-core'),
            'fab fa-mixcloud' => __('mixcloud', 'fs-core'),
            'fab fa-mizuni' => __('mizuni', 'fs-core'),
            'fas fa-mobile' => __('mobile', 'fs-core'),
            'fas fa-mobile-alt' => __('mobile-alt', 'fs-core'),
            'fab fa-modx' => __('modx', 'fs-core'),
            'fab fa-monero' => __('monero', 'fs-core'),
            'fas fa-money-bill-alt' => __('money-bill-alt', 'fs-core'),
            'far fa-money-bill-alt' => __('money-bill-alt', 'fs-core'),
            'fas fa-moon' => __('moon', 'fs-core'),
            'far fa-moon' => __('moon', 'fs-core'),
            'fas fa-motorcycle' => __('motorcycle', 'fs-core'),
            'fas fa-mouse-pointer' => __('mouse-pointer', 'fs-core'),
            'fas fa-music' => __('music', 'fs-core'),
            'fab fa-napster' => __('napster', 'fs-core'),
            'fas fa-neuter' => __('neuter', 'fs-core'),
            'fas fa-newspaper' => __('newspaper', 'fs-core'),
            'far fa-newspaper' => __('newspaper', 'fs-core'),
            'fab fa-nintendo-switch' => __('nintendo-switch', 'fs-core'),
            'fab fa-node' => __('node', 'fs-core'),
            'fab fa-node-js' => __('node-js', 'fs-core'),
            'fas fa-notes-medical' => __('notes-medical', 'fs-core'),
            'fab fa-npm' => __('npm', 'fs-core'),
            'fab fa-ns8' => __('ns8', 'fs-core'),
            'fab fa-nutritionix' => __('nutritionix', 'fs-core'),
            'fas fa-object-group' => __('object-group', 'fs-core'),
            'far fa-object-group' => __('object-group', 'fs-core'),
            'fas fa-object-ungroup' => __('object-ungroup', 'fs-core'),
            'far fa-object-ungroup' => __('object-ungroup', 'fs-core'),
            'fab fa-odnoklassniki' => __('odnoklassniki', 'fs-core'),
            'fab fa-odnoklassniki-square' => __('odnoklassniki-square', 'fs-core'),
            'fab fa-opencart' => __('opencart', 'fs-core'),
            'fab fa-openid' => __('openid', 'fs-core'),
            'fab fa-opera' => __('opera', 'fs-core'),
            'fab fa-optin-monster' => __('optin-monster', 'fs-core'),
            'fab fa-osi' => __('osi', 'fs-core'),
            'fas fa-outdent' => __('outdent', 'fs-core'),
            'fab fa-page4' => __('page4', 'fs-core'),
            'fab fa-pagelines' => __('pagelines', 'fs-core'),
            'fas fa-paint-brush' => __('paint-brush', 'fs-core'),
            'fab fa-palfed' => __('palfed', 'fs-core'),
            'fas fa-pallet' => __('pallet', 'fs-core'),
            'fas fa-paper-plane' => __('paper-plane', 'fs-core'),
            'far fa-paper-plane' => __('paper-plane', 'fs-core'),
            'fas fa-paperclip' => __('paperclip', 'fs-core'),
            'fas fa-parachute-box' => __('parachute-box', 'fs-core'),
            'fas fa-paragraph' => __('paragraph', 'fs-core'),
            'fas fa-paste' => __('paste', 'fs-core'),
            'fab fa-patreon' => __('patreon', 'fs-core'),
            'fas fa-pause' => __('pause', 'fs-core'),
            'fas fa-pause-circle' => __('pause-circle', 'fs-core'),
            'far fa-pause-circle' => __('pause-circle', 'fs-core'),
            'fas fa-paw' => __('paw', 'fs-core'),
            'fab fa-paypal' => __('paypal', 'fs-core'),
            'fas fa-pen-square' => __('pen-square', 'fs-core'),
            'fas fa-pencil-alt' => __('pencil-alt', 'fs-core'),
            'fas fa-people-carry' => __('people-carry', 'fs-core'),
            'fas fa-percent' => __('percent', 'fs-core'),
            'fab fa-periscope' => __('periscope', 'fs-core'),
            'fab fa-phabricator' => __('phabricator', 'fs-core'),
            'fab fa-phoenix-framework' => __('phoenix-framework', 'fs-core'),
            'fas fa-phone' => __('phone', 'fs-core'),
            'fas fa-phone-slash' => __('phone-slash', 'fs-core'),
            'fas fa-phone-square' => __('phone-square', 'fs-core'),
            'fas fa-phone-volume' => __('phone-volume', 'fs-core'),
            'fab fa-php' => __('php', 'fs-core'),
            'fab fa-pied-piper' => __('pied-piper', 'fs-core'),
            'fab fa-pied-piper-alt' => __('pied-piper-alt', 'fs-core'),
            'fab fa-pied-piper-hat' => __('pied-piper-hat', 'fs-core'),
            'fab fa-pied-piper-pp' => __('pied-piper-pp', 'fs-core'),
            'fas fa-piggy-bank' => __('piggy-bank', 'fs-core'),
            'fas fa-pills' => __('pills', 'fs-core'),
            'fab fa-pinterest' => __('pinterest', 'fs-core'),
            'fab fa-pinterest-p' => __('pinterest-p', 'fs-core'),
            'fab fa-pinterest-square' => __('pinterest-square', 'fs-core'),
            'fas fa-plane' => __('plane', 'fs-core'),
            'fas fa-play' => __('play', 'fs-core'),
            'fas fa-play-circle' => __('play-circle', 'fs-core'),
            'far fa-play-circle' => __('play-circle', 'fs-core'),
            'fab fa-playstation' => __('playstation', 'fs-core'),
            'fas fa-plug' => __('plug', 'fs-core'),
            'fas fa-plus' => __('plus', 'fs-core'),
            'fas fa-plus-circle' => __('plus-circle', 'fs-core'),
            'fas fa-plus-square' => __('plus-square', 'fs-core'),
            'far fa-plus-square' => __('plus-square', 'fs-core'),
            'fas fa-podcast' => __('podcast', 'fs-core'),
            'fas fa-poo' => __('poo', 'fs-core'),
            'fas fa-pound-sign' => __('pound-sign', 'fs-core'),
            'fas fa-power-off' => __('power-off', 'fs-core'),
            'fas fa-prescription-bottle' => __('prescription-bottle', 'fs-core'),
            'fas fa-prescription-bottle-alt' => __('prescription-bottle-alt', 'fs-core'),
            'fas fa-print' => __('print', 'fs-core'),
            'fas fa-procedures' => __('procedures', 'fs-core'),
            'fab fa-product-hunt' => __('product-hunt', 'fs-core'),
            'fab fa-pushed' => __('pushed', 'fs-core'),
            'fas fa-puzzle-piece' => __('puzzle-piece', 'fs-core'),
            'fab fa-python' => __('python', 'fs-core'),
            'fab fa-qq' => __('qq', 'fs-core'),
            'fas fa-qrcode' => __('qrcode', 'fs-core'),
            'fas fa-question' => __('question', 'fs-core'),
            'fas fa-question-circle' => __('question-circle', 'fs-core'),
            'far fa-question-circle' => __('question-circle', 'fs-core'),
            'fas fa-quidditch' => __('quidditch', 'fs-core'),
            'fab fa-quinscape' => __('quinscape', 'fs-core'),
            'fab fa-quora' => __('quora', 'fs-core'),
            'fas fa-quote-left' => __('quote-left', 'fs-core'),
            'fas fa-quote-right' => __('quote-right', 'fs-core'),
            'fas fa-random' => __('random', 'fs-core'),
            'fab fa-ravelry' => __('ravelry', 'fs-core'),
            'fab fa-react' => __('react', 'fs-core'),
            'fab fa-readme' => __('readme', 'fs-core'),
            'fab fa-rebel' => __('rebel', 'fs-core'),
            'fas fa-recycle' => __('recycle', 'fs-core'),
            'fab fa-red-river' => __('red-river', 'fs-core'),
            'fab fa-reddit' => __('reddit', 'fs-core'),
            'fab fa-reddit-alien' => __('reddit-alien', 'fs-core'),
            'fab fa-reddit-square' => __('reddit-square', 'fs-core'),
            'fas fa-redo' => __('redo', 'fs-core'),
            'fas fa-redo-alt' => __('redo-alt', 'fs-core'),
            'fas fa-registered' => __('registered', 'fs-core'),
            'far fa-registered' => __('registered', 'fs-core'),
            'fab fa-rendact' => __('rendact', 'fs-core'),
            'fab fa-renren' => __('renren', 'fs-core'),
            'fas fa-reply' => __('reply', 'fs-core'),
            'fas fa-reply-all' => __('reply-all', 'fs-core'),
            'fab fa-replyd' => __('replyd', 'fs-core'),
            'fab fa-resolving' => __('resolving', 'fs-core'),
            'fas fa-retweet' => __('retweet', 'fs-core'),
            'fas fa-ribbon' => __('ribbon', 'fs-core'),
            'fas fa-road' => __('road', 'fs-core'),
            'fas fa-rocket' => __('rocket', 'fs-core'),
            'fab fa-rocketchat' => __('rocketchat', 'fs-core'),
            'fab fa-rockrms' => __('rockrms', 'fs-core'),
            'fas fa-rss' => __('rss', 'fs-core'),
            'fas fa-rss-square' => __('rss-square', 'fs-core'),
            'fas fa-ruble-sign' => __('ruble-sign', 'fs-core'),
            'fas fa-rupee-sign' => __('rupee-sign', 'fs-core'),
            'fab fa-safari' => __('safari', 'fs-core'),
            'fab fa-sass' => __('sass', 'fs-core'),
            'fas fa-save' => __('save', 'fs-core'),
            'far fa-save' => __('save', 'fs-core'),
            'fab fa-schlix' => __('schlix', 'fs-core'),
            'fab fa-scribd' => __('scribd', 'fs-core'),
            'fas fa-search' => __('search', 'fs-core'),
            'fas fa-search-minus' => __('search-minus', 'fs-core'),
            'fas fa-search-plus' => __('search-plus', 'fs-core'),
            'fab fa-searchengin' => __('searchengin', 'fs-core'),
            'fas fa-seedling' => __('seedling', 'fs-core'),
            'fab fa-sellcast' => __('sellcast', 'fs-core'),
            'fab fa-sellsy' => __('sellsy', 'fs-core'),
            'fas fa-server' => __('server', 'fs-core'),
            'fab fa-servicestack' => __('servicestack', 'fs-core'),
            'fas fa-share' => __('share', 'fs-core'),
            'fas fa-share-alt' => __('share-alt', 'fs-core'),
            'fas fa-share-alt-square' => __('share-alt-square', 'fs-core'),
            'fas fa-share-square' => __('share-square', 'fs-core'),
            'far fa-share-square' => __('share-square', 'fs-core'),
            'fas fa-shekel-sign' => __('shekel-sign', 'fs-core'),
            'fas fa-shield-alt' => __('shield-alt', 'fs-core'),
            'fas fa-ship' => __('ship', 'fs-core'),
            'fas fa-shipping-fast' => __('shipping-fast', 'fs-core'),
            'fab fa-shirtsinbulk' => __('shirtsinbulk', 'fs-core'),
            'fas fa-shopping-bag' => __('shopping-bag', 'fs-core'),
            'fas fa-shopping-basket' => __('shopping-basket', 'fs-core'),
            'fas fa-shopping-cart' => __('shopping-cart', 'fs-core'),
            'fas fa-shower' => __('shower', 'fs-core'),
            'fas fa-sign' => __('sign', 'fs-core'),
            'fas fa-sign-in-alt' => __('sign-in-alt', 'fs-core'),
            'fas fa-sign-language' => __('sign-language', 'fs-core'),
            'fas fa-sign-out-alt' => __('sign-out-alt', 'fs-core'),
            'fas fa-signal' => __('signal', 'fs-core'),
            'fab fa-simplybuilt' => __('simplybuilt', 'fs-core'),
            'fab fa-sistrix' => __('sistrix', 'fs-core'),
            'fas fa-sitemap' => __('sitemap', 'fs-core'),
            'fab fa-skyatlas' => __('skyatlas', 'fs-core'),
            'fab fa-skype' => __('skype', 'fs-core'),
            'fab fa-slack' => __('slack', 'fs-core'),
            'fab fa-slack-hash' => __('slack-hash', 'fs-core'),
            'fas fa-sliders-h' => __('sliders-h', 'fs-core'),
            'fab fa-slideshare' => __('slideshare', 'fs-core'),
            'fas fa-smile' => __('smile', 'fs-core'),
            'far fa-smile' => __('smile', 'fs-core'),
            'fas fa-smoking' => __('smoking', 'fs-core'),
            'fab fa-snapchat' => __('snapchat', 'fs-core'),
            'fab fa-snapchat-ghost' => __('snapchat-ghost', 'fs-core'),
            'fab fa-snapchat-square' => __('snapchat-square', 'fs-core'),
            'fas fa-snowflake' => __('snowflake', 'fs-core'),
            'far fa-snowflake' => __('snowflake', 'fs-core'),
            'fas fa-sort' => __('sort', 'fs-core'),
            'fas fa-sort-alpha-down' => __('sort-alpha-down', 'fs-core'),
            'fas fa-sort-alpha-up' => __('sort-alpha-up', 'fs-core'),
            'fas fa-sort-amount-down' => __('sort-amount-down', 'fs-core'),
            'fas fa-sort-amount-up' => __('sort-amount-up', 'fs-core'),
            'fas fa-sort-down' => __('sort-down', 'fs-core'),
            'fas fa-sort-numeric-down' => __('sort-numeric-down', 'fs-core'),
            'fas fa-sort-numeric-up' => __('sort-numeric-up', 'fs-core'),
            'fas fa-sort-up' => __('sort-up', 'fs-core'),
            'fab fa-soundcloud' => __('soundcloud', 'fs-core'),
            'fas fa-space-shuttle' => __('space-shuttle', 'fs-core'),
            'fab fa-speakap' => __('speakap', 'fs-core'),
            'fas fa-spinner' => __('spinner', 'fs-core'),
            'fab fa-spotify' => __('spotify', 'fs-core'),
            'fas fa-square' => __('square', 'fs-core'),
            'far fa-square' => __('square', 'fs-core'),
            'fas fa-square-full' => __('square-full', 'fs-core'),
            'fab fa-stack-exchange' => __('stack-exchange', 'fs-core'),
            'fab fa-stack-overflow' => __('stack-overflow', 'fs-core'),
            'fas fa-star' => __('star', 'fs-core'),
            'far fa-star' => __('star', 'fs-core'),
            'fas fa-star-half' => __('star-half', 'fs-core'),
            'far fa-star-half' => __('star-half', 'fs-core'),
            'fab fa-staylinked' => __('staylinked', 'fs-core'),
            'fab fa-steam' => __('steam', 'fs-core'),
            'fab fa-steam-square' => __('steam-square', 'fs-core'),
            'fab fa-steam-symbol' => __('steam-symbol', 'fs-core'),
            'fas fa-step-backward' => __('step-backward', 'fs-core'),
            'fas fa-step-forward' => __('step-forward', 'fs-core'),
            'fas fa-stethoscope' => __('stethoscope', 'fs-core'),
            'fab fa-sticker-mule' => __('sticker-mule', 'fs-core'),
            'fas fa-sticky-note' => __('sticky-note', 'fs-core'),
            'far fa-sticky-note' => __('sticky-note', 'fs-core'),
            'fas fa-stop' => __('stop', 'fs-core'),
            'fas fa-stop-circle' => __('stop-circle', 'fs-core'),
            'far fa-stop-circle' => __('stop-circle', 'fs-core'),
            'fas fa-stopwatch' => __('stopwatch', 'fs-core'),
            'fab fa-strava' => __('strava', 'fs-core'),
            'fas fa-street-view' => __('street-view', 'fs-core'),
            'fas fa-strikethrough' => __('strikethrough', 'fs-core'),
            'fab fa-stripe' => __('stripe', 'fs-core'),
            'fab fa-stripe-s' => __('stripe-s', 'fs-core'),
            'fab fa-studiovinari' => __('studiovinari', 'fs-core'),
            'fab fa-stumbleupon' => __('stumbleupon', 'fs-core'),
            'fab fa-stumbleupon-circle' => __('stumbleupon-circle', 'fs-core'),
            'fas fa-subscript' => __('subscript', 'fs-core'),
            'fas fa-subway' => __('subway', 'fs-core'),
            'fas fa-suitcase' => __('suitcase', 'fs-core'),
            'fas fa-sun' => __('sun', 'fs-core'),
            'far fa-sun' => __('sun', 'fs-core'),
            'fab fa-superpowers' => __('superpowers', 'fs-core'),
            'fas fa-superscript' => __('superscript', 'fs-core'),
            'fab fa-supple' => __('supple', 'fs-core'),
            'fas fa-sync' => __('sync', 'fs-core'),
            'fas fa-sync-alt' => __('sync-alt', 'fs-core'),
            'fas fa-syringe' => __('syringe', 'fs-core'),
            'fas fa-table' => __('table', 'fs-core'),
            'fas fa-table-tennis' => __('table-tennis', 'fs-core'),
            'fas fa-tablet' => __('tablet', 'fs-core'),
            'fas fa-tablet-alt' => __('tablet-alt', 'fs-core'),
            'fas fa-tablets' => __('tablets', 'fs-core'),
            'fas fa-tachometer-alt' => __('tachometer-alt', 'fs-core'),
            'fas fa-tag' => __('tag', 'fs-core'),
            'fas fa-tags' => __('tags', 'fs-core'),
            'fas fa-tape' => __('tape', 'fs-core'),
            'fas fa-tasks' => __('tasks', 'fs-core'),
            'fas fa-taxi' => __('taxi', 'fs-core'),
            'fab fa-telegram' => __('telegram', 'fs-core'),
            'fab fa-telegram-plane' => __('telegram-plane', 'fs-core'),
            'fab fa-tencent-weibo' => __('tencent-weibo', 'fs-core'),
            'fas fa-terminal' => __('terminal', 'fs-core'),
            'fas fa-text-height' => __('text-height', 'fs-core'),
            'fas fa-text-width' => __('text-width', 'fs-core'),
            'fas fa-th' => __('th', 'fs-core'),
            'fas fa-th-large' => __('th-large', 'fs-core'),
            'fas fa-th-list' => __('th-list', 'fs-core'),
            'fab fa-themeisle' => __('themeisle', 'fs-core'),
            'fas fa-thermometer' => __('thermometer', 'fs-core'),
            'fas fa-thermometer-empty' => __('thermometer-empty', 'fs-core'),
            'fas fa-thermometer-full' => __('thermometer-full', 'fs-core'),
            'fas fa-thermometer-half' => __('thermometer-half', 'fs-core'),
            'fas fa-thermometer-quarter' => __('thermometer-quarter', 'fs-core'),
            'fas fa-thermometer-three-quarters' => __('thermometer-three-quarters', 'fs-core'),
            'fas fa-thumbs-down' => __('thumbs-down', 'fs-core'),
            'far fa-thumbs-down' => __('thumbs-down', 'fs-core'),
            'fas fa-thumbs-up' => __('thumbs-up', 'fs-core'),
            'far fa-thumbs-up' => __('thumbs-up', 'fs-core'),
            'fas fa-thumbtack' => __('thumbtack', 'fs-core'),
            'fas fa-ticket-alt' => __('ticket-alt', 'fs-core'),
            'fas fa-times' => __('times', 'fs-core'),
            'fas fa-times-circle' => __('times-circle', 'fs-core'),
            'far fa-times-circle' => __('times-circle', 'fs-core'),
            'fas fa-tint' => __('tint', 'fs-core'),
            'fas fa-toggle-off' => __('toggle-off', 'fs-core'),
            'fas fa-toggle-on' => __('toggle-on', 'fs-core'),
            'fas fa-trademark' => __('trademark', 'fs-core'),
            'fas fa-train' => __('train', 'fs-core'),
            'fas fa-transgender' => __('transgender', 'fs-core'),
            'fas fa-transgender-alt' => __('transgender-alt', 'fs-core'),
            'fas fa-trash' => __('trash', 'fs-core'),
            'fas fa-trash-alt' => __('trash-alt', 'fs-core'),
            'far fa-trash-alt' => __('trash-alt', 'fs-core'),
            'fas fa-tree' => __('tree', 'fs-core'),
            'fab fa-trello' => __('trello', 'fs-core'),
            'fab fa-tripadvisor' => __('tripadvisor', 'fs-core'),
            'fas fa-trophy' => __('trophy', 'fs-core'),
            'fas fa-truck' => __('truck', 'fs-core'),
            'fas fa-truck-loading' => __('truck-loading', 'fs-core'),
            'fas fa-truck-moving' => __('truck-moving', 'fs-core'),
            'fas fa-tty' => __('tty', 'fs-core'),
            'fab fa-tumblr' => __('tumblr', 'fs-core'),
            'fab fa-tumblr-square' => __('tumblr-square', 'fs-core'),
            'fas fa-tv' => __('tv', 'fs-core'),
            'fab fa-twitch' => __('twitch', 'fs-core'),
            'fab fa-twitter' => __('twitter', 'fs-core'),
            'fab fa-twitter-square' => __('twitter-square', 'fs-core'),
            'fab fa-typo3' => __('typo3', 'fs-core'),
            'fab fa-uber' => __('uber', 'fs-core'),
            'fab fa-uikit' => __('uikit', 'fs-core'),
            'fas fa-umbrella' => __('umbrella', 'fs-core'),
            'fas fa-underline' => __('underline', 'fs-core'),
            'fas fa-undo' => __('undo', 'fs-core'),
            'fas fa-undo-alt' => __('undo-alt', 'fs-core'),
            'fab fa-uniregistry' => __('uniregistry', 'fs-core'),
            'fas fa-universal-access' => __('universal-access', 'fs-core'),
            'fas fa-university' => __('university', 'fs-core'),
            'fas fa-unlink' => __('unlink', 'fs-core'),
            'fas fa-unlock' => __('unlock', 'fs-core'),
            'fas fa-unlock-alt' => __('unlock-alt', 'fs-core'),
            'fab fa-untappd' => __('untappd', 'fs-core'),
            'fas fa-upload' => __('upload', 'fs-core'),
            'fab fa-usb' => __('usb', 'fs-core'),
            'fas fa-user' => __('user', 'fs-core'),
            'far fa-user' => __('user', 'fs-core'),
            'fas fa-user-circle' => __('user-circle', 'fs-core'),
            'far fa-user-circle' => __('user-circle', 'fs-core'),
            'fas fa-user-md' => __('user-md', 'fs-core'),
            'fas fa-user-plus' => __('user-plus', 'fs-core'),
            'fas fa-user-secret' => __('user-secret', 'fs-core'),
            'fas fa-user-times' => __('user-times', 'fs-core'),
            'fas fa-users' => __('users', 'fs-core'),
            'fab fa-ussunnah' => __('ussunnah', 'fs-core'),
            'fas fa-utensil-spoon' => __('utensil-spoon', 'fs-core'),
            'fas fa-utensils' => __('utensils', 'fs-core'),
            'fab fa-vaadin' => __('vaadin', 'fs-core'),
            'fas fa-venus' => __('venus', 'fs-core'),
            'fas fa-venus-double' => __('venus-double', 'fs-core'),
            'fas fa-venus-mars' => __('venus-mars', 'fs-core'),
            'fab fa-viacoin' => __('viacoin', 'fs-core'),
            'fab fa-viadeo' => __('viadeo', 'fs-core'),
            'fab fa-viadeo-square' => __('viadeo-square', 'fs-core'),
            'fas fa-vial' => __('vial', 'fs-core'),
            'fas fa-vials' => __('vials', 'fs-core'),
            'fab fa-viber' => __('viber', 'fs-core'),
            'fas fa-video' => __('video', 'fs-core'),
            'fas fa-video-slash' => __('video-slash', 'fs-core'),
            'fab fa-vimeo' => __('vimeo', 'fs-core'),
            'fab fa-vimeo-square' => __('vimeo-square', 'fs-core'),
            'fab fa-vimeo-v' => __('vimeo-v', 'fs-core'),
            'fab fa-vine' => __('vine', 'fs-core'),
            'fab fa-vk' => __('vk', 'fs-core'),
            'fab fa-vnv' => __('vnv', 'fs-core'),
            'fas fa-volleyball-ball' => __('volleyball-ball', 'fs-core'),
            'fas fa-volume-down' => __('volume-down', 'fs-core'),
            'fas fa-volume-off' => __('volume-off', 'fs-core'),
            'fas fa-volume-up' => __('volume-up', 'fs-core'),
            'fab fa-vuejs' => __('vuejs', 'fs-core'),
            'fas fa-warehouse' => __('warehouse', 'fs-core'),
            'fab fa-weibo' => __('weibo', 'fs-core'),
            'fas fa-weight' => __('weight', 'fs-core'),
            'fab fa-weixin' => __('weixin', 'fs-core'),
            'fab fa-whatsapp' => __('whatsapp', 'fs-core'),
            'fab fa-whatsapp-square' => __('whatsapp-square', 'fs-core'),
            'fas fa-wheelchair' => __('wheelchair', 'fs-core'),
            'fab fa-whmcs' => __('whmcs', 'fs-core'),
            'fas fa-wifi' => __('wifi', 'fs-core'),
            'fab fa-wikipedia-w' => __('wikipedia-w', 'fs-core'),
            'fas fa-window-close' => __('window-close', 'fs-core'),
            'far fa-window-close' => __('window-close', 'fs-core'),
            'fas fa-window-maximize' => __('window-maximize', 'fs-core'),
            'far fa-window-maximize' => __('window-maximize', 'fs-core'),
            'fas fa-window-minimize' => __('window-minimize', 'fs-core'),
            'far fa-window-minimize' => __('window-minimize', 'fs-core'),
            'fas fa-window-restore' => __('window-restore', 'fs-core'),
            'far fa-window-restore' => __('window-restore', 'fs-core'),
            'fab fa-windows' => __('windows', 'fs-core'),
            'fas fa-wine-glass' => __('wine-glass', 'fs-core'),
            'fas fa-won-sign' => __('won-sign', 'fs-core'),
            'fab fa-wordpress' => __('wordpress', 'fs-core'),
            'fab fa-wordpress-simple' => __('wordpress-simple', 'fs-core'),
            'fab fa-wpbeginner' => __('wpbeginner', 'fs-core'),
            'fab fa-wpexplorer' => __('wpexplorer', 'fs-core'),
            'fab fa-wpforms' => __('wpforms', 'fs-core'),
            'fas fa-wrench' => __('wrench', 'fs-core'),
            'fas fa-x-ray' => __('x-ray', 'fs-core'),
            'fab fa-xbox' => __('xbox', 'fs-core'),
            'fab fa-xing' => __('xing', 'fs-core'),
            'fab fa-xing-square' => __('xing-square', 'fs-core'),
            'fab fa-y-combinator' => __('y-combinator', 'fs-core'),
            'fab fa-yahoo' => __('yahoo', 'fs-core'),
            'fab fa-yandex' => __('yandex', 'fs-core'),
            'fab fa-yandex-international' => __('yandex-international', 'fs-core'),
            'fab fa-yelp' => __('yelp', 'fs-core'),
            'fas fa-yen-sign' => __('yen-sign', 'fs-core'),
            'fab fa-yoast' => __('yoast', 'fs-core'),
            'fab fa-youtube' => __('youtube', 'fs-core'),
            'fab fa-youtube-square' => __('youtube-square', 'fs-core'),
        );

    }


    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_twitter_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://twitter.com/intent/tweet?text=' . $post_excerpt . '\x20' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_pinterest_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://www.pinterest.com/pin/create/button/?url=' . $post_url . '&media=' . $post_thumb);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_facebook_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://www.facebook.com/sharer.php?u=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_vk_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://vkontakte.ru/share.php?url=' . $post_url . '&title=' . $post_title . '&description=' . $post_excerpt . '&image=' . $post_thumb);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_linkedin_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://www.linkedin.com/shareArticle?mini=true&url=' . $post_url . '&title=' . $post_title . '&summary=' . $post_excerpt . '&source=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_odnoklassniki_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://connect.ok.ru/offer?url=' . $post_url . '&title=' . $post_title . '&imageUrl=' . $post_thumb);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_tumblr_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://tumblr.com/share/link?url=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_google_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://plus.google.com/share?url=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_digg_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://digg.com/submit?url=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_reddit_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://reddit.com/submit?url=' . $post_url . '&title=' . $post_title);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_stumbleupon_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://www.stumbleupon.com/submit?url=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_pocket_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://getpocket.com/edit?url=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_whatsapp_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://api.whatsapp.com/send?text=*' . $post_title . '*%0A' . $post_excerpt . '%0A' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_xing_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://www.xing.com/app/user?op=share&url=' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_email_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('mailto:?subject=' . $post_title . '&body=' . $post_excerpt . '\n' . $post_url);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_telegram_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://telegram.me/share/url?url=' . $post_url . '&text=' . $post_excerpt);

    }

    /**
     * @param $post_title
     * @param $post_url
     * @param $post_thumb
     * @param $post_excerpt
     *
     * @return string
     */
    public static function get_skype_share_link($post_title, $post_url, $post_thumb, $post_excerpt)
    {

        return esc_url('https://web.skype.com/share?url=' . $post_url);

    }

    /**
     * @param $post_id
     *
     * @return string
     */
    public static function get_social_sharing_url($post_id)
    {

        return urlencode(get_permalink($post_id));

    }

    /**
     * @param $post_id
     *
     * @return string
     */
    public static function get_social_sharing_title($post_id)
    {

        return htmlspecialchars(urlencode(html_entity_decode(get_the_title($post_id), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8');

    }

    /**
     * @param $post_id
     *
     * @return string
     */
    public static function get_social_sharing_excerpt($post_id)
    {

        return htmlspecialchars(urlencode(html_entity_decode(get_the_excerpt($post_id), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8');

    }

    /**
     * @param $post_id
     *
     * @return array|false
     */
    public static function get_social_sharing_thumbnail($post_id)
    {

        if (!empty(get_post_thumbnail_id($post_id))):

            return wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'full');

        else:

            return 0;

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_twitter_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        $excerpt = self::get_social_sharing_excerpt($post_id);

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_twitter_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-twitter">

                <i class="fab fa-twitter"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_twitter_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-twitter">

                <?php echo esc_html('Twitter'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_pinterest_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_pinterest_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-pinterest">

                <i class="fab fa-pinterest-p"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_pinterest_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-pinterest">

                <?php echo esc_html('Pinterest'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_facebook_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_facebook_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-facebook">

                <i class="fab fa-facebook-f"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_facebook_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-facebook">

                <?php echo esc_html('Facebook'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_vk_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_vk_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-vk">

                <i class="fab fa-vk"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_vk_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-vk">

                <?php echo esc_html('VK'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_linkedin_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_linkedin_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-linkedin">

                <i class="fab fa-linkedin"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_linkedin_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-linkedin">

                <?php echo esc_html('Linkedin'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_odnoklassniki_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_odnoklassniki_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-odnoklassniki">

                <i class="fab fa-odnoklassniki"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_odnoklassniki_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-odnoklassniki">

                <?php echo esc_html('Odnoklassniki'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_tumblr_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_tumblr_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-tumblr">

                <i class="fab fa-tumblr"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_tumblr_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-tumblr">

                <?php echo esc_html('Tumblr'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_google_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_google_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-google">

                <i class="fab fa-google"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_google_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-google">

                <?php echo esc_html('Google'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_digg_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_digg_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-digg">

                <i class="fab fa-digg"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_digg_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-digg">

                <?php echo esc_html('Digg'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_reddit_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_reddit_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-reddit">

                <i class="fab fa-reddit"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_reddit_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-reddit">

                <?php echo esc_html('Reddit'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_stumbleupon_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_stumbleupon_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-stumbleupon">

                <i class="fab fa-stumbleupon"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_stumbleupon_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-stumbleupon">

                <?php echo esc_html('Stumbleupon'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_pocket_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_pocket_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-pocket">

                <i class="fab fa-get-pocket"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_pocket_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-pocket">

                <?php echo esc_html('Pocket'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_whatsapp_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_whatsapp_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-whatsapp">

                <i class="fab fa-whatsapp"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_whatsapp_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-whatsapp">

                <?php echo esc_html('Whatsapp'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_xing_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_xing_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-xing">

                <i class="fab fa-xing"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_xing_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-xing">

                <?php echo esc_html('Xing'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_email_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_email_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-email">

                <i class="fa fa-envelope"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_email_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-email">

                <?php echo esc_html('Email'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_telegram_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_telegram_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-telegram">

                <i class="fab fa-telegram"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_telegram_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-telegram">

                <?php echo esc_html('Telegram'); ?>

            </a>

        <?php

        endif;

    }

    /**
     * @param $post_id
     * @param string $type
     */
    public static function the_skype_share_link_render($post_id, $type = 'default')
    {

        $title = self::get_social_sharing_title($post_id);

        $url = self::get_social_sharing_url($post_id);

        $excerpt = self::get_social_sharing_excerpt($post_id);

        $thumbnail = self::get_social_sharing_thumbnail($post_id)[0];

        if ($type === 'default'):

            ?>

            <a href="<?php echo esc_url(self::get_skype_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               target="_blank" class="share-link share-link-default  share-link-skype">

                <i class="fab fa-skype"></i>

            </a>

        <?php

        endif;

        if ($type === 'simple'):

            ?>

            <a href="<?php echo esc_url(self::get_skype_share_link($title, $url, $thumbnail, $excerpt)); ?>"
               class="share-link share-link-simple share-link-skype">

                <?php echo esc_html('Skype'); ?>

            </a>

        <?php

        endif;

    }

}