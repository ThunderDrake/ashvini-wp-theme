<?php defined('ABSPATH') || exit;

/**
 * Class FSD_Customizer
 */
class FSD_Customizer extends FSD_Core
{
	
	/**
	 * FSD_Customizer constructor.
	 */
	public function __construct()
	{
		
		/* init */
		$this->init();
		
		
	}
	
	/**
	 * init
	 */
	public function init()
	{
		
		$this->prepare_custom_fonts();
		
		$this->prepare_typekit_fonts();
		
		$this->kirki_init();
		
		$this->kirki_branding();
		
		$this->kirki_typography();
		
		$this->kirki_colors();
		
		$this->kirki_navigation();
		
		$this->kirki_footer();
		
		$this->kirki_blog();
		
		$this->kirki_career();
		
		$this->kirki_error_page();
		
		$this->kirki_social();
		
		$this->kirki_optimization();
		
		if (class_exists('WooCommerce')):
			
			$this->kirki_shop();
		
		endif;
		
	}
	
	/**
	 * @param $array
	 * @param $key
	 * @param $key_value
	 *
	 * @return string
	 */
	public function is_in_array($array, $key, $key_value)
	{
		
		$within_array = 'no';
		
		foreach ($array as $k => $v) :
			
			if (is_array($v)) :
				
				$within_array = $this->is_in_array($v, $key, $key_value);
				
				if ($within_array == 'yes') :
					
					break;
				
				endif;
			
			else :
				
				if ($v == $key_value && $k == $key) :
					
					$within_array = 'yes';
					
					break;
				
				endif;
			
			endif;
		
		endforeach;
		
		return $within_array;
		
	}
	
	/**
	 * prepare adobe typekit fonts
	 */
	public function prepare_typekit_fonts()
	{
		
		/* check if exists typekit loader */
		if (class_exists('BSF_Analytics_Loader')):
			
			/* get typekit fonts option */
			$fonts = get_option('custom-typekit-fonts');
			
			/* check if typekit fonts is empty */
			if (!empty($fonts)) :
				
				/* get fonts details array */
				$fonts = $fonts['custom-typekit-font-details'];
				
				/* check if fonts details is empty */
				if (!empty($fonts)) :
					
					/* fonts loop */
					foreach ($fonts as $key => $font) :
						
						/* added to new fonts typekit fonts */
						$this->new_fonts[$key] = [
							'id' => implode($font['css_names']),
							'text' => $font['family'],
							'variant' => $font['weights']
						];
					
					endforeach;
				
				endif;
			
			endif;
			
			unset($fonts);
		
		endif;
		
	}
	
	/**
	 * prepare custom fonts
	 */
	public function prepare_custom_fonts()
	{
		
		if (class_exists('Kirki') && class_exists('ACF')):
			
			/* empty fonts array */
			$fonts = [];
			
			/* repeater loop */
			if (have_rows('field_custom_fonts', 'option')):
				
				while (have_rows('field_custom_fonts', 'option')) : the_row();
					
					/* get font title */
					$title = FSD_Helper::get_sub_field('field_font_title');
					
					/* add title to the fonts */
					$fonts[$title] = $title;
				
				endwhile;
			
			endif;
			
			/* check if fonts empty */
			if (!empty($fonts)) :
				
				/* fonts loop */
				foreach ($fonts as $font => $key) :
					
					/* added new font to the new fonts */
					$this->new_fonts[$font] = [
						'id' => $font,
						'text' => $font,
						'variant' => ['100', '100italic', '200', '200italic', '300', '300italic', '400', '400italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', 'regular', 'italic']
					];
				
				endforeach;
			
			endif;
			
			unset($fonts);
		
		endif;
		
	}
	
	/**
	 * init
	 */
	public function kirki_init()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_config('fs-theme',
				[
					'capability' => 'read',
					'option_type' => 'theme_mod',
					'disable_output' => false
				]
			);
			
			Kirki::add_panel('theme_options', [
				'priority' => 1,
				'title' => esc_attr__('Theme Options', 'fs-core'),
			]);
		
		endif;
		
	}
	
	/**
	 * branding
	 */
	public function kirki_branding()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_branding', [
				'title' => esc_attr__('Branding', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general branding values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 1,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'image',
				'settings' => 'branding-logotype',
				'label' => esc_html__('Logotype', 'fs-core'),
				'description' => esc_html__('Upload your Logotype', 'fs-core'),
				'section' => 'theme_options_branding',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'image',
				'settings' => 'branding-logotype-white',
				'label' => esc_html__('Logotype White', 'fs-core'),
				'description' => esc_html__('Upload your Logotype (white version)', 'fs-core'),
				'section' => 'theme_options_branding',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'slider',
				'settings' => 'branding-logotype-width',
				'label' => esc_html__('Logotype Width', 'fs-core'),
				'description' => esc_attr__('Logotype Width', 'fs-core'),
				'section' => 'theme_options_branding',
				'default' => 150,
				'choices' => [
					'min' => 50,
					'max' => 300,
					'step' => 1,
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'editor',
				'settings' => 'branding-copyright',
				'label' => esc_html__('Copyright', 'fs-core'),
				'description' => esc_attr__('Input your copyright (use {year} to display current year)', 'fs-core'),
				'section' => 'theme_options_branding',
				'default' => esc_html__('© {year} Beauty Store. All rights reserved.', 'fs-core'),
			]);
		
		endif;
		
	}
	
	/**
	 * typography
	 */
	public function kirki_typography()
	{
		
		if (class_exists('Kirki')):
			
			if (!empty($this->new_fonts)) :
				
				foreach ($this->new_fonts as $new_font) :
					
					if ($this->is_in_array(self::$children, 'id', $new_font['id']) == 'no') :
						
						self::$children[] = [
							'id' => $new_font['id'],
							'text' => $new_font['text']
						];
						
						self::$variants[$new_font['id']] = $new_font['variant'];
					
					endif;
				
				endforeach;
			
			endif;
			
			$custom_choice['families']['custom'] = [
				'text' => esc_attr__('Custom Fonts', 'fs-core'),
				'children' => self::$children
			];
			
			$fonts = [
				'fonts' => $custom_choice
			];
			
			Kirki::add_section('theme_options_typography', [
				'title' => esc_attr__('Typography', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general typography values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 2,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'typography',
				'settings' => 'primary-font',
				'section' => 'theme_options_typography',
				'label' => esc_html__('Primary Font', 'fs-core'),
				'description' => esc_attr__('Select the primary font', 'fs-core'),
				'transport' => 'auto',
				'default' => [
					'font-family' => 'HKGrotesk',
				],
				'choices' => $fonts,
				'output' => [
					[
						'choice' => 'font-family',
						'element' => ':root',
						'property' => '--heading-font',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'typography',
				'settings' => 'text-font',
				'section' => 'theme_options_typography',
				'label' => esc_html__('Text Font', 'fs-core'),
				'description' => esc_attr__('Select the text font', 'fs-core'),
				'transport' => 'auto',
				'default' => [
					'font-family' => 'HKGrotesk',
				],
				'choices' => $fonts,
				'output' => [
					[
						'choice' => 'font-family',
						'element' => ':root',
						'property' => '--text-font',
						'context' => ['editor', 'front'],
					]
				]
			]);
		
		endif;
		
	}
	
	/**
	 * colors
	 */
	public function kirki_colors()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_colors', [
				'title' => esc_attr__('Colors', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general colors values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 3,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'color-dark',
				'label' => esc_html__('Dark Color', 'fs-core'),
				'description' => esc_html__('Select the dark color', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => '#000000',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--dark-color',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'color-white',
				'label' => esc_html__('White Color', 'fs-core'),
				'description' => esc_html__('Select the white color', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => '#ffffff',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--white-color',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'border-color',
				'label' => esc_html__('Border Colors', 'fs-core'),
				'description' => esc_html__('Select the border color', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => 'rgba(0,0,0,0.1)',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--border-color',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'color-primary-1',
				'label' => esc_html__('Primary Color 1', 'fs-core'),
				'description' => esc_html__('Select the primary color 1', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => '#FBF8F5',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--primary-color-1',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'color-primary-2',
				'label' => esc_html__('Primary Color 2', 'fs-core'),
				'description' => esc_html__('Select the primary color 2', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => '#ECF2F1',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--primary-color-2',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'color-primary-3',
				'label' => esc_html__('Primary Color 3', 'fs-core'),
				'description' => esc_html__('Select the primary color 3', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => '#FCF3F6',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--primary-color-3',
						'context' => ['editor', 'front'],
					]
				]
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'color',
				'settings' => 'color-primary-4',
				'label' => esc_html__('Primary Color 4', 'fs-core'),
				'description' => esc_html__('Select the primary color 4', 'fs-core'),
				'section' => 'theme_options_colors',
				'default' => '#F0ECE4',
				'choices' => [
					'alpha' => true,
				],
				'output' => [
					[
						'choice' => 'color',
						'element' => ':root',
						'property' => '--primary-color-4',
						'context' => ['editor', 'front'],
					]
				]
			]);
		
		endif;
		
	}
	
	/**
	 * navigation
	 */
	public function kirki_navigation()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_navigation', [
				'title' => esc_attr__('Navigation', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general navigation values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 4,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'navigation-type',
				'label' => esc_html__('Navigation Type', 'fs-core'),
				'description' => esc_attr__('Select the type of navigation menu', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'type-1',
				'choices' => [
					'type-1' => esc_html__('Type 1', 'fs-core'),
					'type-2' => esc_html__('Type 2', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'navigation-style',
				'label' => esc_html__('Navigation Style', 'fs-core'),
				'description' => esc_attr__('Select the type of navigation style', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'light',
				'choices' => [
					'light' => esc_html__('Light', 'fs-core'),
					'dark' => esc_html__('Dark', 'fs-core'),
					'transparent' => esc_html__('Transparent', 'fs-core'),
					'transparent-light' => esc_html__('Transparent-Light', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'navigation-state',
				'label' => esc_html__('Navigation State', 'fs-core'),
				'description' => esc_attr__('Select the navigation state', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'sticky',
				'choices' => [
					'sticky' => esc_html__('Sticky', 'fs-core'),
					'static' => esc_html__('Static', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'navigation-scroll-animation',
				'label' => esc_html__('Navigation Scroll Animation', 'fs-core'),
				'description' => esc_attr__('Select the type of navigation scroll animation', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'none',
				'choices' => [
					'none' => esc_html__('None', 'fs-core'),
					'fill' => esc_html__('Fill', 'fs-core'),
					'resize' => esc_html__('Resize', 'fs-core'),
					'fill-resize' => esc_html__('Fill & Resize', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'navigation-state',
						'operator' => '==',
						'value' => 'sticky',
					],
					[
						'setting' => 'navigation-style',
						'operator' => 'contains',
						'value' => ['transparent', 'transparent-light'],
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'navigation-scroll-animation-additional',
				'label' => esc_html__('Navigation Scroll Animation', 'fs-core'),
				'description' => esc_attr__('Select the type of navigation scroll animation', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'none',
				'choices' => [
					'none' => esc_html__('None', 'fs-core'),
					'resize' => esc_html__('Resize', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'navigation-state',
						'operator' => '==',
						'value' => 'sticky',
					],
					[
						'setting' => 'navigation-style',
						'operator' => 'contains',
						'value' => ['light', 'dark'],
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'megamenu-style',
				'label' => esc_html__('Megamenu Style', 'fs-core'),
				'description' => esc_attr__('Select the megamenu style', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'style-1',
				'choices' => [
					'style-1' => esc_html__('Style 1', 'fs-core'),
					'style-2' => esc_html__('Style 2', 'fs-core'),
					'style-3' => esc_html__('Style 3', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'megamenu-layout',
				'label' => esc_html__('Megamenu Layout', 'fs-core'),
				'description' => esc_attr__('Select the megamenu layout', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'wide',
				'choices' => [
					'wide' => esc_html__('Wide', 'fs-core'),
					'boxed' => esc_html__('Boxed', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'navigation-logotype-toggle',
				'label' => esc_html__('Logotype', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the logotype', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'navigation-authorization-toggle',
				'label' => esc_html__('Authorization Button', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the authorization button', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'navigation-search-button-toggle',
				'label' => esc_html__('Search Button', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the search button', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => '1',
			]);
			
			if (class_exists('WooCommerce')):
				
				Kirki::add_field('fs-theme', [
					'type' => 'toggle',
					'settings' => 'navigation-wishlist-toggle',
					'label' => esc_html__('Wishlist Button', 'fs-core'),
					'description' => esc_attr__('If true - will be displayed the wishlist button', 'fs-core'),
					'section' => 'theme_options_navigation',
					'default' => '1',
				]);
				
				Kirki::add_field('fs-theme', [
					'type' => 'toggle',
					'settings' => 'navigation-shopping-bag-toggle',
					'label' => esc_html__('Shopping Bag', 'fs-core'),
					'description' => esc_attr__('If true - will be displayed the shopping bag', 'fs-core'),
					'section' => 'theme_options_navigation',
					'default' => '1',
				]);
				
				Kirki::add_field('fs-theme', [
					'type' => 'image',
					'settings' => 'navigation-shopping-bag-icon',
					'label' => esc_html__('Upload Custom Icon', 'fs-core'),
					'description' => esc_attr__('You can upload your own bag icon instead of "Bag" title', 'fs-core'),
					'section' => 'theme_options_navigation',
					'active_callback' => [
						[
							'setting' => 'navigation-shopping-bag-toggle',
							'operator' => '==',
							'value' => true,
						]
					],
				]);
				
				Kirki::add_field('fs-theme', [
					'type' => 'image',
					'settings' => 'navigation-shopping-bag-icon-white',
					'label' => esc_html__('Upload Custom Icon (White)', 'fs-core'),
					'description' => esc_attr__('You can upload your own bag icon instead of "Bag" title', 'fs-core'),
					'section' => 'theme_options_navigation',
					'active_callback' => [
						[
							'setting' => 'navigation-shopping-bag-toggle',
							'operator' => '==',
							'value' => true,
						]
					],
				]);
				
				Kirki::add_field('fs-theme', [
					'type' => 'slider',
					'settings' => 'navigation-shopping-bag-icon-width',
					'label' => esc_html__('Icon Width', 'fs-core'),
					'description' => esc_attr__('If empty - width will be set to auto', 'fs-core'),
					'section' => 'theme_options_navigation',
					'default' => 0,
					'choices' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					],
				]);
				
				Kirki::add_field('fs-theme', [
					'type' => 'radio-buttonset',
					'settings' => 'shopping-bag-type',
					'label' => esc_html__('Shopping Bag Type', 'fs-core'),
					'description' => esc_attr__('Select the type of shopping bag', 'fs-core'),
					'section' => 'theme_options_navigation',
					'default' => 'static',
					'choices' => [
						'static' => esc_html__('Static', 'fs-core'),
						'dynamic' => esc_html__('Dynamic', 'fs-core'),
					],
					'active_callback' => [
						[
							'setting' => 'navigation-shopping-bag-toggle',
							'operator' => '==',
							'value' => true,
						]
					],
				]);
			
			endif;
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'navigation-top-banner-toggle',
				'label' => esc_html__('Top Banner', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the top banner', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => '1',
			]);
			
			Kirki::add_field('theme_config_id', [
				'type' => 'text',
				'settings' => 'navigation-top-banner-offer-text',
				'label' => esc_html__('Top banner text', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => esc_html__('PRESIDENTS’ DAY SALE: Save up to $200 with code PREZ200. Ends 2/20.', 'fs-core'),
				'description' => esc_html__('Input the top banner text', 'kirki'),
				'active_callback' => [
					[
						'setting' => 'navigation-top-banner-toggle',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('theme_config_id', [
				'type' => 'text',
				'settings' => 'navigation-top-banner-button-text',
				'label' => esc_html__('Top banner button text', 'kirki'),
				'section' => 'theme_options_navigation',
				'default' => esc_html__('Learn More', 'fs-core'),
				'description' => esc_html__('Input the top banner button text', 'kirki'),
				'active_callback' => [
					[
						'setting' => 'navigation-top-banner-toggle',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('theme_config_id', [
				'type' => 'text',
				'settings' => 'navigation-top-banner-button-link',
				'label' => esc_html__('Top banner button link', 'kirki'),
				'section' => 'theme_options_navigation',
				'default' => '#',
				'description' => esc_html__('Input the top banner button link', 'kirki'),
				'active_callback' => [
					[
						'setting' => 'navigation-top-banner-toggle',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('theme_config_id', [
				'type' => 'select',
				'settings' => 'navigation-top-banner-button-link-target',
				'label' => esc_html__('URL Target', 'fs-core'),
				'description' => esc_attr__('Select the type of url target', 'fs-core'),
				'section' => 'theme_options_navigation',
				'default' => 'self',
				'choices' => [
					'self' => esc_html__('Self', 'fs-core'),
					'_blank' => esc_html__('Blank', 'fs-core'),
					'top' => esc_html__('Top', 'fs-core'),
					'parent' => esc_html__('Parent', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'navigation-top-banner-toggle',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
		
		endif;
		
	}
	
	/**
	 * footer
	 */
	public function kirki_footer()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_footer', [
				'title' => esc_attr__('Footer', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general footer values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 5,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'footer-widgets-area',
				'label' => esc_html__('Widgets Area', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the widgets area', 'fs-core'),
				'section' => 'theme_options_footer',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'footer-copyright-toggle',
				'label' => esc_html__('Copyright', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the copyright', 'fs-core'),
				'section' => 'theme_options_footer',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'footer-icons-toggle',
				'label' => esc_html__('Icons List', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the icons list', 'fs-core'),
				'section' => 'theme_options_footer',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'repeater',
				'label' => esc_html__('Icons List', 'fs-core'),
				'section' => 'theme_options_footer',
				'priority' => 10,
				'row_label' => [
					'type' => 'text',
					'value' => esc_html__('Icon', 'fs-core'),
				],
				'button_label' => esc_html__('Add new icon', 'fs-core'),
				'settings' => 'footer-icons-list',
				'fields' => [
					'font_awesome_icon' => [
						'type' => 'select',
						'label' => esc_html__('Icon', 'fs-core'),
						'placeholder' => esc_html__('Select an icon...', 'fs-core'),
						'description' => esc_html__('Select an icon...', 'fs-core'),
						'choices' => FSD_Helper::get_fa_icons(),
					],
					'custom_icon' => [
						'type' => 'image',
						'label' => esc_html__('OR Upload Custom Icon', 'fs-core'),
					],
					'url' => [
						'type' => 'url',
						'label' => esc_html__('Link', 'kirki'),
					],
					'target' => [
						'type' => 'select',
						'label' => esc_html__('URL Target', 'fs-core'),
						'description' => esc_attr__('Select the type of url target', 'fs-core'),
						'default' => 'self',
						'choices' => [
							'self' => esc_html__('Self', 'fs-core'),
							'_blank' => esc_html__('Blank', 'fs-core'),
							'top' => esc_html__('Top', 'fs-core'),
							'parent' => esc_html__('Parent', 'fs-core'),
						],
					],
				],
				'active_callback' => [
					[
						'setting' => 'footer-icons',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
		
		endif;
		
	}
	
	/**
	 * blog
	 */
	public function kirki_blog()
	{
		
		if (class_exists('Kirki')):
			
			$query = new WP_Query([
				'order' => 'DESC',
				'posts_per_page' => -1,
			]);
			
			$posts = [];
			
			if ($query->have_posts()) :
				
				while ($query->have_posts()) : $query->the_post();
					
					$posts[get_the_ID()] = get_the_title();
				
				endwhile;
			
			endif;
			
			Kirki::add_section('theme_options_blog', [
				'title' => esc_attr__('Blog', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general blog values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 6,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'blog-filter-toggle',
				'label' => esc_html__('Blog Filter', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the filter section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'sticky-post-section-toggle',
				'label' => esc_html__('Sticky Post Section', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the sticky post section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'sticky-post-section-type',
				'label' => esc_html__('Sticky Post Section Type', 'fs-core'),
				'description' => esc_attr__('Select the type of blog', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => 'header',
				'choices' => [
					'header' => esc_html__('Header', 'fs-core'),
					'sidebar' => esc_html__('Sidebar', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'sticky-post-section-toggle',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'select',
				'settings' => 'sticky-post-section-post',
				'section' => 'theme_options_blog',
				'label' => esc_html__('Sticky Post', 'fs-core'),
				'description' => esc_attr__('Select the sticky post', 'fs-core'),
				'choices' => $posts,
				'active_callback' => [
					[
						'setting' => 'sticky-post-section-toggle',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'blog-number-of-grid-column',
				'label' => esc_html__('Grid columns', 'fs-core'),
				'description' => esc_attr__('Input number of grid columns', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 4,
					'step' => 1,
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'blog-number-of-grid-column-archive',
				'label' => esc_html__('Archive grid columns', 'fs-core'),
				'description' => esc_attr__('Input number of archive grid columns', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 4,
					'step' => 1,
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'blog-grid-offset',
				'label' => esc_html__('Grid items offset', 'fs-core'),
				'description' => esc_attr__('Input grid items offset', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => 15,
				'choices' => [
					'min' => 0,
					'max' => 50,
					'step' => 1,
				],
			]);
			
			Kirki::add_field('jk-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'blog-pagination-type',
				'label' => esc_html__('Pagination Type', 'fs-core'),
				'description' => esc_attr__('Select the pagination type', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => 'default',
				'choices' => [
					'default' => esc_html__('Default', 'fs-core'),
					'load-more' => esc_html__('Load More', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-blog-share',
				'label' => esc_html__('Single Post Share Icons', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single post share icons section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'multicheck',
				'settings' => 'single-blog-share-list',
				'label' => esc_html__('Sharing Social List', 'fs-core'),
				'section' => 'theme_options_blog',
				'priority' => 10,
				'choices' => [
					'twitter' => esc_html__('twitter', 'fs-core'),
					'pinterest' => esc_html__('pinterest', 'fs-core'),
					'facebook' => esc_html__('facebook', 'fs-core'),
					'vk' => esc_html__('vk', 'fs-core'),
					'linkedin' => esc_html__('linkedin', 'fs-core'),
					'odnoklassniki' => esc_html__('odnoklassniki', 'fs-core'),
					'tumblr' => esc_html__('tumblr', 'fs-core'),
					'google' => esc_html__('google', 'fs-core'),
					'digg' => esc_html__('digg', 'fs-core'),
					'reddit' => esc_html__('reddit', 'fs-core'),
					'stumbleupon' => esc_html__('stumbleupon', 'fs-core'),
					'pocket' => esc_html__('pocket', 'fs-core'),
					'whatsapp' => esc_html__('whatsapp', 'fs-core'),
					'xing' => esc_html__('xing', 'fs-core'),
					'email' => esc_html__('email', 'fs-core'),
					'telegram' => esc_html__('telegram', 'fs-core'),
					'skype' => esc_html__('skype', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'single-blog-share',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-blog-tags',
				'label' => esc_html__('Single Post Tags', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single post tags section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-blog-navigation',
				'label' => esc_html__('Single Post Navigation', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single post navigation section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-blog-recent-posts',
				'label' => esc_html__('Single Post Recent Posts', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single post recent posts section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'single-blog-recent-posts-number',
				'label' => esc_html__('Recent Posts Count', 'fs-core'),
				'description' => esc_attr__('Input number of recent posts', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => 4,
				'choices' => [
					'min' => 4,
					'max' => 12,
					'step' => 1,
				],
				'active_callback' => [
					[
						'setting' => 'single-blog-recent-posts',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-blog-comments',
				'label' => esc_html__('Single Post Comments', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single post comments section', 'fs-core'),
				'section' => 'theme_options_blog',
				'default' => '1',
			]);
		
		endif;
		
	}
	
	/**
	 * career
	 */
	public function kirki_career()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_career', [
				'title' => esc_attr__('Career', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general career values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 7,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-career-header',
				'label' => esc_html__('Single Position Header', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single position header', 'fs-core'),
				'section' => 'theme_options_career',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-career-share',
				'label' => esc_html__('Single Position Share Icons', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single position share icons', 'fs-core'),
				'section' => 'theme_options_career',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'single-career-related',
				'label' => esc_html__('Single Position Related Posts', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the single position related posts', 'fs-core'),
				'section' => 'theme_options_career',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'multicheck',
				'settings' => 'single-career-share-list',
				'label' => esc_html__('Sharing Social List', 'fs-core'),
				'section' => 'theme_options_career',
				'priority' => 10,
				'choices' => [
					'twitter' => esc_html__('twitter', 'fs-core'),
					'pinterest' => esc_html__('pinterest', 'fs-core'),
					'facebook' => esc_html__('facebook', 'fs-core'),
					'vk' => esc_html__('vk', 'fs-core'),
					'linkedin' => esc_html__('linkedin', 'fs-core'),
					'odnoklassniki' => esc_html__('odnoklassniki', 'fs-core'),
					'tumblr' => esc_html__('tumblr', 'fs-core'),
					'google' => esc_html__('google', 'fs-core'),
					'digg' => esc_html__('digg', 'fs-core'),
					'reddit' => esc_html__('reddit', 'fs-core'),
					'stumbleupon' => esc_html__('stumbleupon', 'fs-core'),
					'pocket' => esc_html__('pocket', 'fs-core'),
					'whatsapp' => esc_html__('whatsapp', 'fs-core'),
					'xing' => esc_html__('xing', 'fs-core'),
					'email' => esc_html__('email', 'fs-core'),
					'telegram' => esc_html__('telegram', 'fs-core'),
					'skype' => esc_html__('skype', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'single-career-share',
						'operator' => '==',
						'value' => true,
					]
				],
			]);
		
		endif;
		
	}
	
	/**
	 * shop
	 */
	public function kirki_shop()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_shop', [
				'title' => esc_attr__('Shop', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general shop values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 8,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'shop-header',
				'label' => esc_html__('Enable Header', 'fs-core'),
				'description' => esc_attr__('If true - will be enabled Shop Header section', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => '1',
			]);
			
			Kirki::add_field('jk-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'shop-header-type',
				'label' => esc_html__('Header Type', 'fs-core'),
				'description' => esc_attr__('Select the header type', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 'default',
				'choices' => [
					'default' => esc_html__('Default', 'fs-core'),
					'image' => esc_html__('Image', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'shop-header',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'image',
				'settings' => 'shop-header-bg',
				'label' => esc_html__('Header BG Image', 'fs-core'),
				'description' => esc_html__('Upload header Background Image', 'fs-core'),
				'section' => 'theme_options_shop',
				'active_callback' => [
					[
						'setting' => 'shop-header',
						'operator' => '==',
						'value' => '1',
					],
					[
						'setting' => 'shop-header-type',
						'operator' => '==',
						'value' => 'image',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'shop-labels',
				'label' => esc_html__('Labels', 'fs-core'),
				'description' => esc_attr__('If true - will be displayed the product labels', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'shop-quick-actions-overlay',
				'label' => esc_html__('Quick Actions Overlay', 'fs-core'),
				'description' => esc_attr__('If true - will be enabled the quick actions overlauy (add to cart button & view product button)', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'text',
				'settings' => 'shop-title',
				'label' => esc_html__('Shop Title', 'fs-core'),
				'description' => esc_attr__('Input shop page title', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => esc_html__('Carefully selected beauty products', 'fs-core'),
				'active_callback' => [
					[
						'setting' => 'shop-header',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'text',
				'settings' => 'shop-subtitle',
				'label' => esc_html__('Shop Subtitle', 'fs-core'),
				'description' => esc_attr__('Input shop page subtitle', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => esc_html__('Our team carefully selects only the best products that have toxic-free formulas and are not tested on animals.', 'fs-core'),
				'active_callback' => [
					[
						'setting' => 'shop-header',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('jk-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'shop-pagination-type',
				'label' => esc_html__('Pagination Type', 'fs-core'),
				'description' => esc_attr__('Select the pagination type', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 'default',
				'choices' => [
					'default' => esc_html__('Default', 'fs-core'),
					'load-more' => esc_html__('Load More', 'fs-core'),
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'shop-filter-sidebar',
				'label' => esc_html__('Enable Filters Sidebar', 'fs-core'),
				'description' => esc_attr__('If true - will be enabled filters sidebar', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => '1',
			]);
			
			Kirki::add_field('jk-theme', [
				'type' => 'radio-buttonset',
				'settings' => 'shop-filter-sidebar-type',
				'label' => esc_html__('Filter Sidebar Type', 'fs-core'),
				'description' => esc_attr__('Select the filter sidebar type', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 'default',
				'choices' => [
					'default' => esc_html__('Default', 'fs-core'),
					'fixed' => esc_html__('Fixed', 'fs-core'),
				],
				'active_callback' => [
					[
						'setting' => 'shop-filter-sidebar',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'shop-number-of-grid-column',
				'label' => esc_html__('Grid Columns', 'fs-core'),
				'description' => esc_attr__('Input number of grid columns', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 6,
					'step' => 1,
				],
				'active_callback' => [
					[
						'setting' => 'shop-related-products',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'shop-number-of-items',
				'label' => esc_html__('Grid Items', 'fs-core'),
				'description' => esc_attr__('Input number of grid items', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 12,
				'choices' => [
					'min' => 1,
					'max' => 100,
					'step' => 1,
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'shop-related-products',
				'label' => esc_html__('Enable Related Products', 'fs-core'),
				'description' => esc_attr__('If true - will be enabled related products section', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'shop-number-of-related-column',
				'label' => esc_html__('Related Grid Columns', 'fs-core'),
				'description' => esc_attr__('Input number of related grid columns', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 6,
					'step' => 1,
				],
				'active_callback' => [
					[
						'setting' => 'shop-related-products',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'shop-number-of-related-items',
				'label' => esc_html__('Related Items Limit', 'fs-core'),
				'description' => esc_attr__('Input number of related items limit', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 100,
					'step' => 1,
				],
				'active_callback' => [
					[
						'setting' => 'shop-related-products',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'shop-upsells-products',
				'label' => esc_html__('Enable Upsells Products', 'fs-core'),
				'description' => esc_attr__('If true - will be enabled upsells products section', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'shop-number-of-upsells-column',
				'label' => esc_html__('Upsells Grid Columns', 'fs-core'),
				'description' => esc_attr__('Input number of upsells grid columns', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 6,
					'step' => 1,
				],
				'active_callback' => [
					[
						'setting' => 'shop-upsells-products',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'number',
				'settings' => 'shop-number-of-upsells-items',
				'label' => esc_html__('Upsells Items Limit', 'fs-core'),
				'description' => esc_attr__('Input number of upsells items limit', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 4,
				'choices' => [
					'min' => 1,
					'max' => 100,
					'step' => 1,
				],
				'active_callback' => [
					[
						'setting' => 'shop-upsells-products',
						'operator' => '==',
						'value' => '1',
					]
				],
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'slider',
				'settings' => 'shop-newest-items-treshhold',
				'label' => esc_html__('Newest Items Threshold', 'fs-core'),
				'description' => esc_attr__('Input the newest threshold (in days, used for "new" badge)', 'fs-core'),
				'section' => 'theme_options_shop',
				'default' => 3,
				'choices' => [
					'min' => 1,
					'max' => 90,
					'step' => 1,
				],
			]);
			
			$pages = get_pages();
			
			if (!empty($pages)):
				
				$sorted_pages = [];
				
				foreach ($pages as $page):
					
					$sorted_pages[$page->ID] = $page->post_title;
				
				endforeach;
				
				Kirki::add_field('fs-theme', [
					'type' => 'select',
					'settings' => 'shop-brands-main-page',
					'section' => 'theme_options_shop',
					'label' => esc_html__('Brands Page', 'fs-core'),
					'description' => esc_attr__('Select the brands page', 'fs-core'),
					'choices' => $sorted_pages,
				]);
			
			endif;
		
		endif;
		
	}
	
	/**
	 * error page
	 */
	public function kirki_error_page()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_error', [
				'title' => esc_attr__('Error Page', 'fs-core'),
				'description' => esc_attr__('Here You can customize the Error Page values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 9,
			]);
		
		endif;
		
	}
	
	/**
	 * social
	 */
	public function kirki_social()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_options_social', [
				'title' => esc_attr__('Social', 'fs-core'),
				'description' => esc_attr__('Here You can customize the general social values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 10,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'repeater',
				'label' => esc_html__('Social Icons', 'fs-core'),
				'section' => 'theme_options_social',
				'priority' => 10,
				'row_label' => [
					'type' => 'text',
					'value' => esc_html__('Social Value', 'fs-core'),
				],
				'button_label' => esc_html__('Add new social', 'fs-core'),
				'settings' => 'social-list',
				'default' => [
					[
						'social_icon' => 'fab fa-facebook-f',
						'social_url' => 'https://facebook.com/',
						'target' => 'self',
					],
				],
				'fields' => [
					'social_icon' => [
						'type' => 'select',
						'label' => esc_html__('Social Icon', 'fs-core'),
						'placeholder' => esc_html__('Select an icon...', 'fs-core'),
						'choices' => FSD_Helper::get_fa_icons(),
					],
					'social_url' => [
						'type' => 'text',
						'label' => esc_html__('Social URL', 'fs-core'),
						'description' => esc_html__('This will be the social URL', 'fs-core'),
					],
					'target' => [
						'type' => 'select',
						'label' => esc_html__('URL Target', 'fs-core'),
						'description' => esc_attr__('Select the type of url target', 'fs-core'),
						'default' => 'self',
						'choices' => [
							'self' => esc_html__('Self', 'fs-core'),
							'_blank' => esc_html__('Blank', 'fs-core'),
							'top' => esc_html__('Top', 'fs-core'),
							'parent' => esc_html__('Parent', 'fs-core'),
						],
					],
				]
			
			]);
		
		endif;
		
	}
	
	/**
	 *
	 */
	public function kirki_optimization()
	{
		
		if (class_exists('Kirki')):
			
			Kirki::add_section('theme_optimization', [
				'title' => esc_attr__('Optimization', 'fs-core'),
				'description' => esc_attr__('Here You can customize the Customization values', 'fs-core'),
				'panel' => 'theme_options',
				'priority' => 11,
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'opt-disable-wp-block',
				'label' => esc_html__('Disable WP Block Styles/Scripts', 'fs-core'),
				'description' => esc_attr__('If true - will be disabled default wp block styles (enable this if you are not using gutenberg blocks on your pages)', 'fs-core'),
				'section' => 'theme_optimization',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'opt-disable-emoji',
				'label' => esc_html__('Disable Emoji', 'fs-core'),
				'description' => esc_attr__('If true - will be disabled wordpress emoji library', 'fs-core'),
				'section' => 'theme_optimization',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'opt-disable-jquery-migrate',
				'label' => esc_html__('Disable jQuery Migrate', 'fs-core'),
				'description' => esc_attr__('If true - will be disabled jquery migrate (used for old libraries and plugins)', 'fs-core'),
				'section' => 'theme_optimization',
				'default' => '1',
			]);
			
			Kirki::add_field('fs-theme', [
				'type' => 'toggle',
				'settings' => 'opt-enable-lqip',
				'label' => esc_html__('Enable LQIP', 'fs-core'),
				'description' => esc_attr__('If true - will be enabled low quality image placeholder for all image in your content (the_content output)', 'fs-core'),
				'section' => 'theme_optimization',
				'default' => '1',
			]);
		
		endif;
		
	}
	
}