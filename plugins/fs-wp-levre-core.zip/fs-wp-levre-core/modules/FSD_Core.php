<?php use Elementor\Controls_Stack;
use Elementor\Controls_Manager;

defined('ABSPATH') || exit;

/**
 * Class FSD_Core
 */
class FSD_Core
{
	
	/**
	 * @var string
	 */
	public static $name = '';
	
	/**
	 * @var string
	 */
	public static $slug = '';
	
	/**
	 * @var string
	 */
	public static $prefix = '';
	
	/**
	 * @var string
	 */
	public static $version = '';
	
	/**
	 * @var string
	 */
	public static $minimum_php_version = '';
	
	/**
	 * @var string
	 */
	public static $plugin_path = '';
	
	/**
	 * @var string
	 */
	public static $plugin_url = '';
	
	/**
	 * @var array
	 */
	public $new_fonts = [];
	
	/**
	 * @var array
	 */
	public static $children = [];
	
	/**
	 * @var array
	 */
	public static $variants = [];
	
	/**
	 * @return string
	 */
	public static function getName()
	{
		
		/* return name */
		return self::$name;
		
	}
	
	/**
	 * @param string $name
	 */
	public static function setName($name)
	{
		
		/* set name */
		self::$name = $name;
		
	}
	
	/**
	 * @return string
	 */
	public static function getSlug()
	{
		
		/* return slug */
		return self::$slug;
		
	}
	
	/**
	 * @param string $slug
	 */
	public static function setSlug($slug)
	{
		
		/* set slug */
		self::$slug = $slug;
		
	}
	
	/**
	 * @return string
	 */
	public static function getPrefix()
	{
		
		/* get prefix */
		return self::$prefix;
		
	}
	
	/**
	 * @param string $prefix
	 */
	public static function setPrefix($prefix)
	{
		
		/* set prefix */
		self::$prefix = $prefix;
		
	}
	
	/**
	 * @return string
	 */
	public static function getVersion()
	{
		
		/* get version */
		return self::$version;
		
	}
	
	/**
	 * @param string $version
	 */
	public static function setVersion($version)
	{
		
		/* set version */
		self::$version = $version;
		
	}
	
	/**
	 * @return string
	 */
	public static function getMinimumPhpVersion()
	{
		
		/* get minimum_php_version */
		return self::$minimum_php_version;
		
	}
	
	/**
	 * @param string $minimum_php_version
	 */
	public static function setMinimumPhpVersion($minimum_php_version)
	{
		
		/* set minimum_php_version */
		self::$minimum_php_version = $minimum_php_version;
		
	}
	
	/**
	 * @return string
	 */
	public static function getPluginPath()
	{
		
		/* get plugin_path */
		return self::$plugin_path;
		
	}
	
	/**
	 * @param string $plugin_path
	 */
	public static function setPluginPath($plugin_path)
	{
		
		/* set plugin_path */
		self::$plugin_path = $plugin_path;
		
	}
	
	/**
	 * @return string
	 */
	public static function getPluginUrl()
	{
		
		/* get plugin_url */
		return self::$plugin_url;
		
	}
	
	/**
	 * @param string $plugin_url
	 */
	public static function setPluginUrl($plugin_url)
	{
		
		/* set plugin_url */
		self::$plugin_url = $plugin_url;
		
	}
	
	/**
	 * @return array
	 */
	public function getNewFonts()
	{
		
		/* get new_fonts */
		return $this->new_fonts;
		
	}
	
	/**
	 * @param array $new_fonts
	 */
	public function setNewFonts($new_fonts)
	{
		
		/* set new_fonts */
		$this->new_fonts = $new_fonts;
		
	}
	
	/**
	 * @return array
	 */
	public static function getChildren()
	{
		
		/* get children */
		return self::$children;
		
	}
	
	/**
	 * @param array $children
	 */
	public static function setChildren($children)
	{
		
		/* set children */
		self::$children = $children;
		
	}
	
	/**
	 * @return array
	 */
	public static function getVariants()
	{
		
		/* get variants */
		return self::$variants;
		
	}
	
	/**
	 * @param array $variants
	 */
	public static function setVariants($variants)
	{
		
		/* set variants */
		self::$variants = $variants;
		
	}
	
	/**
	 * FSD_Core constructor.
	 */
	public function __construct($args)
	{
		
		/* setup plugin path */
		if (!empty($args['plugin_path'])):
			
			/* new value */
			$this->setPluginPath($args['plugin_path']);
		
		else:
			
			/* default value */
			$this->setPluginPath(plugin_dir_path(__FILE__));
		
		endif;
		
		/* setup plugin url */
		if (!empty($args['plugin_url'])):
			
			/* new value */
			$this->setPluginUrl($args['plugin_url']);
		
		else:
			
			/* default value */
			$this->setPluginUrl(plugin_dir_url(__FILE__));
		
		endif;
		
		/* setup version of plugin */
		if (!empty($args['version'])):
			
			/* new value */
			$this->setVersion($args['version']);
		
		else:
			
			/* default value */
			$this->setVersion('1.0');
		
		endif;
		
		/* setup plugin name */
		if (!empty($args['name'])):
			
			/* new value */
			$this->setName($args['name']);
		
		else:
			
			/* default value */
			$this->setName('JK Theme Core Plugin');
		
		endif;
		
		/* setup plugin slug */
		if (!empty($args['slug'])):
			
			/* new value */
			$this->setSlug($args['slug']);
		
		else:
			
			/* default value */
			$this->setSlug('fs-core');
		
		endif;
		
		/* setup plugin prefix */
		if (!empty($args['prefix'])):
			
			/* new value */
			$this->setPrefix($args['prefix']);
		
		else:
			
			/* default value */
			$this->setPrefix(self::$prefix . '');
		
		endif;
		
		/* setup plugin minimum_php_version */
		if (!empty($args['minimum_php_version'])):
			
			/* new value */
			$this->setMinimumPhpVersion($args['minimum_php_version']);
		
		else:
			
			/* default value */
			$this->setMinimumPhpVersion('7.0');
		
		endif;
		
		/* init plugin */
		$this->init_plugin();
		
	}
	
	/**
	 * init plugin
	 */
	public function init_plugin()
	{
		
		$opt_disable_wp_block = get_theme_mod('opt-disable-wp-block', 1);
		
		$opt_disable_emoji = get_theme_mod('opt-disable-emoji', 1);
		
		$opt_disable_jquery_migrate = get_theme_mod('opt-disable-jquery-migrate', 1);
		
		$opt_enable_lqip = get_theme_mod('opt-enable-lqip', 1);
		
		/* plugin translation */
		add_action('init', [$this, 'i18n']);
		
		/* init plugin modules */
		add_action('init', [$this, 'init_modules'], 100);
		
		/* register image sizes */
		add_action('init', [$this, 'register_image_sizes']);
		
		add_action('init', [$this, 'register_shortcodes']);
		
		add_action('init', [$this, 'brands_init']);
		
		if ($opt_disable_wp_block):
			
			/* deregister default blog styles */
			add_action('wp_print_styles', [$this, 'deregister_block_styles'], 999);
		
		endif;
		
		if ($opt_disable_jquery_migrate):
			
			/* remove jquery migrate */
			add_action('wp_default_scripts', [$this, 'remove_jquery_migrate'], 999);
		
		endif;
		
		if ($opt_disable_emoji):
			
			/* disable emoji */
			add_filter('tiny_mce_plugins', [$this, 'disable_emojis_tinymce']);
			
			/* disable emoji */
			add_action('init', [$this, 'disable_emojis']);
		
		endif;
		
		if ($opt_enable_lqip):
			
			/* check if exists lqip */
			if (class_exists('jk_wp_lqip_handler')):
				
				/* lqip init */
				add_action('plugins_loaded', [$this, 'lqip_init']);
			
			endif;
		
		endif;
		
		/* set custom fonts */
		add_action('wp_head', [$this, 'set_custom_fonts']);
		
		/* customizer styles */
		add_action('customize_controls_print_styles', [$this, 'customizer_styles'], 999);
		
		/* add custom fonts options page */
		add_action('after_setup_theme', [$this, 'add_custom_fonts_options_page']);
		
		/* add all font variants */
		add_action('after_setup_theme', [$this, 'kirki_font_add_all_variants'], 100);
		
		/* add custom fonts settings */
		add_action('init', [$this, 'add_custom_fonts_settings'], 1);
		
		/* add menu settings */
		add_action('init', [$this, 'add_menu_settings'], 1);
		
		/* add navigation settings */
		add_action('init', [$this, 'add_navigation_settings'], 1);
		
		/* init widgets */
		add_action('elementor/widgets/register', [$this, 'init_widgets']);
		
		/* register categories */
		add_action('elementor/elements/categories_registered', [$this, 'registered_categories']);
		
		add_action('plugins_loaded', [$this, 'inject_new_controls']);
		
		/* compare php versions */
		if (version_compare(PHP_VERSION, self::$minimum_php_version, '<')) :
			
			/* admin notice if php version < minimum_php_version */
			add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
			
			/* exit */
			
			return;
		
		endif;
		
	}
	
	
	/**
	 * @return void
	 */
	public function disable_emojis()
	{
		
		remove_action('wp_head', 'print_emoji_detection_script', 7);
		
		remove_action('admin_print_scripts', 'print_emoji_detection_script');
		
		remove_action('wp_print_styles', 'print_emoji_styles');
		
		remove_action('admin_print_styles', 'print_emoji_styles');
		
		remove_filter('the_content_feed', 'wp_staticize_emoji');
		
		remove_filter('comment_text_rss', 'wp_staticize_emoji');
		
		remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
		
	}
	
	
	/**
	 * @return void
	 */
	public function brands_init()
	{
		
		$labels = [
				'name' => esc_html__('Brands', 'fs-core'),
				'singular_name' => esc_html__('Brand', 'fs-core'),
				'menu_name' => esc_html__('Brands', 'fs-core'),
				'all_items' => esc_html__('All Brands', 'fs-core'),
				'parent_item' => esc_html__('Parent Brand', 'fs-core'),
				'parent_item_colon' => esc_html__('Parent Brand', 'fs-core'),
				'new_item_name' => esc_html__('New Brand Name', 'fs-core'),
				'add_new_item' => esc_html__('Add New Brand', 'fs-core'),
				'edit_item' => esc_html__('Edit Brand', 'fs-core'),
				'update_item' => esc_html__('Update Brand', 'fs-core'),
				'separate_items_with_commas' => esc_html__('Separate Brand with commas', 'fs-core'),
				'search_items' => esc_html__('Search Brands', 'fs-core'),
				'add_or_remove_items' => esc_html__('Add or remove Brands', 'fs-core'),
				'choose_from_most_used' => esc_html__('Choose from most used Brands', 'fs-core'),
		];
		
		$args = [
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => true,
				'show_tagcloud' => true,
		];
		
		register_taxonomy('brands', 'product', $args);
		
		register_taxonomy_for_object_type('brands', 'product');
		
	}
	
	/**
	 * @param $plugins
	 *
	 * @return array
	 */
	public function disable_emojis_tinymce($plugins)
	{
		
		if (is_array($plugins)) :
			
			return array_diff($plugins, ['wpemoji']);
		
		else :
			
			return [];
		
		endif;
		
	}
	
	
	/**
	 * @return void
	 */
	public function deregister_block_styles()
	{
		
		if (!is_admin()) :
			
			wp_deregister_style('wp-block-library');
			
			wp_dequeue_style('wp-block-library');
			
			wp_deregister_script('wp-embed');
			
			wp_dequeue_script('wp-embed');
		
		endif;
		
	}
	
	/**
	 * @param $scripts
	 */
	public function remove_jquery_migrate($scripts)
	{
		
		if (!is_admin() && isset($scripts->registered['jquery'])) :
			
			$script = $scripts->registered['jquery'];
			
			if ($script->deps) :
				
				$script->deps = array_diff($script->deps, ['jquery-migrate']);
			
			endif;
		
		endif;
		
	}
	
	/**
	 * init plugin translation
	 */
	public function i18n()
	{
		
		/* load plugin textdomain fs-core */
		load_plugin_textdomain('fs-core', false, basename(dirname(__FILE__)) . '/lang');
		
	}
	
	/**
	 * register image sizes
	 */
	public function register_image_sizes()
	{
		
		/* add image sizes */
		add_image_size(self::$prefix . 'square-size-extra-small', 300, 300, true);
		/* ------- */
		add_image_size(self::$prefix . 'square-size-small', 540, 540, true);
		/* ------- */
		add_image_size(self::$prefix . 'square-size-medium', 768, 768, true);
		/* ------- */
		add_image_size(self::$prefix . 'square-size-large', 1024, 1024, true);
		/* ------- */
		add_image_size(self::$prefix . 'square-size-extra-large', 1440, 1440, true);
		/* ------- */
		add_image_size(self::$prefix . 'square-size-full', 1920, 1920, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-extra-small', 300, 200, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-small', 540, 360, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-medium', 768, 512, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-large', 1024, 683, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-extra-large', 1440, 960, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-full', 1920, 1080, true);
		/* ------- */
		add_image_size(self::$prefix . 'wide-size-ultra-full', 1920, 768, true);
		/* ------- */
		add_image_size(self::$prefix . 'vertical-size-extra-small', 200, 266, true);
		/* ------- */
		add_image_size(self::$prefix . 'vertical-size-small', 360, 479, true);
		/* ------- */
		add_image_size(self::$prefix . 'vertical-size-medium', 512, 681, true);
		/* ------- */
		add_image_size(self::$prefix . 'vertical-size-large', 683, 908, true);
		/* ------- */
		add_image_size(self::$prefix . 'vertical-size-extra-large', 960, 1277, true);
		/* ------- */
		add_image_size(self::$prefix . 'vertical-size-full', 1080, 1436, true);
		
	}
	
	/**
	 * lqip init
	 */
	public function lqip_init()
	{
		
		/* lqip sizes init */
		$sizes = [
				'thumbnail' => 4,
				'medium' => 8,
				'large' => 16,
				'full' => 32,
				self::$prefix . 'square-size-extra-small' => 4,
				self::$prefix . 'square-size-small' => 8,
				self::$prefix . 'square-size-medium' => 16,
				self::$prefix . 'square-size-large' => 16,
				self::$prefix . 'square-size-extra-large' => 16,
				self::$prefix . 'square-size-full' => 16,
				self::$prefix . 'wide-size-extra-small' => 4,
				self::$prefix . 'wide-size-small' => 8,
				self::$prefix . 'wide-size-medium' => 16,
				self::$prefix . 'wide-size-large' => 16,
				self::$prefix . 'wide-size-extra-large' => 16,
				self::$prefix . 'wide-size-full' => 16,
				self::$prefix . 'wide-size-ultra-full' => 16,
				self::$prefix . 'vertical-size-extra-small' => 4,
				self::$prefix . 'vertical-size-small' => 8,
				self::$prefix . 'vertical-size-medium' => 16,
				self::$prefix . 'vertical-size-large' => 16,
				self::$prefix . 'vertical-size-extra-large' => 16,
				self::$prefix . 'vertical-size-full' => 16,
		
		];
		
		/* init new lqip hanlder */
		$lqip = new jk_wp_lqip_handler();
		
		/* set sizes */
		$lqip->set_sizes($sizes);
		
		/* init */
		$lqip->init();
		
		unset($sizes);
		
		unset($lqip);
		
	}
	
	/**
	 * kirki add all variants for fonts
	 */
	public function kirki_font_add_all_variants()
	{
		
		if (class_exists('Kirki')):
			
			/* check if kirki fonts class exists */
			if (class_exists('Kirki_Fonts_Google')) :
				
				/* enable $force_load_all_variants */
				Kirki_Fonts_Google::$force_load_all_variants = true;
			
			endif;
		
		endif;
		
	}
	
	/**
	 * add menu settings
	 */
	public function add_menu_settings()
	{
		
		/* check if exists ACF */
		if (class_exists('ACF')):
			
			/* menu item settings group */
			acf_add_local_field_group([
					'key' => 'group_menu_item_settings',
					'title' => __('Menu Item Options', 'fs-core'),
					'location' => [
							[
									[
											'param' => 'nav_menu_item',
											'operator' => '==',
											'value' => 'all',
									],
							],
					],
					'position' => 'side',
			]);
			
			acf_add_local_field(
					[
							'key' => 'field_menu_megamenu_toggle',
							'label' => esc_html__('Enable Megamenu', 'fs-core'),
							'name' => 'option_menu_megamenu_toggle',
							'type' => 'true_false',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => [
									'width' => '50%',
							],
							'message' => '',
							'default_value' => 0,
							'ui' => 1,
							'ui_on_text' => esc_html__('Enable', 'fs-core'),
							'ui_off_text' => esc_html__('Disable', 'fs-core'),
							'parent' => 'group_menu_item_settings',
					]);
		
		endif;
		
	}
	
	/**
	 * add navigation settings
	 */
	public function add_navigation_settings()
	{
		
		/* check if exists ACF */
		if (class_exists('ACF')):
			
			/* menu item settings group */
			acf_add_local_field_group([
					'key' => 'group_navigation_settings',
					'title' => __('Navigation Options', 'fs-core'),
					'location' => [
							[
									[
											'param' => 'post_type',
											'operator' => '==',
											'value' => 'all',
									],
							],
					],
					'position' => 'side',
					'fields' => [
							[
									'key' => 'field_navigation_type',
									'label' => esc_html__('Navigation Type', 'fs-core'),
									'name' => 'option_navigation_type',
									'type' => 'select',
									'required' => 0,
									'conditional_logic' => 0,
									'choices' => [
											'default' => esc_html__('Default', 'fs-core'),
											'type-1' => esc_html__('Type 1', 'fs-core'),
											'type-2' => esc_html__('Type 2', 'fs-core'),
									],
									'default_value' => 'default',
									'allow_null' => 0,
									'multiple' => 0,
									'ui' => 1,
									'ajax' => 0,
									'return_format' => 'value',
									'placeholder' => esc_html__('Navigation Type', 'fs-core'),
							],
							[
									'key' => 'field_navigation_style',
									'label' => esc_html__('Navigation Style', 'fs-core'),
									'name' => 'option_navigation_style',
									'type' => 'select',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => [
											'width' => '',
											'class' => '',
											'id' => '',
									],
									'choices' => [
											'default' => esc_html__('Default', 'fs-core'),
											'light' => esc_html__('Light', 'fs-core'),
											'dark' => esc_html__('Dark', 'fs-core'),
											'transparent' => esc_html__('Transparent', 'fs-core'),
											'transparent-light' => esc_html__('Transparent Light', 'fs-core'),
									],
									'default_value' => 'default',
									'allow_null' => 0,
									'multiple' => 0,
									'ui' => 1,
									'ajax' => 0,
									'return_format' => 'value',
									'placeholder' => esc_html__('Navigation Style', 'fs-core'),
							],
					],
			]);
		
		endif;
		
	}
	
	/**
	 * add custom fonts settings
	 */
	public function add_custom_fonts_settings()
	{
		
		/* check if exists kirki */
		if (class_exists('ACF')):
			
			/* custom fonts settings group */
			acf_add_local_field_group([
					'key' => 'group_custom_fonts_settings',
					'title' => esc_html__('Custom Fonts', 'fs-core'),
					'fields' => [
							[
									'key' => 'field_custom_fonts',
									'label' => esc_html__('Custom Fonts'),
									'name' => 'option_custom_fonts',
									'type' => 'repeater',
									'layout' => 'table',
									'button_label' => esc_html__('Add Font', 'fs-core'),
									'sub_fields' => [
										/* font title */
											[
													'key' => 'field_font_title',
													'label' => esc_html__('Font Title', 'fs-core'),
													'name' => 'option_font_title',
													'type' => 'text',
													'instructions' => esc_html__('Input the Font Title', 'fs-core'),
											],
										/* font style */
											[
													'key' => 'field_font_style',
													'label' => esc_html__('Font Style', 'fs-core'),
													'name' => 'option_font_style',
													'type' => 'repeater',
													'layout' => 'table',
													'button_label' => esc_html__('Add Font Style', 'fs-core'),
													'sub_fields' => [
														/* font type */
															[
																	'key' => 'field_font_type',
																	'label' => esc_html__('Font type', 'fs-core'),
																	'name' => 'option_font_type',
																	'type' => 'select',
																	'choices' => [
																			'opentype' => esc_html__('OTF (OpenType)', 'fs-core'),
																			'truetype' => esc_html__('TTF (TrueType)', 'fs-core'),
																			'svg' => esc_html__('SVG', 'fs-core'),
																			'eot' => esc_html__('EOT (Embedded Open Type)', 'fs-core'),
																			'woff' => esc_html__('WOFF (Web Open Font Format)', 'fs-core'),
																			'woff2' => esc_html__('WOFF2', 'fs-core'),
																	],
																	'ui' => 1,
																	'return_format' => 'value',
															],
														/* font style value */
															[
																	'key' => 'field_font_style_value',
																	'label' => esc_html__('Style', 'fs-core'),
																	'name' => 'option_font_style_value',
																	'type' => 'select',
																	'choices' => [
																			'normal' => esc_html__('normal', 'fs-core'),
																			'italic' => esc_html__('italic', 'fs-core'),
																			'oblique' => esc_html__('oblique', 'fs-core'),
																			'inherit' => esc_html__('inherit', 'fs-core'),
																	],
																	'ui' => 1,
																	'return_format' => 'value',
															],
														/* font weight */
															[
																	'key' => 'field_font_weight',
																	'label' => esc_html__('Font Weight', 'fs-core'),
																	'name' => 'option_font_weight',
																	'type' => 'number',
																	'min' => 100,
																	'max' => 900,
																	'step' => 100,
															],
														/* font title */
															[
																	'key' => 'field_font_file',
																	'label' => esc_html__('Font File', 'fs-core'),
																	'name' => 'option_font_file',
																	'type' => 'file',
																	'return_format' => 'url',
																	'library' => 'all',
															],
													],
											],
									],
							],
					],
					'location' => [
							[
									[
											'param' => 'options_page',
											'operator' => '==',
											'value' => 'theme-custom-fonts-settings',
									],
							],
					],
					'menu_order' => 0,
					'position' => 'normal',
					'style' => 'default',
					'label_placement' => 'top',
					'instruction_placement' => 'label',
					'hide_on_screen' => '',
					'active' => true,
					'description' => '',
			]);
		
		endif;
		
	}
	
	/**
	 * set custom fonts
	 */
	public function set_custom_fonts()
	{
		
		if (class_exists('Kirki') && class_exists('ACF')):
			
			/* empty fonts array */
			$fonts = [];
			
			/* repeater loop */
			if (have_rows('field_custom_fonts', 'option')):
				
				while (have_rows('field_custom_fonts', 'option')) : the_row();
					
					/* get title */
					$title = FSD_Helper::get_sub_field('field_font_title');
					
					/* add title to the fonts */
					$fonts[$title] = $title;
				
				endwhile;
			
			endif;
			
			/* get primary font */
			$primary_font = get_theme_mod('primary-font');
			
			/* get text font */
			$text_font = get_theme_mod('text-font');
			
			/* fonts loop */
			foreach ($fonts as $font):
				
				/* check if primary/text font === font */
				if ($primary_font['font-family'] === $font || $text_font['font-family'] === $font):
					
					?>
					
					<!-- fonts including -->
					<style>
						
						<?php

								 /* loop repeater */
								 if (have_rows('field_custom_fonts', 'option')):

									 while (have_rows('field_custom_fonts', 'option')) : the_row();

										  /* check if font === font title */
										  if($font === FSD_Helper::get_sub_field('field_font_title')):

												/* font style repeater loop */
												if (have_rows('field_font_style')):

													 while (have_rows('field_font_style')) : the_row();

														  /* get font type */
														  $field_font_type=FSD_Helper::get_sub_field('field_font_type');

														  /* get font style */
														  $field_font_style_value=FSD_Helper::get_sub_field('field_font_style_value');

														  /* get font weight */
														  $field_font_weight=FSD_Helper::get_sub_field('field_font_weight');

														  /* get font file */
														  $field_font_file=FSD_Helper::get_sub_field('field_font_file');

														  ?>
						
						/* setup new font value */
						@font-face {
							font-family: <?php echo esc_html($font);?>;
							font-style: <?php echo esc_attr($field_font_style_value);?>;
							font-weight: <?php echo esc_attr($field_font_weight); ?>;
							font-display: swap;
							src: url('<?php echo esc_url($field_font_file);?>') format('<?php echo esc_attr($field_font_type);?>');
						}
						
						<?php

								unset($field_font_type);

								unset($field_font_style_value);

								unset($field_font_weight);

								unset($field_font_file);

						  endwhile;

					 endif;

				endif;

		  endwhile;

	 endif;

	  ?>
					
					</style>
				
				<?php
				
				endif;
			
			endforeach;
			
			unset($fonts);
			
			unset($primary_font);
			
			unset($text_font);
		
		endif;
		
	}
	
	
	/**
	 * @return void
	 */
	public function inject_new_controls()
	{
		
		/* check if exists elementor */
		if (function_exists('elementor_load_plugin_textdomain')):
			
			// Structure Injection
			add_action('elementor/element/before_section_end',
					function ($section, $section_id, $args) {
						
						if ($section->get_name() == 'section' && $section_id == 'section_layout') :
							$section->add_responsive_control(
									'_element_width',
									[
											'label' => __('Width', 'fs-core'),
											'type' => Controls_Manager::SELECT,
											'default' => '',
											'options' => [
													'' => __('Default', 'fs-core'),
													'inherit' => __('Full Width', 'fs-core') . ' (100%)',
													'auto' => __('Inline', 'fs-core') . ' (auto)',
													'initial' => __('Custom', 'fs-core'),
											],
											'selectors_dictionary' => [
													'inherit' => '100%',
											],
											'prefix_class' => 'elementor-widget%s__width-',
											'selectors' => [
													'{{WRAPPER}}' => 'width: {{VALUE}}; max-width: {{VALUE}}',
											],
									]
							);
							$section->add_responsive_control(
									'_element_custom_width',
									[
											'label' => __('Custom Width', 'fs-core'),
											'type' => Controls_Manager::SLIDER,
											'range' => [
													'px' => [
															'max' => 1000,
															'step' => 1,
													],
													'%' => [
															'max' => 100,
															'step' => 1,
													],
											],
											'condition' => [
													'_element_width' => 'initial',
											],
											'device_args' => [
													Controls_Stack::RESPONSIVE_TABLET => [
															'condition' => [
																	'_element_width_tablet' => ['initial'],
															],
													],
													Controls_Stack::RESPONSIVE_MOBILE => [
															'condition' => [
																	'_element_width_mobile' => ['initial'],
															],
													],
											],
											'size_units' => ['px', '%', 'vw'],
											'selectors' => [
													'{{WRAPPER}}' => 'width: {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}}',
											],
									]
							);
							$section->add_responsive_control(
									'_element_vertical_align',
									[
											'label' => __('Vertical Align', 'fs-core'),
											'type' => Controls_Manager::CHOOSE,
											'options' => [
													'flex-start' => [
															'title' => __('Start', 'fs-core'),
															'icon' => 'eicon-v-align-top',
													],
													'center' => [
															'title' => __('Center', 'fs-core'),
															'icon' => 'eicon-v-align-middle',
													],
													'flex-end' => [
															'title' => __('End', 'fs-core'),
															'icon' => 'eicon-v-align-bottom',
													],
											],
											'condition' => [
													'_element_width!' => '',
													'_position' => '',
											],
											'selectors' => [
													'{{WRAPPER}}' => 'align-self: {{VALUE}}',
											],
									]
							);
							$section->add_control(
									'_position_description',
									[
											'raw' => '<strong>' . __('Please note!', 'fs-core') . '</strong> ' . __('Custom positioning is not considered best practice for responsive web design and should not be used too frequently.', 'fs-core'),
											'type' => Controls_Manager::RAW_HTML,
											'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
											'render_type' => 'ui',
											'condition' => [
													'_position!' => '',
											],
									]
							);
							$section->add_control(
									'_position',
									[
											'label' => __('Position', 'fs-core'),
											'type' => Controls_Manager::SELECT,
											'default' => '',
											'options' => [
													'' => __('Default', 'fs-core'),
													'absolute' => __('Absolute', 'fs-core'),
													'fixed' => __('Fixed', 'fs-core'),
											],
											'prefix_class' => 'elementor-',
											'frontend_available' => true,
									]
							);
							$start = is_rtl() ? __('Right', 'fs-core') : __('Left', 'fs-core');
							$end = !is_rtl() ? __('Right', 'fs-core') : __('Left', 'fs-core');
							$section->add_control(
									'_offset_orientation_h',
									[
											'label' => __('Horizontal Orientation', 'fs-core'),
											'type' => Controls_Manager::CHOOSE,
											'toggle' => false,
											'default' => 'start',
											'options' => [
													'start' => [
															'title' => $start,
															'icon' => 'eicon-h-align-left',
													],
													'end' => [
															'title' => $end,
															'icon' => 'eicon-h-align-right',
													],
											],
											'classes' => 'elementor-control-start-end',
											'render_type' => 'ui',
											'condition' => [
													'_position!' => '',
											],
									]
							);
							$section->add_responsive_control(
									'_offset_x',
									[
											'label' => __('Offset', 'fs-core'),
											'type' => Controls_Manager::SLIDER,
											'range' => [
													'px' => [
															'min' => -1000,
															'max' => 1000,
															'step' => 1,
													],
													'%' => [
															'min' => -200,
															'max' => 200,
													],
													'vw' => [
															'min' => -200,
															'max' => 200,
													],
													'vh' => [
															'min' => -200,
															'max' => 200,
													],
											],
											'default' => [
													'size' => '0',
											],
											'size_units' => ['px', '%', 'vw', 'vh'],
											'selectors' => [
													'body:not(.rtl) {{WRAPPER}}' => 'left: {{SIZE}}{{UNIT}}',
													'body.rtl {{WRAPPER}}' => 'right: {{SIZE}}{{UNIT}}',
											],
											'condition' => [
													'_offset_orientation_h!' => 'end',
													'_position!' => '',
											],
									]
							);
							$section->add_responsive_control(
									'_offset_x_end',
									[
											'label' => __('Offset', 'fs-core'),
											'type' => Controls_Manager::SLIDER,
											'range' => [
													'px' => [
															'min' => -1000,
															'max' => 1000,
															'step' => 0.1,
													],
													'%' => [
															'min' => -200,
															'max' => 200,
													],
													'vw' => [
															'min' => -200,
															'max' => 200,
													],
													'vh' => [
															'min' => -200,
															'max' => 200,
													],
											],
											'default' => [
													'size' => '0',
											],
											'size_units' => ['px', '%', 'vw', 'vh'],
											'selectors' => [
													'body:not(.rtl) {{WRAPPER}}' => 'right: {{SIZE}}{{UNIT}}',
													'body.rtl {{WRAPPER}}' => 'left: {{SIZE}}{{UNIT}}',
											],
											'condition' => [
													'_offset_orientation_h' => 'end',
													'_position!' => '',
											],
									]
							);
							$section->add_control(
									'_offset_orientation_v',
									[
											'label' => __('Vertical Orientation', 'fs-core'),
											'type' => Controls_Manager::CHOOSE,
											'toggle' => false,
											'default' => 'start',
											'options' => [
													'start' => [
															'title' => __('Top', 'fs-core'),
															'icon' => 'eicon-v-align-top',
													],
													'end' => [
															'title' => __('Bottom', 'fs-core'),
															'icon' => 'eicon-v-align-bottom',
													],
											],
											'render_type' => 'ui',
											'condition' => [
													'_position!' => '',
											],
									]
							);
							$section->add_responsive_control(
									'_offset_y',
									[
											'label' => __('Offset', 'fs-core'),
											'type' => Controls_Manager::SLIDER,
											'range' => [
													'px' => [
															'min' => -1000,
															'max' => 1000,
															'step' => 1,
													],
													'%' => [
															'min' => -200,
															'max' => 200,
													],
													'vh' => [
															'min' => -200,
															'max' => 200,
													],
													'vw' => [
															'min' => -200,
															'max' => 200,
													],
											],
											'size_units' => ['px', '%', 'vh', 'vw'],
											'default' => [
													'size' => '0',
											],
											'selectors' => [
													'{{WRAPPER}}' => 'top: {{SIZE}}{{UNIT}}',
											],
											'condition' => [
													'_offset_orientation_v!' => 'end',
													'_position!' => '',
											],
									]
							);
							$section->add_responsive_control(
									'_offset_y_end',
									[
											'label' => __('Offset', 'fs-core'),
											'type' => Controls_Manager::SLIDER,
											'range' => [
													'px' => [
															'min' => -1000,
															'max' => 1000,
															'step' => 1,
													],
													'%' => [
															'min' => -200,
															'max' => 200,
													],
													'vh' => [
															'min' => -200,
															'max' => 200,
													],
													'vw' => [
															'min' => -200,
															'max' => 200,
													],
											],
											'size_units' => ['px', '%', 'vh', 'vw'],
											'default' => [
													'size' => '0',
											],
											'selectors' => [
													'{{WRAPPER}}' => 'bottom: {{SIZE}}{{UNIT}}',
											],
											'condition' => [
													'_offset_orientation_v' => 'end',
													'_position!' => '',
											],
									]
							);
						endif;
					},
					10,
					3);
		
		endif;
		
	}
	
	/**
	 * customizer styles
	 */
	public function customizer_styles()
	{
		
		if (class_exists('Kirki')):
			
			?>
			
			<style>
				
				#customize-theme-controls .kirki-variant-wrapper {
					display: none !important;
				}
			
			</style>
		
		<?php
		
		endif;
		
	}
	
	/**
	 * add custom fonts options page
	 */
	public function add_custom_fonts_options_page()
	{
		
		/* check if exists ACF */
		if (class_exists('ACF')):
			
			/* add options page for custom fonts */
			acf_add_options_page([
					'page_title' => esc_html__('Custom Fonts', 'fs-core'),
					'menu_title' => esc_html__('Custom Fonts', 'fs-core'),
					'menu_slug' => 'theme-custom-fonts-settings',
					'capability' => 'edit_posts',
					'icon_url' => 'dashicons-editor-textcolor',
					'position' => 25,
					'redirect' => false
			]);
		
		endif;
		
	}
	
	/**
	 * init modules
	 */
	public function init_modules()
	{
		
		/* check if exists Woocommerce */
		if (class_exists('WooCommerce')):
			
			/* shop instance */
			new FSD_Shop();
		
		endif;
		
		/* init customizer settings */
		new FSD_Customizer();
		
		/* init career settings */
		new FSD_Career();
		
		$this->settings();
		
	}
	
	
	/**
	 * @return void
	 */
	public function settings()
	{
		
		if (function_exists('acf_add_local_field')):
			
			acf_add_local_field_group([
					'key' => 'group_video_product_gallery_settings',
					'title' => esc_html__('Video Product Settings', 'fs-core'),
					'fields' => [
							[
									'key' => 'field_product_video_gallery',
									'label' => esc_html__('Video', 'fs-core'),
									'name' => 'option_product_video_gallery',
									'type' => 'repeater',
									'required' => 0,
									'conditional_logic' => 0,
									'min' => 0,
									'max' => 0,
									'layout' => 'row',
									'sub_fields' => [
											[
													'key' => 'field_product_video_preview',
													'label' => esc_html__('Video Preview', 'fs-core'),
													'name' => 'option_product_video_preview',
													'type' => 'image',
													'required' => 0,
													'conditional_logic' => 0,
													'return_format' => 'array',
													'preview_size' => 'medium',
													'library' => 'all',
											],
											[
													'key' => 'field_product_video',
													'label' => esc_html__('Video', 'fs-core'),
													'name' => 'option_product_video',
													'type' => 'button_group',
													'choices' => [
															'html' => esc_html('Html'),
															'youtube' => esc_html('Youtube'),
															'vimeo' => esc_html('Vimeo'),
													],
													'default_value' => 'html',
													'layout' => 'horizontal',
													'return_format' => 'value',
											],
											[
													'key' => 'field_product_video_file',
													'label' => esc_html__('HTML Video', 'fs-core'),
													'name' => 'option_product_video_file',
													'type' => 'file',
													'conditional_logic' => [
															[
																	[
																			'field' => 'field_product_video',
																			'operator' => '==',
																			'value' => 'html',
																	],
															],
													],
													'return_format' => 'url',
													'library' => 'all',
											],
											[
													'key' => 'field_product_video_url',
													'label' => esc_html__('Video URL', 'fs-core'),
													'name' => 'option_product_video_url',
													'type' => 'url',
													'conditional_logic' => [
															[
																	[
																			'field' => 'field_product_video',
																			'operator' => '==',
																			'value' => 'youtube',
																	],
															],
															[
																	[
																			'field' => 'field_product_video',
																			'operator' => '==',
																			'value' => 'vimeo',
																	],
															],
													],
											],
									],
							],
					],
					'location' => [
							[
									[
											'param' => 'post_type',
											'operator' => '==',
											'value' => 'product',
									],
							],
					],
					'menu_order' => 0,
					'position' => 'side',
					'style' => 'default',
					'label_placement' => 'top',
					'instruction_placement' => 'label',
					'active' => true,
			]);
			
			if (function_exists('elementor_load_plugin_textdomain')):
				
				$templates = FSD_Helper::get_elementor_templates('section');
				
				if (!empty($templates)):
					
					$formatted_templates = [];
					
					$formatted_templates['none'] = esc_html__('None', 'fs-core');
					
					foreach ($templates as $template):
						
						$formatted_templates[$template['template_id']] = $template['title'];
					
					endforeach;
					
					acf_add_local_field_group([
							'key' => 'group_cta_settings',
							'title' => esc_html__('CTA', 'fs-core'),
							'fields' => [
									[
											'key' => 'field_cta_content',
											'label' => esc_html__('CTA Template', 'fs-core'),
											'name' => 'option_cta_content',
											'type' => 'select',
											'instructions' => esc_html__('Select some Elementor template to display it before footer section (optional)', 'fs-core'),
											'choices' => $formatted_templates
									],
							],
							'location' => [
									[
											[
													'param' => 'post_type',
													'operator' => '==',
													'value' => 'post',
											],
									],
									[
											[
													'param' => 'post_type',
													'operator' => '==',
													'value' => 'page',
											],
									],
									[
											[
													'param' => 'post_type',
													'operator' => '==',
													'value' => 'product',
											],
									],
							],
							'menu_order' => 0,
							'position' => 'side',
							'style' => 'default',
							'label_placement' => 'top',
							'instruction_placement' => 'label',
							'hide_on_screen' => '',
							'active' => true,
							'description' => '',
					]);
				
				endif;
			
			endif;
		
		endif;
		
	}
	
	/**
	 * init widgets
	 */
	public function init_widgets()
	{
		
		/* check if exists elementor */
		if (function_exists('elementor_load_plugin_textdomain')):
			
			/* check if button widget is not exists */
			if (!class_exists('FS_Button_Widget')):
				
				require_once(self::$plugin_path . 'widgets/button.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Button_Widget());
			
			endif;
			
			/* check if accordion widget is not exists */
			if (!class_exists('FS_Accordion')):
				
				require_once(self::$plugin_path . 'widgets/accordions.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Accordion());
			
			endif;
			
			/* check if cf7 widget is not exists */
			if (!class_exists('FS_CF7_Form_Widget')):
				
				require_once(self::$plugin_path . 'widgets/cf7-form.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_CF7_Form_Widget());
			
			endif;
			
			/* check if content tabs widget is not exists */
			if (!class_exists('FS_Content_Tabs')):
				
				require_once(self::$plugin_path . 'widgets/content-tabs.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Content_Tabs());
			
			endif;
			
			/* check if countdown widget is not exists */
			if (!class_exists('FS_Countdown_Widget')):
				
				require_once(self::$plugin_path . 'widgets/countdown.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Countdown_Widget());
			
			endif;
			
			/* check if featured product categories widget is not exists */
			if (!class_exists('FS_Featured_Product_Categories_Widget')):
				
				require_once(self::$plugin_path . 'widgets/featured-product-categories.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Featured_Product_Categories_Widget());
			
			endif;
			
			/* check if hero slider widget is not exists */
			if (!class_exists('FS_Hero_Slider_Widget')):
				
				require_once(self::$plugin_path . 'widgets/hero-slider.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Hero_Slider_Widget());
			
			endif;
			
			/* check if instagram feed widget is not exists */
			if (!class_exists('FS_Instagram_Feed_Widget')):
				
				require_once(self::$plugin_path . 'widgets/instagram-feed.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Instagram_Feed_Widget());
			
			endif;
			
			/* check if paroller widget is not exists */
			if (!class_exists('FS_Paroller_Widget')):
				
				require_once(self::$plugin_path . 'widgets/paroller-image.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Paroller_Widget());
			
			endif;
			
			/* check if positions list widget is not exists */
			if (!class_exists('FS_Positions_List_Widget')):
				
				require_once(self::$plugin_path . 'widgets/positions-list.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Positions_List_Widget());
			
			endif;
			
			/* check if posts slider widget is not exists */
			if (!class_exists('FS_Posts_Slider_Widget')):
				
				require_once(self::$plugin_path . 'widgets/posts-slider.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Posts_Slider_Widget());
			
			endif;
			
			/* check if exists Woocommerce */
			if (class_exists('WooCommerce')):
				
				/* check if products slider widget is not exists */
				if (!class_exists('FS_Products_Slider_Widget')):
					
					require_once(self::$plugin_path . 'widgets/products-slider.php');
					
					\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Products_Slider_Widget());
				
				endif;
			
			endif;
			
			/* check if testimonials widget is not exists */
			if (!class_exists('FS_Testimonials')):
				
				require_once(self::$plugin_path . 'widgets/testimonials.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Testimonials());
			
			endif;
			
			/* check if ticker widget is not exists */
			if (!class_exists('FS_Ticker_Widget')):
				
				require_once(self::$plugin_path . 'widgets/ticker.php');
				
				\Elementor\Plugin::instance()->widgets_manager->register(new \FS_Ticker_Widget());
			
			endif;
		
		endif;
		
	}
	
	/**
	 * @param $elements_manager
	 */
	public function registered_categories($elements_manager)
	{
		
		/* check if exists elementor */
		if (function_exists('elementor_load_plugin_textdomain')):
			
			/* add new category for widgets */
			$elements_manager->add_category(
					self::$prefix . 'widgets',
					[
							'title' => esc_html__('FS Widgets', 'fs-core'),
							'icon' => '',
					]
			);
		
		endif;
		
	}
	
	
	/**
	 * @return void
	 */
	public function admin_notice_minimum_php_version()
	{
		
		/* check if activate === true */
		if (isset($_GET['activate'])):
			
			/* unset activate */
			unset($_GET['activate']);
		
		endif;
		
		/* alert message */
		$message = sprintf(
				esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'fs-core'),
				'<strong>' . esc_html__(self::$name, 'fs-core') . '</strong>',
				'<strong>' . esc_html__('PHP', 'fs-core') . '</strong>',
				self::$minimum_php_version
		);
		
		/* output message */
		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
		
		unset($message);
		
	}
	
	
	/**
	 * @return void
	 */
	public function register_shortcodes()
	{
		
		add_shortcode('fs-social', [$this, 'social_shortcode']);
		
	}
	
	/**
	 * @return string
	 */
	public function social_shortcode()
	{
		
		$social = get_theme_mod('social-list');
		
		if (!empty($social)):
			
			$html = '<div class="social-list-wrapper">';
			
			$html .= '<ul class="fs-social-list">';
			
			foreach ($social as $item) :
				
				$target = 'self';
				
				if (!empty($item['target'])):
					
					$target = $item['target'];
				
				endif;
				
				$html .= '<li><a target="' . esc_attr($target) . '" href="' . esc_url($item['social_url']) . '"><i class="' . esc_attr($item['social_icon']) . '"></i></a></li>';
			
			endforeach;
			
			$html .= '</ul>';
			
			$html .= '</div>';
		
		endif;
		
		return $html;
		
	}
	
}