<?php defined('ABSPATH') || exit;


/**
 * Class FSD_Shop
 */
class FSD_Shop extends FSD_Core
{

    /**
     * fs_portfolio constructor.
     */
    public function __construct()
    {

        /* init portfolio */
        $this->init();

    }

    /**
     * init
     */
    public function init()
    {

        /* set woo archive thumbnail size */
        add_filter('single_product_archive_thumbnail_size', function ($size) {

            /* set */
            return 'fs-vertical-size-large';

        });

        /* set woo archive subcategory thumbnail size */
        add_filter('subcategory_archive_thumbnail_size', function ($size) {

            /* set small size */
            return 'fs-square-size-medium';

        });

        /* set woo gallery thumbnails size */
        add_filter('woocommerce_gallery_thumbnail_size', function ($size) {

            /* set small size */
            return 'fs-vertical-size-full';

        });

        /* set woo gallery full size */
        add_filter('woocommerce_gallery_image_size', function ($size) {

            /* set small size */
            return 'fs-vertical-size-full';

        });

        /* set woo gallery full size */
        add_filter('woocommerce_gallery_full_size', function ($size) {

            /* set small size */
            return 'fs-vertical-size-full';

        });

        add_action('wp_ajax_nopriv_fsd_shopping_bag', [$this, 'shopping_bag']);
        add_action('wp_ajax_fsd_shopping_bag', [$this, 'shopping_bag']);

        add_action('wp_ajax_nopriv_fsd_shopping_bag_remove_item', [$this, 'shopping_bag_remove_item']);
        add_action('wp_ajax_fsd_shopping_bag_remove_item', [$this, 'shopping_bag_remove_item']);

        add_action('wp_ajax_nopriv_fsd_shopping_bag_change_quantity', [$this, 'shopping_bag_change_quantity']);
        add_action('wp_ajax_fsd_shopping_bag_change_quantity', [$this, 'shopping_bag_change_quantity']);

        add_action('wp_ajax_nopriv_fsd_shopping_bag_remove_item', [$this, 'shopping_bag_remove_item']);
        add_action('wp_ajax_fsd_shopping_bag_remove_item', [$this, 'shopping_bag_remove_item']);

        add_action('wp_ajax_nopriv_fsd_shopping_bag_remove_item', [$this, 'shopping_bag_remove_item']);
        add_action('wp_ajax_fsd_shopping_bag_remove_item', [$this, 'shopping_bag_remove_item']);

        add_action('wp_ajax_nopriv_fsd_shopping_bag_update_count', [$this, 'shopping_bag_update_count']);
        add_action('wp_ajax_fsd_shopping_bag_update_count', [$this, 'shopping_bag_update_count']);

        add_action('wp_ajax_nopriv_fsd_shopping_bag_update_subtotals', [$this, 'shopping_bag_update_subtotals']);
        add_action('wp_ajax_fsd_shopping_bag_update_subtotals', [$this, 'shopping_bag_update_subtotals']);

        add_action('wp_ajax_nopriv_fsd_add_to_cart', [$this, 'add_to_cart']);
        add_action('wp_ajax_fsd_add_to_cart', [$this, 'add_to_cart']);

        $this->settings();

    }

    public function settings()
    {

        if (function_exists('acf_add_local_field_group')):

            acf_add_local_field_group(array(
                'key' => 'group_product_settings',
                'title' => __('Product Options', 'fs-core'),
                'location' => array(
                    array(
                        array(
                            'param' => 'taxonomy',
                            'operator' => '==',
                            'value' => 'product_cat',
                        ),
                    ),
                ),
                'position' => 'side',
            ));

        endif;

        if (function_exists('acf_add_local_field')):

            /* menu item image setting */
            acf_add_local_field(array(
                'key' => 'field_product_category_additional_image',
                'label' => esc_html__('Additional Image', 'jk-core'),
                'name' => 'option_product_category_additional_image',
                'type' => 'image',
                'instructions' => esc_html__('Upload product category additional image', 'jk-core'),
                'return_format' => 'id',
                'preview_size' => 'thumbnail',
                'library' => 'all',
                'parent' => 'group_product_settings',
            ));

            /* menu item image setting */
            acf_add_local_field(array(
                'key' => 'field_product_category_description',
                'label' => esc_html__('Category Description', 'jk-core'),
                'name' => 'option_product_category_description',
                'type' => 'text',
                'instructions' => esc_html__('Input your category description', 'jk-core'),
                'library' => 'all',
                'parent' => 'group_product_settings',
            ));

            if (function_exists('elementor_load_plugin_textdomain')):

                $templates = FSD_Helper::get_elementor_templates('section');

                if (!empty($templates)):

                    $formatted_templates = array();

                    $formatted_templates['none'] = esc_html__('None', 'fs-core');

                    foreach ($templates as $template):

                        $formatted_templates[$template['template_id']] = $template['title'];

                    endforeach;

                    acf_add_local_field_group(array(
                        'key' => 'group_product_page_settings',
                        'title' => esc_html__('After Content', 'jk-core'),
                        'fields' => array(
                            array(
                                'key' => 'field_after_content',
                                'label' => esc_html__('After Content (optional)', 'jk-core'),
                                'name' => 'option_after_content',
                                'type' => 'select',
                                'instructions' => esc_html__('Select some Elementor template to display it after product info (optional)', 'jk-core'),
                                'choices' => $formatted_templates
                            ),
                        ),
                        'location' => array(
                            array(
                                array(
                                    'param' => 'post_type',
                                    'operator' => '==',
                                    'value' => 'product',
                                ),
                            ),
                        ),
                        'menu_order' => 0,
                        'position' => 'side',
                        'style' => 'default',
                        'label_placement' => 'top',
                        'instruction_placement' => 'label',
                        'hide_on_screen' => '',
                        'active' => true,
                        'description' => '',
                    ));

                endif;

            endif;

            acf_add_local_field_group(array(
                'key' => 'group_product_page_labels_settings',
                'title' => esc_html__('Product Labels', 'jk-core'),
                'fields' => array(
                    array(
                        'key' => 'field_new_label',
                        'label' => esc_html__('New Label', 'jk-core'),
                        'name' => 'option_new_label',
                        'type' => 'true_false',
                        'instructions' => esc_html__('If true - will be enabled the "New" product label', 'jk-core'),
                        'required' => 0,
                        'conditional_logic' => 0,
                        'default_value' => 0,
                        'ui' => 1,
                        'ui_on_text' => esc_html__('Enable', 'fs-core'),
                        'ui_off_text' => esc_html__('Disable', 'fs-core'),
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'product',
                        ),
                    ),
                ),
                'menu_order' => 0,
                'position' => 'side',
                'style' => 'default',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => true,
                'description' => '',
            ));

        endif;

    }

    public function shopping_bag()
    {

        wp_reset_postdata();

        ?>

        <div class="products-list">

            <?php

            $items = WC()->cart->get_cart();

            foreach ($items as $item => $values) :

                $product_id = $values['data']->get_id();

                $product = wc_get_product($product_id);

                $title = $product->get_title();

                $image_id = $product->get_image_id();

                $quantity = $values['quantity'];

                ?>

                <article class="product" data-product-id="<?php echo esc_attr($product_id); ?>">

                    <div class="product-image">

                        <?php

                        echo FSD_Helper::render_image($image_id,
                            'thumbnail',
                            array('sizes' => implode(',', array(
                                '(max-width: 300px) 300px',
                            )),
                                'srcset' => implode(',', array(
                                    esc_url(wp_get_attachment_image_url($image_id, 'thumbnail')) . ' 300w',
                                )),
                                'loading' => 'lazy',
                                'alt' => get_the_title()
                            ), false);

                        ?>

                        <a href="<?php echo esc_url($product->get_permalink()); ?>"
                           class="link-overlay"></a>

                    </div>

                    <div class="product-body">

                        <h6 class="product-title">

                            <a href="<?php echo esc_url($product->get_permalink()); ?>">

                                <?php echo esc_html(wp_trim_words($title, 10, '...')); ?>

                            </a>

                        </h6>

                        <p class="product-price">

                            <?php echo $product->get_price_html(); ?>

                        </p>

                        <div class="custom-quantity-input-wrapper">

                            <p class="pre">

                                <?php echo esc_html__('Quantity', 'levre'); ?>

                            </p>

                            <div class="quantity-inner">

                                <button class="decrease">

                                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/chevron.svg'); ?>"
                                         alt="<?php echo esc_attr__('Chevron Left', 'levre'); ?>">

                                </button>

                                <input type="number" class="quantity-input" min="1"
                                       value="<?php echo esc_attr($quantity); ?>">

                                <button class="increase">

                                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/chevron.svg'); ?>"
                                         alt="<?php echo esc_attr__('Chevron Right', 'levre'); ?>">

                                </button>

                            </div>

                        </div>

                        <div class="product-remote-button">

                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/close.svg'); ?>"
                                 alt="<?php echo esc_attr__('Remove Icon', 'levre'); ?>">

                        </div>

                    </div>

                </article>

            <?php

            endforeach;

            ?>

        </div>

        <?php

        wp_reset_postdata();

        die();

    }

    public function shopping_bag_remove_item()
    {

        $id = (int)$_POST['id'];

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) :

            if ($cart_item['product_id'] === $id || $cart_item['variation_id'] === $id) :

                WC()->cart->remove_cart_item($cart_item_key);

            endif;

        endforeach;

        die();

    }

    public function shopping_bag_update_count()
    {

        $cart_count = WC()->cart->cart_contents_count;

        echo esc_html($cart_count);

        die();

    }

    public function shopping_bag_update_subtotals()
    {

        echo WC()->cart->get_cart_total();

        die();

    }

    public function add_to_cart()
    {

        $id = $_POST['product_id'];

        WC()->cart->add_to_cart($id);

        echo '<div class="woocommerce-message" role="alert">';

        echo FSD_Theme::custom_added_to_cart_message('', array($id => 1), false);

        echo '<div class="toast-close-button close-button"><img src="' . esc_url(get_template_directory_uri() . '/assets/img/close-tost.svg') . '" alt="' . esc_attr__('Close icon', 'levre') . '"></div>';

        echo '</div>';

        die();

    }

    public function shopping_bag_change_quantity()
    {

        $id = (int)$_POST['id'];

        $type = $_POST['type'];

        $old_value = (int)$_POST['old'];

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) :

            if ($cart_item['product_id'] === $id) :

                if ($type === 'decrease'):

                    WC()->cart->set_quantity($cart_item_key, $old_value - 1);

                elseif ($type === 'increase'):

                    WC()->cart->set_quantity($cart_item_key, $old_value + 1);

                endif;

            endif;

        endforeach;

        die();

    }

}
